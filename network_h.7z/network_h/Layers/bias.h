#pragma once

#include "../defines.h"

// Bias Layer

class BIAS
{
public:
	bool built;
	int d,h,w;
	float *b;
	bool inplace;

private:
	float *tmpb;
	inline void initmem(float *&wei, float *&tmp)
	{
		b=wei,tmpb=tmp;
		wei+=d,tmp+=d;
	}

public:
	inline void init(int &m,SHAPE3D Input,bool Inplace=false)
	{
		d=std::get<0>(Input),h=std::get<1>(Input),w=std::get<2>(Input);
		inplace=Inplace;
		m+=d;
	}
	inline void build(float *&wei, float *&tmp)
	{
		built=true;
		initmem(wei,tmp);
		// init w
		memset(b,0,sizeof(float)*d);
	}
	inline void save(std::ofstream& ouf)
	{
		writf(ouf,built);
		if(!built) return;
		writf(ouf,SHAPE3D(d,h,w)),writf(ouf,inplace);
	}
	inline void load(std::ifstream& inf,float *&wei,float *&tmp)
	{
		readf(inf,built);
		if(!built) return;
		SHAPE3D Input;
		bool Inplace;
		readf(inf,Input),readf(inf,Inplace);
		int nou=0;
		init(nou,Input,Inplace);
		initmem(wei,tmp);
	}

private:
	inline void forward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size,1);
		int id=nin->d,ih=nin->h,iw=nin->w;
		int od=nout->d,oh=nout->h,ow=nout->w;
		float* in=nin->a;
		float* out=nout->a;
		ext_assert(d==id&&h==ih&&w==iw&&d==od&&h==oh&&w==ow,
			fprintf(stderr,"\
In BIAS::operator()\n\
  shape = [%d * %d * %d]\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",d,h,w,id,ih,iw,od,oh,ow));
		for(int t=0;t<bs;t++)
		{
			int adt=t*d*h*w;
			for(int i=0;i<d;i++)
			{
				int ad=i*h*w;
				for(int j=0;j<h*w;j++) out[adt+ad+j]=in[adt+ad+j]+b[i];
			}
		}
	}
	inline void backward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size,1);
		float* din=nin->da;
		float* dout=nout->da;
		for(int t=0;t<bs;t++)
		{
			int adt=t*d*h*w;
			for(int i=0;i<d;i++)
			{
				int ad=i*h*w;
				for(int j=0;j<h*w;j++)
				{
					if(!inplace) din[adt+ad+j]+=dout[adt+ad+j];
					tmpb[i]+=dout[adt+ad+j];
				}
			}
		}
	}

public:
	inline val3d operator()(val3d x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In BIAS::operator()\n\
  this hasn't been initalized yet\n\n"));
		val3d res;
		if(!inplace)
		{
			res=val3d(d,h,w);
			res.dat->in1=x.dat,x.dat->oud++;
		}
		else res=x;
		forward(x.dat,res.dat);
		res.dat->backward_f.push_back(std::bind(
			&std::remove_reference<decltype(*this)>::type::backward,
			this,
			std::placeholders::_1,std::placeholders::_2));
		return res;
	}
	inline BIAS()
	{
		built=false;
		#ifdef ENABLE_AUTO_SL
			AUTO_SL_LAYER_CONSTRUCTER_WEIGHT(b)
		#endif
	}
};
