#pragma once

#include "../defines.h"

// Convolution layer

class CONV
{
public:
	int ind, inh, inw;
	int cnt, ch, cw;
	int stx, sty;
	int pdx, pdy;
	float pdval;
	int ouh, ouw;
	float * w;

private:
	float* tmpw;
	inline void initmem(float *&wei, float *&tmp)
	{
		w = wei, tmpw = tmp;
		wei += (ind * ch * cw) * cnt, tmp += (ind * ch * cw) * cnt;
	}
	float* inmrt;
	inline void getmem(){inmrt = new float[MAX_BUFSIZE_BYTE / sizeof(float)]; }
	inline void freemem(){delete[] inmrt;}

public:
	inline void init(int &m,
		SHAPE3D Input,
		int CoreCnt, std::pair<int, int> Core,
		std::pair<int, int> Stride = { 1, 1 },
		std::pair<int, int> Padding = { 0, 0 }, float PaddingVal = 0)
	{
		ind = std::get<0>(Input), inh = std::get<1>(Input), inw = std::get<2>(Input),
			cnt = CoreCnt, ch = Core.first, cw = Core.second;
		stx = Stride.first, sty = Stride.second;
		pdx = Padding.first, pdy = Padding.second, pdval = PaddingVal;
		ouh = (inh + pdx * 2 - ch) / stx + 1, ouw = (inw + pdy * 2 - cw) / sty + 1;
		m += (ind * ch * cw) * cnt;
	}
	inline void build(float *&wei, float *&tmp, int InitType = INIT_HE)
	{
		initmem(wei, tmp);
		// init w
		std::default_random_engine gen;
		std::normal_distribution<float> wer;
		if (InitType == INIT_HE) wer = std::normal_distribution<float>(0, sqrt(2 / (float)ind / ch / cw));
		else                     wer = std::normal_distribution<float>(0, sqrt(1 / (float)ind / ch / cw));
		gen.seed(time(NULL));
		for (int i = 0; i < (ind * ch * cw) * cnt; i++) w[i] = wer(gen);
	}
	inline void save(std::ofstream& ouf)
	{
		writf(ouf, SHAPE3D(ind, inh, inw));
		writf(ouf, cnt), writf(ouf, std::make_pair(ch, cw));
		writf(ouf, std::make_pair(stx, sty));
		writf(ouf, std::make_pair(pdx, pdy)), writf(ouf, pdval);
	}
	inline void load(std::ifstream& inf, float *&wei, float *&tmp)
	{
		SHAPE3D Input;
		int CoreCnt;
		std::pair<int, int> Core, Stride, Padding;
		float PaddingVal;
		readf(inf, Input);
		readf(inf, CoreCnt), readf(inf, Core);
		readf(inf, Stride);
		readf(inf, Padding), readf(inf, PaddingVal);
		int nou = 0;
		init(nou,
			Input,
			CoreCnt, Core,
			Stride,
			Padding, PaddingVal);
		initmem(wei, tmp);
	}

private:
	inline void forward(int bs,
						int id,int ih,int iw,float *in,
						int od,int oh,int ow,float *out)
	{
		ext_assert(ind==id&&inh==ih&&inw==iw&&cnt==od&&ouh==oh&&ouw==ow,
			fprintf(stderr,"\
In CONV::forward(...)\n\
  in  = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",ind,inh,inw,cnt,ouh,ouw,id,ih,iw,od,oh,ow));
		getmem();
		bs = (std::max)(bs, 1);
		memset(out, 0, sizeof(float)*bs*cnt*ouh*ouw);
		int in_h = ouh * ouw, in_w = ind * ch * cw;
		int pre_h = MAX_BUFSIZE_BYTE / sizeof(float) / in_w;
		for (int l = 0; l < bs * in_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, bs*in_h - 1);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % in_h, ad = k / in_h * ind * inh * inw;
				int ox = idd / ouw, oy = idd % ouw;
				int lx = ox * stx - pdx, ly = oy * sty - pdy;
				for (int d = 0; d < ind; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
							if (x >= 0 && x < inh && y >= 0 && y < inw)
								inmrt[p++] = in[ad + d * inh * inw + x * inw + y];
							else
								inmrt[p++] = pdval;
			}
			Matrix_Mul(r - l + 1, in_w, cnt,
				inmrt, false,
				w, false,
				out + cnt * l);
		}
		toNDHW(out, bs, ouh, ouw, cnt);
		freemem();
	}
	inline void backward(int bs,
						 int id,int ih,int iw,float *in, float* din,
						 int od,int oh,int ow,float *dout)
	{
		ext_assert(ind==id&&inh==ih&&inw==iw&&cnt==od&&ouh==oh&&ouw==ow,
			fprintf(stderr,"\
In CONV::backward(...)\n\
  in  = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",ind,inh,inw,cnt,ouh,ouw,id,ih,iw,od,oh,ow));
		getmem();
		memset(din, 0, sizeof(float) * bs * ind * inh * inw);
		toNHWD(dout, bs, cnt, ouh, ouw);
		int in_h = ouh * ouw, in_w = ind * ch * cw;
		int pre_h = MAX_BUFSIZE_BYTE / sizeof(float) / in_w;
		for (int l = 0; l < bs * in_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, bs * in_h - 1);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % in_h, ad = k / in_h * ind * inh * inw;
				int ox = idd / ouw, oy = idd % ouw;
				int lx = ox * stx - pdx, ly = oy * sty - pdy;
				for (int d = 0; d < ind; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
							if (x >= 0 && x < inh && y >= 0 && y < inw)
								inmrt[p++] = in[ad + d * inh * inw + x * inw + y];
							else
								inmrt[p++] = pdval;
			}
			Matrix_Mul(in_w, r - l + 1, cnt,
				inmrt, true,
				dout + cnt * l, false,
				tmpw);
			memset(inmrt, 0, sizeof(float) * (r - l + 1) * in_w);
			Matrix_Mul(r - l + 1, cnt, in_w,
				dout + cnt * l, false,
				w, true,
				inmrt);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % in_h, ad = k / in_h * ind * inh * inw;
				int ox = idd / ouw, oy = idd % ouw;
				int lx = ox * stx - pdx, ly = oy * sty - pdy;
				for (int d = 0; d < ind; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
						{
							if (x >= 0 && x < inh && y >= 0 && y < inw)
								din[ad + d * inh * inw + x * inw + y] += inmrt[p];
							p++;
						}
			}
		}
		toNDHW(dout, bs, ouh, ouw, cnt);
		freemem();
	}

public:
	inline val3d operator()(val3d x)
	{
		val3d res(cnt,ouh,ouw);
		res.dat->in1=x.dat;
		x.dat->oud++;
		#define pch(x) std::placeholders::_##x
		res.dat->forward_f=std::bind(
			&std::remove_reference<decltype(*this)>::type::forward,
			this,
			pch(1),
			pch(2),pch(3),pch(4),pch(5),
			pch(6),pch(7),pch(8),pch(9));
		res.dat->backward_f=std::bind(
			&std::remove_reference<decltype(*this)>::type::backward,
			this,
			pch(1),
			pch(2),pch(3),pch(4),pch(5),pch(6),
			pch(7),pch(8),pch(9),pch(10));
		#undef pch
		res.dat->forward();
		return res;
	}
	#ifdef ENABLE_AUTO_SL
		AUTO_SL_LAYER_CONSTRUCTER_WEIGHT(CONV)
	#endif
};
