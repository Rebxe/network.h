#pragma once

#include "../defines.h"

// Leaky_ReLU Layer

class LEAKY_RELU
{
public:
	bool built;
	int siz;
	float a;
	bool inplace;
	
private:
	int tmpsize;
	float* tmp;
	inline void getmem(int bs){if(tmpsize<bs*siz) delete[] tmp,tmp=new float[bs*siz],tmpsize=bs*siz;}

public:
	inline void init(int Siz,bool Inplace=false,float Alpha = 0.01)
	{
		built=true;
		siz=Siz;
		inplace=Inplace;
		a=Alpha;
	}
	inline void save(std::ofstream& ouf)
	{
		writf(ouf,built);
		if(!built) return;
		writf(ouf,siz),writf(ouf,inplace),writf(ouf,a);
	}
	inline void load(std::ifstream& inf)
	{
		readf(inf,built);
		if(!built) return;
		int Siz;
		bool Inplace;
		float Alpha;
		readf(inf,Siz),readf(inf,Inplace),readf(inf,Alpha);
		init(Siz,Inplace,Alpha);
	}
	inline void delthis(){if(tmpsize!=0) delete[] tmp;}

private:
	inline void forward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size, 1);
		int id=nin->d,ih=nin->h,iw=nin->w;
		int od=nout->d,oh=nout->h,ow=nout->w;
		float* in=nin->a;
		float* out=nout->a;
		ext_assert(siz==id*ih*iw&&siz==od*oh*ow,
			fprintf(stderr,"\
In LEAKY_RELU::operator()\n\
  siz = %d\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",siz,id,ih,iw,od,oh,ow));
		for(int i=0;i<bs*siz;i++) out[i]=in[i]<0?a*in[i]:in[i];
		if(auto_dao::Batch_Size!=0&&inplace)
		{
			getmem(bs);
			memcpy(tmp,in,sizeof(float)*bs*siz);
		}
	}
	inline void backward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size, 1);
		float *in=nin->a,*din=nin->da;
		float *dout=nout->da;
		if(!inplace) for(int i=0;i<bs*siz;i++) din[i]+=in[i]<0?a*dout[i]:dout[i];
		else for(int i=0;i<bs*siz;i++) dout[i]=tmp[i]<0?a*dout[i]:dout[i];
	}

public:
	inline val3d operator()(val3d x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In LEAKY_RELU::operator()\n\
  this hasn't been initalized yet\n\n"));
		val3d res;
		if(!inplace)
		{
			res=val3d(x.d,x.h,x.w);
			res.dat->in1=x.dat,x.dat->oud++;
		}
		else res=x;
		forward(x.dat,res.dat);
		res.dat->backward_f.push_back(std::bind(
			&std::remove_reference<decltype(*this)>::type::backward,
			this,
			std::placeholders::_1,std::placeholders::_2));
		return res;
	}
	inline LEAKY_RELU()
	{
		built=false;
		tmpsize=0;
		#ifdef ENABLE_AUTO_SL
			AUTO_SL_LAYER_CONSTRUCTER_DELTHISFUNC
		#endif
	}
};
