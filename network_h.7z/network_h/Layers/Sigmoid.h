#pragma once

#include "../defines.h"

// Sigmoid Layer

class SIGMOID
{
public:
	bool built;
	int siz;
	bool inplace;
	
private:
	int tmpsize;
	float* tmp;
	inline void getmem(int bs){if(tmpsize<bs*siz) delete[] tmp,tmp=new float[bs*siz],tmpsize=bs*siz;}

public:
	inline void init(int Siz,bool Inplace=false)
	{
		built=true;
		siz=Siz;
		inplace=Inplace;
	}
	inline void save(std::ofstream& ouf)
	{
		writf(ouf,built);
		if(!built) return;
		writf(ouf,siz),writf(ouf,inplace);
	}
	inline void load(std::ifstream& inf)
	{
		readf(inf,built);
		if(!built) return;
		int Siz;
		bool Inplace;
		readf(inf,Siz),readf(inf,Inplace);
		init(Siz,Inplace);
	}
	inline void delthis(){if(tmpsize!=0) delete[] tmp;}

private:
	inline void forward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size, 1);
		int id=nin->d,ih=nin->h,iw=nin->w;
		int od=nout->d,oh=nout->h,ow=nout->w;
		float* in=nin->a;
		float* out=nout->a;
		ext_assert(siz==id*ih*iw&&siz==od*oh*ow,
			fprintf(stderr,"\
In SIGMOID::operator()\n\
  siz = %d\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",siz,id,ih,iw,od,oh,ow));
		for(int i=0;i<bs*siz;i++) out[i]=1 / (1 + exp(-in[i]));
		if(auto_dao::Batch_Size!=0&&inplace)
		{
			getmem(bs);
			memcpy(tmp,in,sizeof(float)*bs*siz);
		}
	}
	inline void backward(auto_dao::node* nin,auto_dao::node* nout)
	{
		int bs = (std::max)(auto_dao::Batch_Size, 1);
		float *in=nin->a,*din=nin->da;
		float *dout=nout->da;
		if(!inplace)
		{
			for(int i=0;i<bs*siz;i++)
			{
				float x=exp(-in[i]);
				din[i]+=(1 / (1 + x)) * (1 - (1 / (1 + x)))*dout[i];
			}
		}
		else
		{
			for(int i=0;i<bs*siz;i++)
			{
				float x=exp(-tmp[i]);
				dout[i]=(1 / (1 + x)) * (1 - (1 / (1 + x)))*dout[i];
			}
		}
	}

public:
	inline val3d operator()(val3d x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In SIGMOID::operator()\n\
  this hasn't been initalized yet\n\n"));
		val3d res;
		if(!inplace)
		{
			res=val3d(x.d,x.h,x.w);
			res.dat->in1=x.dat,x.dat->oud++;
		}
		else res=x;
		forward(x.dat,res.dat);
		res.dat->backward_f.push_back(std::bind(
			&std::remove_reference<decltype(*this)>::type::backward,
			this,
			std::placeholders::_1,std::placeholders::_2));
		return res;
	}
	inline SIGMOID()
	{
		built=false;
		tmpsize=0;
		#ifdef ENABLE_AUTO_SL
			AUTO_SL_LAYER_CONSTRUCTER_DELTHISFUNC
		#endif
	}
};
