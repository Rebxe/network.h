#pragma once

#include "../defines.h"

// Deconvolution layer

class DECONV
{
public:
	int ind, inh, inw;
	int cnt, ch, cw;
	int stx, sty;
	int pdx, pdy;
	int ouh, ouw;
	float* w;

private:
	float* tmpw;
	inline void initmem(float* wei, float* tmp)
	{
		w = wei, tmpw = tmp;
		wei += ind * (cnt * ch * cw), tmp += ind * (cnt * ch * cw);
	}
	float* outmrt;
	inline void getmem() { outmrt = new float[MAX_BUFSIZE_BYTE / sizeof(float)]; }
	inline void freemem() { delete[] outmrt; }

public:
	inline void init(int &m, 
		SHAPE3D Input,
		int CoreCnt, std::pair<int,int> Core,
		std::pair<int,int> Stride = {1,1},
		std::pair<int,int> Padding = {0,0})
	{
		ind = std::get<0>(Input), inh = std::get<1>(Input), inw = std::get<2>(Input);
		cnt = CoreCnt, ch = Core.first, cw = Core.second;
		stx = Stride.first, sty = Stride.second;
		pdx = Padding.first, pdy = Padding.second;
		ouh = ch + (inh - 1) * stx - pdx * 2, ouw = cw + (inw - 1) * sty - pdy * 2;
		m += ind * (cnt * ch * cw);
	}
	inline void build(float *&wei,float *&tmp,int InitType = INIT_HE)
	{
		initmem(wei,tmp);
		// init w
		std::default_random_engine gen;
		std::normal_distribution<float> wer;
		int ins = ind * ((ch + stx - 1) / stx + (cw + sty - 1) / sty);
		if (InitType == INIT_HE) wer = std::normal_distribution<float>(0, sqrt(2 / (float)ins));
		else                     wer = std::normal_distribution<float>(0, sqrt(1 / (float)ins));
		gen.seed(time(NULL));
		for (int i = 0; i < ind * (cnt * ch * cw); i++) w[i] = wer(gen);
	}
	inline void save(std::ofstream& ouf)
	{
		writf(ouf,SHAPE3D(ind,inh,inw));
		writf(ouf,cnt),writf(ouf,std::make_pair(ch,cw));
		writf(ouf,std::make_pair(stx,sty));
		writf(ouf,std::make_pair(pdx,pdy));
	}
	inline void load(std::ifstream& inf,float *&wei, float *&tmp)
	{
		SHAPE3D Input;
		int CoreCnt;
		std::pair<int,int> Core,Stride,Padding;
		readf(inf,Input);
		readf(inf,CoreCnt),readf(inf,Core);
		readf(inf,Stride),readf(inf,Padding);
		int nou=0;
		init(nou,
			Input,
			CoreCnt,Core,
			Stride,
			Padding);
		initmem(wei,tmp);
	}

private: 
	inline void forward(int bs,
						int id,int ih,int iw,float *in,
						int od,int oh,int ow,float *out)
	{
		ext_assert(ind==id&&inh==ih&&inw==iw&&cnt==od&&ouh==oh&&ouw==ow,
			fprintf(stderr,"\
In DECONV::forward(...)\n\
  in  = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",ind,inh,inw,cnt,ouh,ouw,id,ih,iw,od,oh,ow));
		getmem();
		bs = (std::max)(bs, 1);
		memset(out, 0, sizeof(float) * bs * cnt * ouh * ouw);
		toNHWD(in, bs, ind, inh, inw);
		int out_h = inh * inw, out_w = cnt * ch * cw;
		int pre_h = MAX_BUFSIZE_BYTE / sizeof(float) / out_w;
		for (int l = 0; l < bs * out_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, bs * out_h - 1);
			memset(outmrt, 0, sizeof(float) * (r - l + 1) * out_w);
			Matrix_Mul(r - l + 1, ind, out_w,
				in + ind * l, false,
				w, false,
				outmrt);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % out_h, ad = k / out_h * cnt * ouh * ouw;
				int ix = idd / inw, iy = idd % inw;
				int lx = ix * stx - pdx, ly = iy * sty - pdy;
				for (int d = 0; d < cnt; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
						{
							if (x >= 0 && x < ouh && y >= 0 && y < ouw)
								out[ad + d * ouh * ouw + x * ouw + y] += outmrt[p];
							p++;
						}
			}
		}
		toNDHW(in, bs, inh, inw, ind);
		freemem();
	}
	inline void backward(int bs,
						 int id,int ih,int iw,float *in, float* din,
						 int od,int oh,int ow,float *dout)
	{
		ext_assert(ind==id&&inh==ih&&inw==iw&&cnt==od&&ouh==oh&&ouw==ow,
			fprintf(stderr,"\
In DECONV::backward(...)\n\
  in  = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  Real Input  = [%d * %d * %d]\n\
  Real Output = [%d * %d * %d]\n\n",ind,inh,inw,cnt,ouh,ouw,id,ih,iw,od,oh,ow));
		getmem();
		memset(din, 0, sizeof(float) * bs * ind * inh * inw);
		toNHWD(in, bs, ind, inh, inw);
		int out_h = inh * inw, out_w = cnt * ch * cw;
		int pre_h = MAX_BUFSIZE_BYTE / sizeof(float) / out_w;
		for (int l = 0; l < bs * out_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, bs * out_h - 1);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % out_h, ad = k / out_h * cnt * ouh * ouw;
				int ix = idd / inw, iy = idd % inw;
				int lx = ix * stx - pdx, ly = iy * sty - pdy;
				for (int d = 0; d < cnt; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
							if (x >= 0 && x < ouh && y >= 0 && y < ouw)
								outmrt[p++] = dout[ad + d * ouh * ouw + x * ouw + y];
							else
								outmrt[p++] = 0;
			}
			Matrix_Mul(ind, r - l + 1, out_w,
				in + ind * l, true,
				outmrt, false,
				tmpw);
			Matrix_Mul(r - l + 1, out_w, ind,
				outmrt, false,
				w, true,
				din + ind * l);
		}
		toNDHW(in, bs, inh, inw, ind);
		toNDHW(din, bs, inh, inw, ind);
		freemem();
	}

public:
	inline val3d operator()(val3d x)
	{
		val3d res(cnt,ouh,ouw);
		res.dat->in1=x.dat;
		x.dat->oud++;
		#define pch(x) std::placeholders::_##x
		res.dat->forward_f=std::bind(
			&std::remove_reference<decltype(*this)>::type::forward,
			this,
			pch(1),
			pch(2),pch(3),pch(4),pch(5),
			pch(6),pch(7),pch(8),pch(9));
		res.dat->backward_f=std::bind(
			&std::remove_reference<decltype(*this)>::type::backward,
			this,
			pch(1),
			pch(2),pch(3),pch(4),pch(5),pch(6),
			pch(7),pch(8),pch(9),pch(10));
		#undef pch
		res.dat->forward();
		return res;
	}
	#ifdef ENABLE_AUTO_SL
		AUTO_SL_LAYER_CONSTRUCTER_WEIGHT(DECONV)
	#endif
};
