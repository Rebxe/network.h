#pragma once

namespace network
{

template<typename T,typename owner>
class read_only
{
	friend owner;
	
	private:
		T x;
	
	public:
		read_only(){}
		template<typename number>
		read_only(number y){x=y;}
	
	public:
	    operator T() const { return x; }
	    template<typename number> bool   operator==(const number& a) const { return x ==a; } 
	    template<typename number> number operator+ (const number& a) const { return x + a; } 
	    template<typename number> number operator- (const number& a) const { return x - a; } 
	    template<typename number> number operator* (const number& a) const { return x * a; }  
	    template<typename number> number operator/ (const number& a) const { return x / a; } 
	    template<typename number> number operator<<(const number& a) const { return x <<a; }
	    template<typename number> number operator>>(const number& a) const { return x >>a; }
	    template<typename number> number operator^ (const number& a) const { return x ^ a; }
	    template<typename number> number operator| (const number& a) const { return x | a; }
	    template<typename number> number operator& (const number& a) const { return x & a; }
	    template<typename number> number operator&&(const number& a) const { return x &&a; }
	    template<typename number> number operator||(const number& a) const { return x ||a; }
    	template<typename number> number operator~() const                 { return ~x;    }
    	template<typename number> number operator!() const                 { return !x;    }
    
    protected:
	    template<typename number> number operator= (const number& a) { return x =  a; }
	    template<typename number> number operator+=(const number& a) { return x += a; }      
	    template<typename number> number operator-=(const number& a) { return x -= a; }
	    template<typename number> number operator*=(const number& a) { return x *= a; }
	    template<typename number> number operator/=(const number& a) { return x /= a; }
	    template<typename number> number operator&=(const number& a) { return x &= a; }
	    template<typename number> number operator|=(const number& a) { return x |= a; }
};

template<typename T>
class read_func
{
	private:
		std::function<T()> x;
		
	public:
		read_func(){x=[=](){return T();};}
		read_func(std::function<T()> fun){x=fun;}
		read_func(T y){x=[=](){return y;};}
	
	public:
		void bind(std::function<T()> fun){x=fun;}

	public:
	    operator T() const { return x(); }
	    template<typename number> bool   operator==(const number& a) const { return x() ==a; } 
	    template<typename number> number operator+ (const number& a) const { return x() + a; } 
	    template<typename number> number operator- (const number& a) const { return x() - a; } 
	    template<typename number> number operator* (const number& a) const { return x() * a; }  
	    template<typename number> number operator/ (const number& a) const { return x() / a; } 
	    template<typename number> number operator<<(const number& a) const { return x() <<a; }
	    template<typename number> number operator>>(const number& a) const { return x() >>a; }
	    template<typename number> number operator^ (const number& a) const { return x() ^ a; }
	    template<typename number> number operator| (const number& a) const { return x() | a; }
	    template<typename number> number operator& (const number& a) const { return x() & a; }
	    template<typename number> number operator&&(const number& a) const { return x() &&a; }
	    template<typename number> number operator||(const number& a) const { return x() ||a; }
    	template<typename number> number operator~() const                 { return ~x();    }
    	template<typename number> number operator!() const                 { return !x();    }
};

}
