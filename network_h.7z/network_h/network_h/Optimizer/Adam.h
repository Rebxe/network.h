#pragma once

namespace network
{

class ADAM : public Opti_Base
{
public:
	read_only<bool,ADAM> built;
	float lrt,b1,b2,w_de,eps;
	
private:
	int m;
	float mb1,mb2;
	float *v,*s;
	
private:
	void chk(const char* type,const char* name)
	{
		ext_assert(built,
			fprintf(stderr,"\
In %s ADAM::%s\n\
  this hasn't been initalized yet\n\n",type,name));
	}

public:
	void clear_grad()
	{
		chk("void","clear_grad()");
		for(auto x:para.dat) memset(x.grad,0,sizeof(float)*x.cnt);
	}
	void step()
	{
		chk("void","step()");
		mb1*=b1,mb2*=b2;
		int p=0;
		for(auto x:para.dat)
			for(int i=0;i<x.cnt;i++)
			{
				float g=x.grad[i];
				v[p]=b1*v[p]+(1-b1)*g;
				s[p]=b2*s[p]+(1-b2)*g*g;
				float vh=v[p]/(1-mb1),sh=s[p]/(1-mb2); 
				x.wei[i]-=lrt*vh/(sqrt(sh)+eps);
				x.wei[i]-=lrt*w_de*x.wei[i];
				p++;
			}
	}
	
public:
	void save(std::ofstream &ouf)
	{
		if(!built) return;
		writf(ouf,lrt);
		writf(ouf,b1),writf(ouf,b2),writf(ouf,w_de),writf(ouf,eps);
		writf(ouf,mb1),writf(ouf,mb2);
		writf(ouf,v,m),writf(ouf,s,m);
	}
	void load(std::ifstream &inf)
	{
		if(!built) return;
		readf(inf,lrt);
		readf(inf,b1),readf(inf,b2),readf(inf,w_de),readf(inf,eps);
		readf(inf,mb1),readf(inf,mb2);
		readf(inf,v,m),readf(inf,s,m);
	}
	void delthis(){if(built) para.clear(),delete[] v,delete[] s,built=false;}

public:
	ADAM(){built=false,v=0,s=0;}
	ADAM(Parameter parameter,float Learn_Rate,float beta1=0.9,float beta2=0.999,float weight_decay=0,float Eps=1e-8)
	{
		ext_assert(parameter.size()>0,
			fprintf(stderr,"\
In ADAM::ADAM(Parameter parameter,float Learn_Rate,float beta1=0.9,float beta2=0.999,float weight_decay=0,float Eps=1e-8)\n\
  parameter is empty\n\n"));
		built=true;
		para=parameter;
		lrt=Learn_Rate;
		b1=beta1,b2=beta2,w_de=weight_decay,eps=Eps;
		m=para.size();
		mb1=1,mb2=1;
		v=new float[m],s=new float[m];
		memset(v,0,sizeof(float)*m),memset(s,0,sizeof(float)*m);
	}
};

}
