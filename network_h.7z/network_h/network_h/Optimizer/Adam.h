#pragma once

namespace network
{

	class ADAM : public Opti_Base
	{
	public:
		read_only<bool, ADAM> built;
		double lrt, b1, b2, w_de, eps;

	private:
		double mb1, mb2;
		std::vector<af::array*> v, s;

	private:
		void chk(const char* type, const char* name)
		{
			ext_assert(built, fprintf(stderr, "\
In %s ADAM::%s\n\
  this hasn't been initalized yet\n\n", type, name));
		}

	public:
		void clear_grad()
		{
			chk("void", "clear_grad()");
			for (auto x : para) *x.second = 0;
		}
		void step()
		{
			chk("void", "step()");
			mb1 *= b1, mb2 *= b2;
			for (int i = 0; i < para.size(); i++)
			{
				af::array& w = *para[i].first;
				af::array& g = *para[i].second;
				af::array& vi = *v[i];
				af::array& si = *s[i];
				vi = b1 * vi + (1 - b1) * g;
				si = b2 * si + (1 - b2) * g * g;
				vi.eval(), si.eval();
				af::array vh = vi / (1 - mb1), sh = si / (1 - mb2);
				w -= lrt * vh / (af::sqrt(sh) + eps);
				w -= lrt * w_de * w;
				w.eval();
			}
		}

	public:
		void save(std::ofstream& ouf)
		{
			if (!built) return;
			writf(ouf, lrt);
			writf(ouf, b1), writf(ouf, b2), writf(ouf, w_de), writf(ouf, eps);
			writf(ouf, mb1), writf(ouf, mb2);
			for (int i = 0; i < para.size(); i++) writf(ouf, *v[i]), writf(ouf, *s[i]);
		}
		void load(std::ifstream& inf)
		{
			if (!built) return;
			readf(inf, lrt);
			readf(inf, b1), readf(inf, b2), readf(inf, w_de), readf(inf, eps);
			readf(inf, mb1), readf(inf, mb2);
			for (int i = 0; i < para.size(); i++) readf(inf, *v[i]), readf(inf, *s[i]);
		}
		void delthis()
		{
			if (built)
			{
				for (int i = 0; i < para.size(); i++) delete v[i], delete s[i];
				Parameters().swap(para);
			}
			built = false;
		}

	public:
		ADAM() { built = false; }
		ADAM(Parameters parameter, float Learn_Rate, float beta1 = 0.9, float beta2 = 0.999, float weight_decay = 0, float Eps = 1e-8)
		{
			ext_assert(parameter.size() > 0, fprintf(stderr, "\
In ADAM::ADAM(Parameters parameter, float Learn_Rate, float beta1, float beta2, float weight_decay, float Eps)\n\
  parameter is empty\n\n"));
			built = true;
			para = parameter;
			lrt = Learn_Rate;
			b1 = beta1, b2 = beta2, w_de = weight_decay, eps = Eps;
			mb1 = 1, mb2 = 1;
			v = std::vector<af::array*>(para.size()), s = std::vector<af::array*>(para.size());
			for (int i = 0; i < para.size(); i++)
			{
				v[i] = new af::array(para[i].first->dims(), para[i].first->type());
				s[i] = new af::array(para[i].first->dims(), para[i].first->type());
				*v[i] = 0, * s[i] = 0;
			}
		}

	public:
		ADAM& operator=(const ADAM& y)
		{
			delthis();
			para = y.para;
			built = y.built;
			lrt = y.lrt, b1 = y.b1, b2 = y.b2, w_de = y.w_de, eps = y.eps;
			mb1 = y.mb1, mb2 = y.mb2;
			v = y.v, s = y.s;
			return *this;
		}
	};

}
