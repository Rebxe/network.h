#pragma once

namespace network
{

class SGD : Opti_Base 
{
public:
	read_only<bool,SGD> built;
	float lrt;
	
private:
	void chk(const char* type,const char* name)
	{
		ext_assert(built,
			fprintf(stderr,"\
In %s SGD::%s\n\
  this hasn't been initalized yet\n\n",type,name));
	}

public:
	void clear_grad()
	{
		chk("void","clear_grad()");
		for(auto x:para.dat) memset(x.grad,0,sizeof(float)*x.cnt);
	}
	void step()
	{
		chk("void","step()");
		for(auto x:para.dat) for(int i=0;i<x.cnt;i++) x.wei[i]-=lrt*x.grad[i];
	}

public:
	void save(std::ofstream &ouf){if(built) writf(ouf,lrt);}
	void load(std::ifstream &inf){if(built) readf(inf,lrt);}
	void delthis(){para.clear(),built=false;}
	
public:
	SGD(){built=false;}
	SGD(Parameter parameter,float Learn_Rate)
	{
		ext_assert(parameter.size()>0,
			fprintf(stderr,"\
In SGD::SGD(Parameter parameter,float Learn_Rate)\n\
  parameter is empty\n\n"));
		built=true;
		para=parameter;
		lrt=Learn_Rate;
	}
};

}
