#pragma once

namespace network
{

	class SGD : Opti_Base
	{
	public:
		read_only<bool, SGD> built;
		double lrt;

	private:
		void chk(const char* type, const char* name)
		{
			ext_assert(built,fprintf(stderr, "\
In %s SGD::%s\n\
  this hasn't been initalized yet\n\n", type, name));
		}

	public:
		void clear_grad()
		{
			chk("void", "clear_grad()");
			for (auto x : para) *x.second = 0;
		}
		void step()
		{
			chk("void", "step()");
			for (int i = 0; i < para.size(); i++)
			{
				af::array& w = *para[i].first;
				af::array& g = *para[i].second;
				w -= lrt * g;
				w.eval();
			}
		}

	public:
		void save(std::ofstream& ouf) { if (built) writf(ouf, lrt); }
		void load(std::ifstream& inf) { if (built) readf(inf, lrt); }
		void delthis() { Parameters().swap(para), built = false; }

	public:
		SGD() { built = false; }
		SGD(Parameters parameters, double Learn_Rate)
		{
			ext_assert(parameters.size() > 0, fprintf(stderr, "\
In SGD::SGD(Parameters parameters, double Learn_Rate)\n\
  parameter is empty\n\n"));
			built = true;
			para = parameters;
			lrt = Learn_Rate;
		}

	public:
		SGD& operator=(const SGD& y)
		{
			delthis();
			para = y.para;
			built = y.built;
			lrt = y.lrt;
			return *this;
		}
	};

}