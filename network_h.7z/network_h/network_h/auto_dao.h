#pragma once

namespace network
{

namespace auto_dao
{
	void Data_Node::freemem()
	{
		if(pdata!=0) delete[] pdata;
		if(pgrad!=0) delete[] pgrad;
		pdata=pgrad=0;
	}
	
	OP_Base* Data_Node::getfa(){return fa;}
	float4d Data_Node::data(){return float4d(n,d,h,w,pdata);}
	float4d Data_Node::grad()
	{
		if(pgrad==0)
		{
			pgrad=new float[n*d*h*w];
			memset(pgrad,0,sizeof(float)*n*d*h*w);
		}
		return float4d(n,d,h,w,pgrad);
	}
	
	void Data_Node::clearop(){input.clear(),backward_f.clear(),outd=0;}
	void Data_Node::regop(std::vector<Data_Node*> Input,type_backward_f Backward_f) // not inplace
	{
		ext_assert(backward_f.empty(),
			fprintf(stderr,"\
In void Data_Node::regop(std::vector<Data_Node*> Input,type_backward_f Backward_f)\n\
  there can't be more than one not inplace operator\n\n"));
		input=Input;
		for(Data_Node* x:input) x->outd++;
		backward_f.push_back(Backward_f);
	}
	void Data_Node::addop(type_backward_f Backward_f) // inplace
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void Data_Node::addop(type_backward_f Backward_f)\n\
  Inplace mode is not allowed for train_able item\n\n"));
		ext_assert(outd==0,
			fprintf(stderr,"\
In void Data_Node::addop(type_backward_f Backward_f)\n\
  this should not be used before an inplace operation\n\n"));
		backward_f.push_back(Backward_f);
	}
	void Data_Node::backward()
	{
		ext_assert(!fa->eval,
			fprintf(stderr,"\
In void auto_dao::Data_Node::backward()\n\
  Backward is disabled in eval mode\n\n"));
		while(!backward_f.empty()) backward_f.back()(input,this),backward_f.pop_back();
		if(!train&&fa->deltmp) freemem();
		for(Data_Node* x:input) if(--x->outd==0) x->backward();
	}
	
	void Data_Node::toshape(shape4d shape)
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void auto_dao::Data_Node::toshape(shape4d shape)\n\
  this function is disabled for train-able item"));
		int _n=shape[0],_d=shape[1],_h=shape[2],_w=shape[3];
		ext_assert(_n*_d*_h*_w==n*d*h*w,
			fprintf(stderr,"\
In void auto_dao::Data_Node::toshape(shape4d shape)\n\
  Before = [%d * %d * %d * %d]\n\
  To     = [%d * %d * %d * %d]\n\
But\n\
  %d * %d * %d * %d = %d\n\
is not equal to\n\
  %d * %d * %d * %d = %d\n\n",n,d,h,w,_n,_d,_h,_w,n,d,h,w,n*d*h*w,_n,_d,_h,_w,_n*_d*_h*_w));
		n=_n,d=_d,h=_h,w=_w;
	}
	void Data_Node::sdim(const char* from,const char* to)
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  this function is disabled for train-able item"));
  		ext_assert(strlen(from)==4&&strlen(to)==4,
			fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  length of 'from' and length of 'to' should equal to 4\n\n",from,to));
#ifndef NDEBUG
	for(int i=0;i<4;i++)
		for(int j=i+1;j<4;j++)
			ext_assert(from[i]!=from[j],
				fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' appears more than once in \"%s\"\n\n",from,to,from[i],from));
#endif
  		int p[4]={-1,-1,-1,-1};
  		for(int i=0;i<4;i++)
  		{
  			for(int j=0;j<4&&p[i]==-1;j++) if(to[i]==from[j]) p[i]=j;
  			ext_assert(p[i]!=-1,
				fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' in \"%s\" does not appear in \"%s\"\n\n",from,to,to[i],to,from));
		}
		int tp[4]={n,d,h,w};
		mem_pool::getmem(n*d*h*w);
		float4d tmp(tp[p[0]],tp[p[1]],tp[p[2]],tp[p[3]],mem_pool::shared_memory);
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
					{
						int tp[4]={i,j,k,l};
						tmp[tp[p[0]]][tp[p[1]]][tp[p[2]]][tp[p[3]]]=data()[i][j][k][l]; 
					}
		memcpy(data(),tmp,sizeof(float)*tmp.size());
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
					{
						int tp[4]={i,j,k,l};
						tmp[tp[p[0]]][tp[p[1]]][tp[p[2]]][tp[p[3]]]=grad()[i][j][k][l]; 
					}
		memcpy(grad(),tmp,sizeof(float)*tmp.size());
		n=tp[p[0]],d=tp[p[1]],h=tp[p[2]],w=tp[p[3]];
	}
	
	Data_Node::Data_Node(OP_Base* fap,shape4d shape)
	{
		train=false;
		n=shape[0],d=shape[1],h=shape[2],w=shape[3];
		fa=fap;
		pdata=new float[n*d*h*w],pgrad=0;
		outd=0;
	}
	Data_Node::Data_Node(OP_Base* fap,shape3d shape)
	{
		train=true;
		n=1,d=shape[0],h=shape[1],w=shape[2];
		fa=fap;
		pdata=new float[n*d*h*w],pgrad=new float[n*d*h*w];
		outd=0;
	}
	Data_Node::~Data_Node(){freemem();}
}

}

#include "auto_dao/val4d.h"
#include "auto_dao/wei3d.h"
#include "auto_dao/operators.h"
