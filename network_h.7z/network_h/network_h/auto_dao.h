#pragma once

namespace network
{

namespace auto_dao
{
	void Data_Node::freemem()
	{
		if(pdata!=0) delete[] pdata;
		if(pgrad!=0) delete[] pgrad;
		pdata=pgrad=0;
	}
	
	OP_Base* Data_Node::getfa(){return fa;}
	float4d Data_Node::data(){return float4d(n,d,h,w,pdata);}
	float4d Data_Node::grad()
	{
		if(pgrad==0)
		{
			pgrad=new float[n*d*h*w];
			memset(pgrad,0,sizeof(float)*n*d*h*w);
		}
		return float4d(n,d,h,w,pgrad);
	}
	
	void Data_Node::clearop(){input.clear(),backward_f.clear(),outd=0;}
	void Data_Node::regop(std::vector<Data_Node*> Input,type_backward_f Backward_f) // not inplace
	{
		ext_assert(backward_f.empty(),
			fprintf(stderr,"\
In void Data_Node::regop(std::vector<Data_Node*> Input,type_backward_f Backward_f)\n\
  there can't be more than one not inplace operator\n\n"));
		input=Input;
		for(Data_Node* x:input) x->outd++;
		backward_f.push_back(Backward_f);
	}
	void Data_Node::addop(type_backward_f Backward_f) // inplace
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void Data_Node::addop(type_backward_f Backward_f)\n\
  Inplace mode is not allowed for train_able item\n\n"));
		ext_assert(outd==0,
			fprintf(stderr,"\
In void Data_Node::addop(type_backward_f Backward_f)\n\
  this should not be used before an inplace operation\n\n"));
		backward_f.push_back(Backward_f);
	}
	void Data_Node::backward()
	{
		ext_assert(!fa->eval,
			fprintf(stderr,"\
In void auto_dao::Data_Node::backward()\n\
  Backward is disabled in eval mode\n\n"));
		while(!backward_f.empty()) backward_f.back()(input,this),backward_f.pop_back();
		if(!train&&fa->deltmp) freemem();
		for(Data_Node* x:input) if(--x->outd==0) x->backward();
	}
	
	void Data_Node::toshape(shape4d shape)
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void auto_dao::Data_Node::toshape(shape4d shape)\n\
  this function is disabled for train-able item"));
		int _n=shape[0],_d=shape[1],_h=shape[2],_w=shape[3];
		ext_assert(_n*_d*_h*_w==n*d*h*w,
			fprintf(stderr,"\
In void auto_dao::Data_Node::toshape(shape4d shape)\n\
  Before = [%d * %d * %d * %d]\n\
  To     = [%d * %d * %d * %d]\n\
But\n\
  %d * %d * %d * %d = %d\n\
is not equal to\n\
  %d * %d * %d * %d = %d\n\n",(int)n,(int)d,(int)h,(int)w,_n,_d,_h,_w,(int)n,(int)d,(int)h,(int)w,(int)n*d*h*w,_n,_d,_h,_w,_n*_d*_h*_w));
		n=_n,d=_d,h=_h,w=_w;
	}
	void Data_Node::sdim(const char* from,const char* to)
	{
		ext_assert(!train,
			fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  this function is disabled for train-able item"));
  		ext_assert(strlen(from)==4&&strlen(to)==4,
			fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  length of 'from' and length of 'to' should equal to 4\n\n",from,to));
#ifndef NDEBUG
	for(int i=0;i<4;i++)
		for(int j=i+1;j<4;j++)
			ext_assert(from[i]!=from[j],
				fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' appears more than once in \"%s\"\n\n",from,to,from[i],from));
#endif
  		int p[4]={-1,-1,-1,-1};
  		for(int i=0;i<4;i++)
  		{
  			for(int j=0;j<4&&p[i]==-1;j++) if(to[i]==from[j]) p[i]=j;
  			ext_assert(p[i]!=-1,
				fprintf(stderr,"\
In void auto_dao::Data_Node::sdim(const char* from,const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' in \"%s\" does not appear in \"%s\"\n\n",from,to,to[i],to,from));
		}
		//  from DeepSeek
	    const int total_elements = n * d * h * w;
	    const int original_dims[4] = {n, d, h, w};
	    const int new_dims[4] = {original_dims[p[0]], original_dims[p[1]], original_dims[p[2]], original_dims[p[3]]};
	
	    // �����ڴ� 
		mem_pool::getmem(total_elements);
	
	    // ����ԭʼά�ȵĲ�����strides��
	    const int original_strides[4] = {
	        d * h * w,  // n�Ĳ���
	        h * w,      // d�Ĳ���
	        w,          // h�Ĳ���
	        1           // w�Ĳ���
	    };
	
	    // ����Ŀ��ά�ȵĲ���������new_dims��
	    const int new_strides[4] = {
	        new_dims[1] * new_dims[2] * new_dims[3],  // ��n�Ĳ���
	        new_dims[2] * new_dims[3],                // ��d�Ĳ���
	        new_dims[3],                              // ��h�Ĳ���
	        1                                         // ��w�Ĳ���
	    };
	
	    // ��������ӳ�亯�����޸�ԭ�����жϴ���
	    auto get_mapped_index = [&](int i, int j, int k, int l) -> int {
	        int mapped_coords[4];
	        mapped_coords[0] = i;  // ԭn������
	        mapped_coords[1] = j;  // ԭd������
	        mapped_coords[2] = k;  // ԭh������
	        mapped_coords[3] = l;  // ԭw������
	        // ��pӳ�䵽��ά��˳��
	        const int new_i = mapped_coords[p[0]];
	        const int new_j = mapped_coords[p[1]];
	        const int new_k = mapped_coords[p[2]];
	        const int new_l = mapped_coords[p[3]];
	        // ����Ŀ����������
	        return new_i * new_strides[0] + new_j * new_strides[1] + new_k * new_strides[2] + new_l;
	    };
	
	    // ����data��grad
	    auto process = [&](float* src, float* dst) {
	        #pragma omp parallel for collapse(4)
	        for (int i = 0; i < n; ++i) {
	            for (int j = 0; j < d; ++j) {
	                for (int k = 0; k < h; ++k) {
	                    for (int l = 0; l < w; ++l) {
	                        // ����ԭʼ��������
	                        const int src_idx = i * original_strides[0] + j * original_strides[1] + k * original_strides[2] + l;
	                        // ����Ŀ�������������޸��˴��߼���
	                        const int dst_idx = get_mapped_index(i, j, k, l);
	                        dst[dst_idx] = src[src_idx];
	                    }
	                }
	            }
	        }
	    };
	    
	    process(pdata, mem_pool::shared_memory);
	    memcpy(pdata, mem_pool::shared_memory, sizeof(float)*total_elements);
	    if (pgrad!=0)
		{
			process(pgrad, mem_pool::shared_memory);
	    	memcpy(pgrad, mem_pool::shared_memory, sizeof(float)*total_elements);
		}
	
	    // ����ά��
	    n = new_dims[0];
	    d = new_dims[1];
	    h = new_dims[2];
	    w = new_dims[3];
	}
	
	Data_Node::Data_Node(OP_Base* fap,shape4d shape)
	{
		train=false;
		n=shape[0],d=shape[1],h=shape[2],w=shape[3];
		fa=fap;
		pdata=new float[n*d*h*w],pgrad=0;
		outd=0;
	}
	Data_Node::Data_Node(OP_Base* fap,shape3d shape)
	{
		train=true;
		n=1,d=shape[0],h=shape[1],w=shape[2];
		fa=fap;
		pdata=new float[n*d*h*w],pgrad=new float[n*d*h*w];
		outd=0;
	}
	Data_Node::~Data_Node(){freemem();}
}

}

#include "auto_dao/val4d.h"
#include "auto_dao/wei3d.h"

namespace network
{
	
namespace auto_dao
{
	class Data
	{
		private:
			Data_Node* x;
			
		public:
			using type_backward_f=Data_Node::type_backward_f;
			
		public:
			operator Data_Node&()const{return *x;}
			operator Data_Node*()const{return x;}
		
		public:
			read_func<bool> train;
			read_func<int> n,d,h,w;
			
		private:
			bool gettrain(){return x->train;}
			int getn(){return x->n;}
			int getd(){return x->d;}
			int geth(){return x->h;}
			int getw(){return x->w;}
			void bindfunc()
			{
				train.bind(std::bind(&Data::gettrain,this));
				n.bind(std::bind(&Data::getn,this));
				d.bind(std::bind(&Data::getd,this));
				h.bind(std::bind(&Data::geth,this));
				w.bind(std::bind(&Data::getw,this)); 
			}
			
		public:
			OP_Base* getfa(){return x->getfa();}
			float4d data(){return x->data();}
			float4d grad(){return x->grad();}
		
		public:
			void clearop(){x->clearop();}
			void regop(std::vector<Data_Node*> Input,type_backward_f Backward_f) // not inplace
			{
				x->regop(Input,Backward_f); 
			}
			void addop(type_backward_f Backward_f) // inplace
			{
				x->addop(Backward_f);
			}
			void backward(){x->backward();}
		
		public:
			void toshape(shape4d shape){x->toshape(shape);}
			void sdim(const char* from,const char* to){x->sdim(from,to);}
		
		public:
			Data(Data_Node& y){x=&y,bindfunc();}
			Data(val4d& y){x=&y.getdat(),bindfunc();}
			Data(wei3d& y){x=&y.getdat(),bindfunc();}
			Data(val4d* y){x=&y->getdat(),bindfunc();}
			Data(wei3d* y){x=&y->getdat(),bindfunc();}
		
		public:
			Data& operator=(const Data& y){return x=y.x,*this;}
	};
}

}

#include "auto_dao/operators.h"
