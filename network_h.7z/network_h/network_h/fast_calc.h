#pragma once

#include "OS_Headers/Eigen/Eigen"

namespace network
{

//float expf_fast(float x)
//{
//	return exp(x);
//	float d;
//    *(reinterpret_cast<short*>(&d) + 0) = 0;
//    *(reinterpret_cast<short*>(&d) + 1) = static_cast<short>(184 * x + (16256-7));
//    return d;
//}

inline float expf_fast(float x) {
	if(x < -256) return 0;
	if(x > 15) return 1e5;
	x = 1.0 + x / 256.0;
	x *= x; x *= x; x *= x; x *= x;
	x *= x; x *= x; x *= x; x *= x;
	return x;
}

//inline float expf_fast(float x)
//{
//    union {uint32_t i;float f;} v;
//    v.i=(1<<23)*(1.4426950409*x+126.94201519f);
//    return v.f;
//}

#ifdef ENABLE_GPU
	#define VIENNACL_WITH_OPENCL
	#define VIENNACL_WITH_EIGEN
	#include "viennacl/matrix.hpp"
	/*
		A: N*M
		B: M*K
		C: N*K
	*/
	void Matrix_Mul(int N, int M, int K,
		float* A, bool ta, // A or A^T
		float* B, bool tb, // B or B^T
		float* C)          // C
	{
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > a(A, !ta ? N : M, !ta ? M : N);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > b(B, !tb ? M : K, !tb ? K : M);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > c(C, N, K);
		viennacl::matrix<float> gpu_a(!ta ? N : M, !ta ? M : N);
		viennacl::matrix<float> gpu_b(!tb ? M : K, !tb ? K : M);
		viennacl::matrix<float> gpu_c(N, K);
		viennacl::copy(a, gpu_a);
		viennacl::copy(b, gpu_b);
		viennacl::copy(c, gpu_c);
		gpu_c += viennacl::linalg::prod(
			!ta ? gpu_a : viennacl::trans(gpu_a),
			!tb ? gpu_b : viennacl::trans(gpu_b)
		);
		viennacl::copy(gpu_c, c);
	}
#else
	// A: N*M
	// B: M*K
	// C: N*K
	void Matrix_Mul(int N, int M, int K,
		float* A, bool ta, // A or A^T
		float* B, bool tb, // B or B^T
		float* C)          // C
	{
		typedef Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> MatrixType;
		Eigen::Map<const MatrixType> a(A, !ta ? N : M, !ta ? M : N);
		Eigen::Map<const MatrixType> b(B, !tb ? M : K, !tb ? K : M);
		Eigen::Map<MatrixType> c(C, N, K);
		if (!ta && !tb)   c.noalias() += a * b;
		else if (ta&&!tb) c.noalias() += a.transpose() * b;
		else if (!ta&&tb) c.noalias() += a * b.transpose();
		else if (ta&&tb)  c.noalias() += a.transpose() * b.transpose();
	}
#endif

}
