#pragma once

// 1D ~ 4D float container

namespace network
{

class float1d
{
	public:
		const int w;
		float* a;
	
	public:
		float& operator[](int x)
		{
			ext_assert(0<=x&&x<w,fprintf(stderr,"\
In float1d::operator[](int x)\
  x = %d is out of range[0,%d]\n\n",x,w-1));
  			return a[x];
		}
		operator float*(){return a;}
			
	public:
		float1d(int _w,float* _a):w(_w){a=_a;}
		int size(){return w;}
};

class float2d
{
	public:
		const int h,w;
		float* a;
	
	public:
		float1d operator[](int x)
		{
			ext_assert(0<=x&&x<h,fprintf(stderr,"\
In float2d::operator[](int x)\
  x = %d is out of range[0,%d]\n\n",x,h-1));
  			return float1d(w,a+x*w);
		}
		operator float*(){return a;}
			
	public:
		float2d(int _h,int _w,float* _a):h(_h),w(_w){a=_a;}
		int size(){return h*w;}
};

class float3d
{
	public:
		const int d,h,w;
		float* a;
	
	public:
		float2d operator[](int x)
		{
			ext_assert(0<=x&&x<d,fprintf(stderr,"\
In float3d::operator[](int x)\
  x = %d is out of range[0,%d]\n\n",x,d-1));
  			return float2d(h,w,a+x*h*w);
		}
		operator float*(){return a;}
			
	public:
		float3d(int _d,int _h,int _w,float* _a):d(_d),h(_h),w(_w){a=_a;}
		int size(){return d*h*w;}
};

class float4d
{
	public:
		const int n,d,h,w;
		float* a;
	
	public:
		float3d operator[](int x)
		{
			ext_assert(0<=x&&x<n,fprintf(stderr,"\
In float4d::operator[](int x)\
  x = %d is out of range[0,%d]\n\n",x,n-1));
  			return float3d(d,h,w,a+x*d*h*w);
		}
		operator float*(){return a;}
			
	public:
		float4d(int _n,int _d,int _h,int _w,float* _a):n(_n),d(_d),h(_h),w(_w){a=_a;}
		int size(){return n*d*h*w;}
};

}
