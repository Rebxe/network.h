#pragma once

// Batch Normalization Layer

namespace network
{

	class BN : public OP_Base
	{
	public:
		read_only<bool, BN> built;
		read_only<int, BN> dim;
		read_only<dim_t, BN> siz;
		read_only<double, BN> delta, eps; // avg_x=avg_x*delta+pre_x*(1-delta)
		read_only<bool, BN> inplace;

	private:
		af::array *e_avg, *e_var; // Expect_avg, Expect_variance
		af::array *k, *b;
		af::array *k_grad, *b_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built)
			{
				writf(ouf, *e_avg), writf(ouf, *e_var);
				writf(ouf, *k), writf(ouf, *b);
			}
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built)
			{
				readf(inf, *e_avg), readf(inf, *e_var);
				readf(inf, *k), readf(inf, *b);
			}
			auto_load(inf);
		}
		void delthis()
		{
			if (built)
			{
				delete e_avg, delete e_var;
				delete k, delete b;
				delete k_grad, delete b_grad;
			}
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype BN::type() const\n\
  this hasn't been initalized yet\n\n"));
			return k->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* BN::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(dim) == siz, fprintf(stderr, "\
In val4d* BN::operator()(auto_grad::Data x)\n\
  dim = %d\n\
  siz = %lld\n\
but\n\
  x = [%lld * %lld * %lld * %lld]\n\n",
				(int)dim,
				(long long)siz,
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			val4d* resp;
			if (!inplace) resp = tmp<val4d>(x.dims(), x.type());
			else		  resp = x.getfa()->tmp<val4d>(x);
			auto_grad::Data res = resp;
			af::array tmp_data;
			if (inplace) tmp_data = x.data();
			// forward
			dim_t div = x.elements() / siz;
			af::array avg, var;
			auto sum2 = [&](const auto& x) {
				af::array tmp = af::sum(x, 3);
				if (dim != 0) tmp = af::sum(tmp, 0);
				if (dim != 1) tmp = af::sum(tmp, 1);
				if (dim != 2) tmp = af::sum(tmp, 2);
				return tmp;
				};
			if (!eval)
			{
				avg = sum2(x.data()) / div;
				var = sum2((x.data() - avg) * (x.data() - avg)) / div;
				*e_avg = *e_avg * delta + avg * (1 - delta);
				*e_var = *e_var * delta + var * (1 - delta);
			}
			else avg = *e_avg, var = *e_var;
			af::array xh = (x.data() - avg) / af::sqrt(var + eps);
			res.data() = *k * xh + *b;
			// backward
			if (!inplace)
			{
				res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = in[0];
					auto_grad::Data res = out;
					*k_grad += sum2(xh * res.grad());
					*b_grad += sum2(res.grad());
					af::array dL_dxh = res.grad() * *k;
					af::array dL_dvar = -sum2(dL_dxh * (x.data() - avg) / (2 * af::pow(var + eps, 1.5)));
					af::array dvar_davg = sum2(avg - x.data()) * 2 / div;
					af::array dL_davg = dL_dvar * dvar_davg - sum2(dL_dxh / af::sqrt(var + eps));
					af::array dvar_dx = (x.data() - avg) * 2 / div;
					x.grad() += dL_dxh / af::sqrt(var + eps) + dL_davg / div + dL_dvar * dvar_dx;
					});
			}
			else
			{
				res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = out;
					x.data() = tmp_data;
					*k_grad += sum2(xh * x.grad());
					*b_grad += sum2(x.grad());
					af::array dL_dxh = x.grad() * *k;
					af::array dL_dvar = -sum2(dL_dxh * (x.data() - avg) / (2 * af::pow(var + eps, 1.5)));
					af::array dvar_davg = sum2(avg - x.data()) * 2 / div;
					af::array dL_davg = dL_dvar * dvar_davg - sum2(dL_dxh / af::sqrt(var + eps));
					af::array dvar_dx = (x.data() - avg) * 2 / div;
					x.grad() = dL_dxh / af::sqrt(var + eps) + dL_davg / div + dL_dvar * dvar_dx;
					});
			}
			return resp;
		}

	public:
		BN() { built = false; }
		BN(OP_Base* fap, int Dim, dim_t Siz, bool Inplace = false, double Delta = 0.9, double EPS = 1e-4, af::dtype type = f32) :OP_Base(fap)
		{
			ext_assert(0 <= Dim && Dim <= 2, fprintf(stderr, "\
In BN::BN(OP_Base* fap, int Dim, dim_t Siz, bool Inplace, double Delta, double EPS, af::dtype type)\n\
  Dim = %d is out of range [0,2]\n\n", Dim));
			built = true;
			dim = Dim, siz = Siz;
			delta = Delta, eps = EPS;
			inplace = Inplace;
			af::dim4 ndim = { 1,1,1,1 };
			ndim[dim] = siz;
			e_avg = new af::array(ndim), e_var = new af::array(ndim);
			k = new af::array(ndim), b = new af::array(ndim);
			k_grad = new af::array(ndim), b_grad = new af::array(ndim);
			reg_para(k, k_grad);
			reg_para(b, b_grad);
			// init wei
			*e_avg = 0, * e_var = 1;
			*k = 1, * b = 0;
		}
	};

}