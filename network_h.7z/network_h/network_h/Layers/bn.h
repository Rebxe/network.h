#pragma once

// Batch Normalization Layer

namespace network
{

class BN : public OP_Base
{
public:
	read_only<bool,BN> built;
	read_only<int,BN> d,h,w;
	read_only<float,BN> delta, eps; // avg_x=avg_x*delta+pre_x*(1-delta)
	
private:
	float *e_avg,*e_var; // Expect_avg, Expect_variance
	float *t_avg,*t_var;
	float *k,*b;
	float *k_grad,*b_grad;

private:
	void forward(auto_dao::Data_Node& in,auto_dao::Data_Node& out)
	{
		int n=in.n;
		ext_assert(d==in.d&&h==in.h&&w==in.w,
			fprintf(stderr,"\
In val4d* BN::operator()(auto_dao::Data_Node& x)\n\
  shape = [%d * %d * %d]\n\
but\n\
  x = [%d * %d * %d * %d]\n\n",d,h,w,in.n,in.d,in.h,in.w));
  		float4d ina=in.data(),outa=out.data();
		for(int i=0;i<d;i++)
		{
			if(eval)
			{
				float s=sqrt(e_var[i]+eps);
				for(int t=0;t<h*w;t++) outa[0][i].a[t]=k[i]*(ina[0][i].a[t]-e_avg[i])/s+b[i];
			}
			else
			{
				float &avg=t_avg[i],&var=t_var[i];
				avg=var=0;
				for(int j=0;j<n;j++) for(int t=0;t<h*w;t++) avg+=ina[j][i].a[t];
				avg/=n*h*w;
				for(int j=0;j<n;j++) for(int t=0;t<h*w;t++) var+=pow(ina[j][i].a[t]-avg,2);
				var/=n*h*w;
				float s=sqrt(var+eps);
				for(int j=0;j<n;j++)
					for(int t=0;t<h*w;t++)
						outa[j][i].a[t]=k[i]*(ina[j][i].a[t]-avg)/s+b[i];
				e_avg[i]=e_avg[i]*delta+avg*(1-delta);
				e_var[i]=e_var[i]*delta+var*(1-delta);
			}
		}
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		int n=inp->n;
  		float4d ina=inp->data();
  		float4d ing=inp->grad(),outg=out->grad();
		for(int i=0;i<d;i++)
		{
			float avg=t_avg[i],var=t_var[i];
			float s=sqrt(var+eps),s2=pow(var+eps,1.5)*2;
			for(int j=0;j<n;j++)
				for(int t=0;t<h*w;t++) k_grad[i]+=outg[j][i].a[t]*(ina[j][i].a[t]-avg)/s;
			for(int j=0;j<n;j++)
				for(int t=0;t<h*w;t++) b_grad[i]+=outg[j][i].a[t];
			float dL_davg=0,dL_dvar=0,dvar_davg=0;
			for(int j=0;j<n;j++)
				for(int t=0;t<h*w;t++)
				{
					float dL_dhx=outg[j][i].a[t]*k[i];
					ing[j][i].a[t]+=dL_dhx/s;
					dL_davg-=dL_dhx/s;
					dL_dvar-=dL_dhx*(ina[j][i].a[t]-avg)/s2;
					dvar_davg+=2/(float)(n*h*w)*(avg-ina[j][i].a[t]);
				}
			dL_davg+=dL_dvar*dvar_davg;
			for(int j=0;j<n;j++)
				for(int t=0;t<h*w;t++)
					ing[j][i].a[t]+=(dL_davg+dL_dvar*2*(ina[j][i].a[t]-avg))/(float)(n*h*w);
		}
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built)
		{
			writf(ouf,e_avg,d),writf(ouf,e_var,d);
			writf(ouf,k,d),writf(ouf,b,d);
		}
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built)
		{
			readf(inf,e_avg,d),readf(inf,e_var,d);
			readf(inf,k,d),readf(inf,b,d);
		}
		auto_load(inf);
	}
	void delthis()
	{
		if(built)
		{
			delete[] t_avg,delete[] t_var;
			delete[] e_avg,delete[] e_var;
			delete[] k,delete[] b;
			delete[] k_grad,delete[] b_grad;
		}
		built=false;
		auto_delthis();
	}

public:
	val4d* operator()(auto_dao::Data_Node& x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d* BN::operator()(auto_dao::Data_Node& x)\n\
  this hasn't been initalized yet\n\n"));
  		val4d* res=tmp<val4d>((shape4d){x.n,d,h,w});
		forward(x,*res);
		res->getdat().regop({&x},std::bind(&BN::backward,this,std::placeholders::_1,std::placeholders::_2));
		return res;
	}

public:
	BN(){built=false;}
	BN(OP_Base* fap,shape3d Input,float Delta = 0.9, float EPS = 1e-4):OP_Base(fap)
	{
		built=true;
		d=Input[0],h=Input[1],w=Input[2];
		delta=Delta,eps=EPS;
		t_avg=new float[d],t_var=new float[d];
		e_avg=new float[d],e_var=new float[d];
		k=new float[d],b=new float[d];
		k_grad=new float[d],b_grad=new float[d];
		reg_para(d,k,k_grad);
		reg_para(d,b,b_grad);
		// init wei
		for(int i=0;i<d;i++) k[i]=1,b[i]=0,e_avg[i]=0,e_var[i]=1;
	}
};

}
