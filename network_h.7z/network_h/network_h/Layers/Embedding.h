#pragma once

// Embedding layer

namespace network
{

	class EMBEDDING : public OP_Base
	{
	public:
		read_only<bool, EMBEDDING> built;
		read_only<dim_t, EMBEDDING> cnt, ins, dim;
		// in:  ins*n (type = dim_t)
		// out: ins*dim*1*n

	private:
		af::array* w, * w_grad; // cnt*dim*1*1
		dim_t tinsize, * tin;
		void getmem(dim_t n)
		{
			if (tinsize < n * ins)
			{
				if (tinsize != 0) delete[] tin;
				tinsize = n * ins;
				tin = new dim_t[tinsize];
			}
		}

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *w);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *w);
			auto_load(inf);
		}
		void delthis()
		{
			if (built)
			{
				delete w, delete w_grad;
				if (tinsize != 0) delete[] tin;
				tinsize = 0;
			}
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype EMBEDDING::type()\n\
  this hasn't been initalized yet\n\n"));
			return  w->type();
		}
		val4d* operator()(dim_t n, dim_t* x)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* EMBEDDING::operator()(dim_t n, dim_t* x)\n\
  this hasn't been initalized yet\n\n"));
			val4d* resp = tmp<val4d>(af::dim4{ ins,dim,1,n }, type());
			auto_grad::Data res = resp;
			getmem(n);
			memcpy(tin, x, sizeof(dim_t) * n * ins);
			for (dim_t i = 0; i < n; i++)
			{
				for (dim_t j = 0; j < ins; j++)
				{
					dim_t id = tin[i * ins + j];
					ext_assert(0 <= id && id <= cnt - 1, fprintf(stderr, "\
In val4d* EMBEDDING::operator()(dim_t n, dim_t* x)\n\
  x[%lld] = %lld but it should be in range [0,%lld]\n\n", long long(i * ins + j), (long long)id, long long(cnt - 1)));
					res.data()(j, af::span, 0, i) = (*w)(id, af::span, 0, 0);
				}
			}
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				for (dim_t i = 0; i < out.dims(3); i++)
				{
					for (dim_t j = 0; j < ins; j++)
					{
						dim_t id = tin[i * ins + j];
						(*w_grad)(id, af::span, 0, 0) += out.grad()(j, af::span, 0, i);
					}
				}
				});
			return resp;
		}

	public:
		EMBEDDING() { built = false; }
		EMBEDDING(OP_Base* fap, int Cnt, int Ins, int Dim, af::dtype type = f32) :OP_Base(fap)
		{
			built = true;
			cnt = Cnt, ins = Ins, dim = Dim;
			af::dim4 shape = { cnt,dim,1,1 };
			w = new af::array(shape, type), w_grad = new af::array(shape, type);
			tinsize = 0;
			reg_para(w, w_grad);
			// init w
			*w = af::randu(shape, type);
		}
	};

}