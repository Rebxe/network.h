#pragma once

// Embedding layer

namespace network
{

class EMBEDDING : public OP_Base
{
public:
	read_only<bool,EMBEDDING> built;
	read_only<int,EMBEDDING> cnt,ins,dim;
	// in: ins*(int in [0,cnt-1])
	// out: 1*ins*dim

private:
	float *w,*w_grad;
	int tinsize,*tin;
	void getmem(int n)
	{
		if(tinsize<n*ins)
		{
			if(tinsize!=0) delete[] tin;
			tinsize=n*ins;
			tin=new int[tinsize];
		}
	}
	
private:
	void forward(int n,int* in,auto_dao::Data out)
	{
		float4d outa=out.data();
		getmem(n);
		memcpy(tin,in,sizeof(int)*n*ins);
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<ins;j++)
			{
				int id=tin[i*ins+j];
				ext_assert(0<=id&&id<=cnt-1,
					fprintf(stderr,"\
In val4d* EMBEDDING::operator()(int n,int* x)\n\
  x[%d] = %d but it should be in range [0,%d]\n\n",i*ins+j,id,cnt-1));
				memcpy(outa[i][0][j],w+id*dim,sizeof(float)*dim);
			}
		}
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		int n=out->n;
		float4d outg=out->grad();
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<ins;j++)
			{
				int id=tin[i*ins+j];
				for(int k=0;k<dim;k++) w_grad[id*dim+k]+=outg[i][0][j][k];
			}
		}
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built) writf(ouf,w,cnt*dim);
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built) readf(inf,w,cnt*dim); 
		auto_load(inf);
	}
	void delthis()
	{
		if(built)
		{
			delete[] w,delete[] w_grad;
			if(tinsize!=0) delete[] tin;
		}
		built=false;
		auto_delthis();
	}

public:
	val4d* operator()(int n,int* x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d* EMBEDDING::operator()(int n,int* x)\n\
  this hasn't been initalized yet\n\n"));
  		val4d* res=tmp<val4d>(shape4d{n,1,ins,dim});
		forward(n,x,*res);
		res->getdat().addop(std::bind(&EMBEDDING::backward,this,std::placeholders::_1,std::placeholders::_2));
		return res;
	}

public:
	EMBEDDING(){built=false; }
	EMBEDDING(OP_Base* fap, int Cnt, int Ins, int Dim):OP_Base(fap)
	{
		built=true;
		cnt = Cnt, ins = Ins, dim = Dim;
		w=new float[cnt*dim],w_grad=new float[cnt*dim];
		tinsize=0;
		reg_para(cnt*dim,w,w_grad);
		// init w
		std::default_random_engine gen;
		std::normal_distribution<float> wer = std::normal_distribution<float>(0, 1);
		gen.seed(time(NULL));
		for (int i = 0; i < cnt * dim; i++) w[i] = wer(gen);
	}
};

}
