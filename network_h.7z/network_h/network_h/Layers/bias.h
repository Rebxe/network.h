#pragma once

// Bias Layer

namespace network
{

	class BIAS : public OP_Base
	{
	public:
		read_only<bool, BIAS> built;
		read_only<int, BIAS> dim;
		read_only<dim_t, BIAS> siz;
		read_only<bool, BIAS> inplace;

	private:
		af::array *b, *b_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *b);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *b);
			auto_load(inf);
		}
		void delthis()
		{
			if (built) delete b, delete b_grad;
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype BIAS::type() const\n\
  this hasn't been initalized yet\n\n"));
			return b->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built,fprintf(stderr, "\
In val4d BIAS::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(dim) == siz, fprintf(stderr, "\
In val4d* BIAS::operator()(auto_grad::Data x)\n\
  dim = %d\n\
  siz = %lld\n\
but\n\
  x = [%lld * %lld * %lld * %lld]\n\n",
				(int)dim,
				(long long)siz,
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			val4d* resp;
			if (!inplace)
			{
				resp = tmp<val4d>(x.dims(), x.type());
				auto_grad::Data res = resp;
				res.data() = x.data() + *b;
				res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = in[0];
					auto_grad::Data res = out;
					x.grad() += res.grad();
					af::array tmp = res.grad();
					if (dim != 0) tmp = af::sum(tmp, 0);
					if (dim != 1) tmp = af::sum(tmp, 1);
					if (dim != 2) tmp = af::sum(tmp, 2);
					if (dim != 3) tmp = af::sum(tmp, 3);
					*b_grad += tmp;
					});
			}
			else
			{
				x.data() += *b;
				resp = x.getfa()->tmp<val4d>(x);
				auto_grad::Data res = resp;
				res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = out;
					af::array tmp = x.grad();
					if (dim != 0) tmp = af::sum(tmp, 0);
					if (dim != 1) tmp = af::sum(tmp, 1);
					if (dim != 2) tmp = af::sum(tmp, 2);
					if (dim != 3) tmp = af::sum(tmp, 3);
					*b_grad += tmp;
					x.data() -= *b;
					});
			}
			return resp;
		}

	public:
		BIAS() { built = false; }
		BIAS(OP_Base* fap, int Dim, dim_t Siz, bool Inplace = false, af::dtype type = f32) :OP_Base(fap)
		{
			ext_assert(0 <= Dim && Dim <= 3, fprintf(stderr, "\
In BIAS::BIAS(OP_Base* fap, int Dim, dim_t Siz, bool Inplace = false, af::dtype type)\n\
  Dim = %d is out of range [0,3]\n\n", Dim));
			built = true;
			dim = Dim;
			siz = Siz;
			inplace = Inplace;
			af::dim4 ndim = { 1,1,1,1 };
			ndim[dim] = siz;
			b = new af::array(ndim), b_grad = new af::array(ndim);
			reg_para(b, b_grad);
			// init wei
			*b = 0;
		}
	};

}