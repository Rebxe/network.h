#pragma once

// Bias Layer

namespace network
{

class BIAS : public OP_Base
{
public:
	read_only<bool,BIAS> built;
	read_only<int,BIAS> d,h,w;
	read_only<bool,BIAS> inplace;

private:
	float *b,*b_grad;

private:
	void forward(auto_dao::Data_Node& in,auto_dao::Data_Node& out)
	{
		int n=in.n;
		ext_assert(in.d==d&&in.h==h&&in.w==w,
			fprintf(stderr,"\
In val4d* BIAS::operator()(auto_dao::Data_Node& x)\n\
  shape = [%d * %d * %d]\n\
but\n\
  x = [%d * %d * %d * %d]\n\n",d,h,w,in.n,in.d,in.h,in.w));
  		float4d xa=in.data(),ra=out.data();
  		for(int i=0;i<n;i++)
  			for(int j=0;j<d;j++)
  				for(int k=0;k<h*w;k++) ra[i][j].a[k]=xa[i][j].a[k]+b[j];
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		if(!inplace)
		{
			auto_dao::Data_Node* inp=in[0];
			int n=inp->n;
			float4d xg=inp->grad(),rg=out->grad();
	  		for(int i=0;i<n;i++)
	  			for(int j=0;j<d;j++)
	  				for(int k=0;k<h*w;k++)
					{
						xg[i][j].a[k]+=rg[i][j].a[k];
						b_grad[j]+=rg[i][j].a[k];
					}
		}
		else
		{
			int n=out->n;
			float4d ra=out->data(),rg=out->grad();
	  		for(int i=0;i<n;i++)
	  			for(int j=0;j<d;j++)
	  				for(int k=0;k<h*w;k++)
					{
						ra[i][j].a[k]-=b[j];
						b_grad[j]+=rg[i][j].a[k];
					}
		}
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built) writf(ouf,b,d);
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built) readf(inf,b,d);
		auto_load(inf);
	}
	void delthis()
	{
		if(built) delete[] b,delete[] b_grad;
		built=false;
		auto_delthis();
	}

public:
	val4d* operator()(auto_dao::Data_Node& x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d BIAS::operator()(auto_dao::Data_Node& x)\n\
  this hasn't been initalized yet\n\n"));
		val4d* res;
		if(!inplace)
		{
			res=tmp<val4d>((shape4d){x.n,x.d,x.h,x.w});
			forward(x,*res);
			res->getdat().regop({&x},std::bind(&BIAS::backward,this,std::placeholders::_1,std::placeholders::_2));
		}
		else
		{
			forward(x,x);
			res=x.getfa()->tmp<val4d>(x);
			res->getdat().addop(std::bind(&BIAS::backward,this,std::placeholders::_1,std::placeholders::_2));
		}
		return res;
	}

public:
	BIAS(){built=false;}
	BIAS(OP_Base* fap,shape3d Input,bool Inplace=false):OP_Base(fap)
	{
		built=true;
		d=Input[0],h=Input[1],w=Input[2];
		inplace=Inplace;
		b=new float[d],b_grad=new float[d];
		reg_para(d,b,b_grad);
		// init wei
		memset(b,0,sizeof(float)*d);
	}
	
};

}
