#pragma once

// Multi-Head Attnation Layer

namespace network
{

	class MH_ATTN : public OP_Base
	{
	public:
		read_only<bool, MH_ATTN> built;
		read_only<dim_t, MH_ATTN> inq, dq; // Q: inq*dq*1
		read_only<dim_t, MH_ATTN> ink, dk; // K: ink*dk*1
		read_only<dim_t, MH_ATTN> dv; 	   // V: ink*dv*1
		read_only<dim_t, MH_ATTN> dim, ch, odim;

	private:
		para4d* wq; // dq*dim*1*1
		para4d* wk; // dk*dim*1*1
		para4d* wv; // dv*dim*1*1
		// que: inq*dim*1*n
		// key: ink*dim*1*n
		// val: ink*dim*1*n
		// 
		// divide heads
		// que: inq*(dim/ch)*ch*n
		// key: ink*(dim/ch)*ch*n
		// val: ink*(dim/ch)*ch*n
		// 
		// que*(key^T): (inq*(dim/ch)*ch*n) * ((dim/ch)*ink*ch*n) = inq*ink*ch*n
		// 
		// divide by sqrt(dim/ch)
		// do mask
		// do softmax on dim 1
		//
		// res: (inq*ink*ch*n)* (ink*(dim/ch)*ch*n) = inq*(dim/ch)*ch*n
		// 
		// concat heads
		// res: inq*dim*1*n

		para4d* wo;  // dim*odim*1*1

		// out: (inq*dim*1*n) * (dim*odim*1*1) = inq*odim*1*n

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype MH_ATTN::type()\n\
  this hasn't been initalized yet\n\n"));
			return  wq->type();
		}
		val4d* operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* MH_ATTN::operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(Q.dims(0) == inq && Q.dims(1) == dq &&
				K.dims(0) == ink && K.dims(1) == dk &&
				V.dims(0) == ink && V.dims(1) == dv &&
				Q.dims(3) == K.dims(3) && K.dims(3) == V.dims(3) &&
				Q.dims(2) == 1 && Q.dims(2) == K.dims(2) && K.dims(2) == V.dims(2), fprintf(stderr, "\
In val4d* MH_ATTN::operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V)\n\
  Q = [%lld * %lld * %lld * %lld]\n\
  K = [%lld * %lld * %lld * %lld]\n\
  V = [%lld * %lld * %lld * %lld]\n\
but\n\
  Q should be [%lld * %lld * 1 * n]\n\
  K should be [%lld * %lld * 1 * n]\n\
  V should be [%lld * %lld * 1 * n]\n\n",
					(long long)Q.dims(0), (long long)Q.dims(1), (long long)Q.dims(2), (long long)Q.dims(3),
					(long long)K.dims(0), (long long)K.dims(1), (long long)K.dims(2), (long long)K.dims(3),
					(long long)V.dims(0), (long long)V.dims(1), (long long)V.dims(2), (long long)V.dims(3),
					(long long)inq, (long long)dq,
					(long long)ink, (long long)dk,
					(long long)ink, (long long)dv));
			/******************************* end assertion **********************************/
			dim_t n = Q.dims(3);
			val4d* que = matmul(Q, wq);
			val4d* key = matmul(K, wk);
			val4d* val = matmul(V, wv);
			que = reshape(que, af::dim4{ inq,(dim / ch),ch,n }, true);
			key = reshape(key, af::dim4{ ink,(dim / ch),ch,n }, true);
			val = reshape(val, af::dim4{ ink,(dim / ch),ch,n }, true);
			val4d* dot = matmulNT(que, key);
			dot = mul(dot, 1 / sqrt((double)dim / ch), true);
			dot = softmax(dot, 1, true);
			val4d* res = matmul(dot, val);
			res = reshape(res, af::dim4{ inq,dim,1,n }, true);
			res = matmul(res, wo);
			return res;
		}
		template<typename T = float, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
		val4d* operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V, const af::array& mask, T mask_val = -1e7) // mask inq*ink*ch*n  (i,j,k,l)=1 means change (i,j,k,l) to mask_val
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* MH_ATTN::operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V, const af::array& mask, T mask_val)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(Q.dims(0) == inq && Q.dims(1) == dq &&
				K.dims(0) == ink && K.dims(1) == dk &&
				V.dims(0) == ink && V.dims(1) == dv &&
				Q.dims(3) == K.dims(3) && K.dims(3) == V.dims(3) &&
				Q.dims(2) == 1 && Q.dims(2) == K.dims(2) && K.dims(2) == V.dims(2) &&
				mask.dims(0) == inq && mask.dims(1) == ink && (mask.dims(2) == 1 || mask.dims(2) == ch) && (mask.dims(3) == 1 || mask.dims(3) == Q.dims(3)), fprintf(stderr, "\
In val4d* MH_ATTN::operator()(auto_grad::Data Q, auto_grad::Data K, auto_grad::Data V, const af::array& mask, T mask_val)\n\
  Q = [%lld * %lld * %lld * %lld]\n\
  K = [%lld * %lld * %lld * %lld]\n\
  V = [%lld * %lld * %lld * %lld]\n\
  mask = [%lld * %lld * %lld * %lld]\n\
but\n\
  Q should be [%lld * %lld * 1 * n]\n\
  K should be [%lld * %lld * 1 * n]\n\
  V should be [%lld * %lld * 1 * n]\n\
  mask should be [%lld * %lld * {1,%lld} * {1,n}]\n\n",
					(long long)Q.dims(0), (long long)Q.dims(1), (long long)Q.dims(2), (long long)Q.dims(3),
					(long long)K.dims(0), (long long)K.dims(1), (long long)K.dims(2), (long long)K.dims(3),
					(long long)V.dims(0), (long long)V.dims(1), (long long)V.dims(2), (long long)V.dims(3),
					(long long)mask.dims(0), (long long)mask.dims(1), (long long)mask.dims(2), (long long)mask.dims(3),
					(long long)inq, (long long)dq,
					(long long)ink, (long long)dk,
					(long long)ink, (long long)dv,
					(long long)inq, (long long)ink, (long long)ch));
			/******************************* end assertion **********************************/
			dim_t n = Q.dims(3);
			val4d* que = matmul(Q, wq);
			val4d* key = matmul(K, wk);
			val4d* val = matmul(V, wv);
			que = reshape(que, af::dim4{ inq,(dim / ch),ch,n }, true);
			key = reshape(key, af::dim4{ ink,(dim / ch),ch,n }, true);
			val = reshape(val, af::dim4{ ink,(dim / ch),ch,n }, true);
			val4d* dot = matmulNT(que, key);
			dot = mul(dot, 1 / sqrt((double)dim / ch), true);
			af::array t_mask;
			if (mask.dims(2) != ch || mask.dims(3) != n) t_mask = af::tile(mask, { 1,1,ch / mask.dims(2),n / mask.dims(3) });
			else t_mask = mask;
			dot = masked(dot, t_mask, mask_val, true);
			dot = softmax(dot, 1, true);
			val4d* res = matmul(dot, val);
			res = reshape(res, af::dim4{ inq,dim,1,n }, true);
			res = matmul(res, wo);
			return res;
		}

	public:
		MH_ATTN() { built = false; }
		MH_ATTN(OP_Base* fap,
			std::pair<dim_t, dim_t> Q, std::pair<dim_t, dim_t> K, dim_t dim_V,
			dim_t Dim, dim_t Cnt_head, dim_t Out_dim,
			af::dtype type = f32) :OP_Base(fap)
		{
			ext_assert(Dim % Cnt_head == 0, fprintf(stderr, "\
In MH_ATTN::MH_ATTN(OP_Base* fap,\n\
	std::pair<dim_t, dim_t> Q, std::pair<dim_t, dim_t> K, dim_t dim_V,\n\
	dim_t Cnt_head, dim_t Dim, dim_t Out_dim,\n\
	af::dtype type)\n\
  Dim = %lld can't be divided by Cnt_head = %lld\n\n", (long long)Dim, (long long)Cnt_head));
			built = true;
			inq = Q.first, dq = Q.second;
			ink = K.first, dk = K.second;
			dv = dim_V;
			dim = Dim, ch = Cnt_head, odim = Out_dim;
			wq = get<para4d>(af::dim4{ dq,dim,1,1 }, type);
			wk = get<para4d>(af::dim4{ dk,dim,1,1 }, type);
			wv = get<para4d>(af::dim4{ dv,dim,1,1 }, type);
			wo = get<para4d>(af::dim4{ dim,odim,1,1 }, type);
			// init w
			wq->data() = af::randn(wq->dims(), type) * sqrt((double)1 / dq);
			wk->data() = af::randn(wk->dims(), type) * sqrt((double)1 / dk);
			wv->data() = af::randn(wv->dims(), type) * sqrt((double)1 / dv);
			wo->data() = af::randn(wo->dims(), type) * sqrt((double)1 / dim);
		}
	};

}