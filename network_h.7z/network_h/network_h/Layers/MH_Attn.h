#pragma once

// Multi-Head Attnation Layer

namespace network
{

// mask(batch_id,head_id,que_id,key_id)

class MH_ATTN : public OP_Base 
{
public:
	read_only<bool,MH_ATTN> built;
	read_only<int,MH_ATTN> inq,dq; // Q: 1*inq*dq
	read_only<int,MH_ATTN> ink,dk; // K: 1*ink*dk
	read_only<int,MH_ATTN> dv; 	   // V: 1*ink*dv
	read_only<int,MH_ATTN> ch;
	read_only<int,MH_ATTN> kdim,vdim,odim;

private:
	wei3d* wq; // ch* dq*kdim
	wei3d* wk; // ch* dk*kdim
	// que: inq*kdim
	// key: ink*kdim
	// que*(key^T): (ch* inq*kdim) * (ch* kdim*ink) = ch* inq*ink
	// divide by sqrt(kdim)
	// do mask
	// do softmax
	
	wei3d* wv;    // ch* dv*vdim
	// val: ch* ink*vdim
	
	// out = (ch* inq*ink)* (ch* ink*vdim) = ch* inq*vdim
	
	// to NHWD: inq* vdim*ch
	// reshape(1,inq,vdim*ch)
	wei3d* wout;  // (vdim*ch)*odim
	
	// out = (inq*(vdim*ch)) * ((vdim*ch)*odim) = inq*odim

public:
	val4d* operator()(auto_dao::Data Q,auto_dao::Data K,auto_dao::Data V,std::function<bool(int,int,int,int)> mask)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d* MH_ATTN::operator()(auto_dao::Data Q,auto_dao::Data K,auto_dao::Data V,std::function<bool(int,int,int)> mask)\n\
  this hasn't been initalized yet\n\n"));
		ext_assert(Q.d==1&&Q.h==inq&&Q.w==dq&&
				   K.d==1&&K.h==ink&&K.w==dk&&
				   V.d==1&&V.h==ink&&V.w==dv&&
				   Q.n==K.n&&K.n==V.n,
			fprintf(stderr,"\
In val4d* MH_ATTN::operator()(auto_dao::Data Q,auto_dao::Data K,auto_dao::Data V,std::function<bool(int,int,int)> mask)\n\
  Q = [%d * %d * %d]\n\
  K = [%d * %d * %d]\n\
  V = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  Input Q = [%d * %d * %d * %d]\n\
  Input K = [%d * %d * %d * %d]\n\
  Input V = [%d * %d * %d * %d]\n\n",
	  	1,(int)inq,(int)dq,1,(int)ink,(int)dk,1,(int)ink,(int)dv,1,(int)inq,(int)odim,
		(int)Q.n,(int)Q.d,(int)Q.h,(int)Q.w,(int)K.n,(int)K.d,(int)K.h,(int)K.w,(int)V.n,(int)V.d,(int)V.h,(int)V.w));
/******************************* end assertion **********************************/
		int n=Q.n;
		val4d* que=matmul(toshape(Q,shape4d{n,ch,inq,dq}),wq); // ch* inq*kdim
		val4d* key=matmul(toshape(K,shape4d{n,ch,ink,dk}),wk); // ch* ink*kdim
		key=sdim(key,"NDhw","NDwh",true);
		val4d* dot=matmul(que,key); // ch* inq*ink
		dot=mul(dot,1/sqrt((float)kdim),true);
		dot=masked(dot,mask,-1e8,true); // -inf = -1e8
		dot=softmax(dot,4);
		val4d* val=matmul(toshape(V,shape4d{n,ch,ink,dv}),wv); // ch* ink*vdim
		val4d* out=matmul(dot,val); // ch* inq*vdim
		out=sdim(out,"NdHW","NHWd",true);
		out=reshape(out,shape4d{n,1,inq,vdim*ch},true); // 1*inq*(vdim*ch)
		out=matmul(out,wout);
		return out;
	}

public:
	MH_ATTN(){built=false;}
	MH_ATTN(OP_Base* fap,
		std::pair<int,int> Q,std::pair<int,int> K,int dim_V,
		int Cnt_head,int Key_dim,int Val_dim,
		int Out_dim):OP_Base(fap)
	{
		built=true;
		inq=Q.first,dq=Q.second;
		ink=K.first,dk=K.second;
		dv=dim_V;
		ch=Cnt_head;
		kdim=Key_dim,vdim=Val_dim,odim=Out_dim;
		wq=get<wei3d>(shape3d{ch,dq,kdim},std::normal_distribution<float>(0,sqrt(1/(float)dq)));
		wk=get<wei3d>(shape3d{ch,dk,kdim},std::normal_distribution<float>(0,sqrt(1/(float)dk)));
		wv=get<wei3d>(shape3d{ch,dv,vdim},std::normal_distribution<float>(0,sqrt(1/(float)dv)));
		wout=get<wei3d>(shape3d{1,vdim*ch,odim},std::normal_distribution<float>(0,sqrt(1/(float)(vdim*ch))));
	}
};

}
