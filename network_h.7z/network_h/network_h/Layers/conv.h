#pragma once

// Convolution layer

namespace network
{

	// Input: inh * inw * inc * n
	// Output: ouh * ouw * cnt * n

	class CONV : public OP_Base
	{
	public:
		read_only<bool, CONV> built;
		read_only<dim_t, CONV> inh, inw, inc;
		read_only<dim_t, CONV> ch, cw, cnt;
		read_only<dim_t, CONV> stx, sty;   // stride
		read_only<dim_t, CONV> pdx, pdy;   // padding
		read_only<dim_t, CONV> dilx, dily; // dilation
		read_only<dim_t, CONV> ouh, ouw;

	private:
		af::array* w, * w_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *w);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *w);
			auto_load(inf);
		}
		void delthis()
		{
			if (built) delete w, delete w_grad;
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype CONV::type() const\n\
  this hasn't been initalized yet\n\n"));
			return w->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built,
				fprintf(stderr, "\
In val4d* CONV::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(0) == inh && x.dims(1) == inw && x.dims(2) == inc,
				fprintf(stderr, "\
In val4d* CONV::operator()(auto_grad::Data x)\n\
  input = [%lld * %lld * %lld * n]\n\
  x     = [%lld * %lld * %lld * %lld]\n\n",
					(long long)inh, (long long)inw, (long long)inc,
					(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			val4d* resp = tmp<val4d>(af::dim4{ ouh,ouw,cnt,x.dims(3) });
			auto_grad::Data res = resp;
			res.data() = af::convolve2NN(x.data(), *w, 
					af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 });
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += af::convolve2GradientNN(res.grad(), x.data(), *w, res.data(), 
						af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 }, AF_CONV_GRADIENT_DATA);
				*w_grad += af::convolve2GradientNN(res.grad(), x.data(), *w, res.data(), 
						af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 }, AF_CONV_GRADIENT_FILTER);
			});
			return resp;
		}

	public:
		CONV() { built = false; }
		CONV(OP_Base* fap,
			af::dim4 Input, // Input[3] is ignored
			std::pair<dim_t, dim_t> Core, dim_t CoreCnt,
			std::pair<dim_t, dim_t> Stride = { 1,1 },
			std::pair<dim_t, dim_t> Padding = { 0,0 },
			std::pair<dim_t, dim_t> Dilation = { 1,1 },
			int InitType = Init_He,
			af::dtype type = f32) :OP_Base(fap)
		{
			built = true;
			inh = Input[0], inw = Input[1], inc = Input[2];
			ch = Core.first, cw = Core.second, cnt = CoreCnt;
			stx = Stride.first, sty = Stride.second;
			pdx = Padding.first, pdy = Padding.second;
			dilx = Dilation.first, dily = Dilation.second;
			ouh = (inh + pdx * 2 - (ch - 1) * dilx - 1) / stx + 1, ouw = (inw + pdy * 2 - (cw - 1) * dily - 1) / sty + 1;
			af::dim4 core_shape = af::dim4{ ch,cw,inc,cnt };
			w = new af::array(core_shape, type);
			w_grad = new af::array(core_shape, type);
			reg_para(w, w_grad);
			// init wei
			*w = af::randn(core_shape, type);
			if (InitType == Init_He) *w *= sqrt(2 / (double)(ch * cw * inc));
			else                     *w *= sqrt(1 / (double)(ch * cw * inc));
		}
	};

}