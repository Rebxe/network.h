#pragma once

// Self Attnation Layer

namespace network
{

	class SELF_ATTN : public OP_Base
	{
	public:
		read_only<bool, SELF_ATTN> built;
		read_only<dim_t, SELF_ATTN> in, dim; // input: in*dim*1
		read_only<dim_t, SELF_ATTN> ch, odim;

	private:
		// divide heads
		// que: in*(dim/ch)*ch*n
		// key: in*(dim/ch)*ch*n
		// val: in*(dim/ch)*ch*n
		// 
		// que*(key^T): (in*(dim/ch)*ch*n) * ((dim/ch)*in*ch*n) = in*in*ch*n
		// 
		// divide by sqrt(dim/ch)
		// do mask
		// do softmax on dim 1
		//
		// res: (in*in*ch*n)* (in*(dim/ch)*ch*n) = in*(dim/ch)*ch*n
		// 
		// concat heads
		// res: in*dim*1*n

		para4d* wo;  // dim*odim*1*1

		// out: (in*dim*1*n) * (dim*odim*1*1) = in*odim*1*n

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype SELF_ATTN::type()\n\
  this hasn't been initalized yet\n\n"));
			return  wo->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* SELF_ATTN::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(0) == in && x.dims(1) == dim, fprintf(stderr, "\
In val4d* SELF_ATTN::operator()(auto_grad::Data x)\n\
  x = [%lld * %lld * %lld * %lld]\n\
but\n\
  x should be [%lld * %lld * 1 * n]\n\n",
					(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3),
					(long long)in, (long long)dim));
			/******************************* end assertion **********************************/
			dim_t n = x.dims(3);
			val4d* que, * key, * val;
			que = key = val = reshape(x, af::dim4{ in,(dim / ch),ch,n }, true);
			val4d* dot = matmulNT(que, key);
			dot = mul(dot, 1 / sqrt((double)dim / ch), true);
			dot = softmax(dot, 1, true);
			val4d* res = matmul(dot, val);
			res = reshape(res, af::dim4{ in,dim,1,n }, true);
			res = matmul(res, wo);
			return res;
		}
		template<typename T = float, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
		val4d* operator()(auto_grad::Data x, const af::array& mask, T mask_val = -1e7) // mask in*in*ch*n  (i,j,k,l)=1 means change (i,j,k,l) to mask_val
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* SELF_ATTN::operator()(auto_grad::Data x, const af::array& mask, T mask_val = -1e7)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(0) == in && x.dims(1) == dim &&
				mask.dims(0) == in && mask.dims(1) == in && (mask.dims(2) == 1 || mask.dims(2) == ch) && (mask.dims(3) == 1 || mask.dims(3) == x.dims(3)), fprintf(stderr, "\
In val4d* SELF_ATTN::operator()(auto_grad::Data x, const af::array& mask, T mask_val = -1e7)\n\
  x = [%lld * %lld * %lld * %lld]\n\
  mask = [%lld * %lld * %lld * %lld]\n\
but\n\
  x should be [%lld * %lld * 1 * n]\n\
  mask should be [%lld * %lld * {1,%lld} * {1,n}]\n\n",
					(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3),
					(long long)mask.dims(0), (long long)mask.dims(1), (long long)mask.dims(2), (long long)mask.dims(3),
					(long long)in, (long long)dim,
					(long long)in, (long long)in, (long long)ch));
			/******************************* end assertion **********************************/
			dim_t n = x.dims(3);
			val4d* que, *key, *val;
			que = key = val = reshape(x, af::dim4{ in,(dim / ch),ch,n }, true);
			val4d* dot = matmulNT(que, key);
			dot = mul(dot, 1 / sqrt((double)dim / ch), true);
			af::array t_mask;
			if (mask.dims(2) != ch || mask.dims(3) != n) t_mask = af::tile(mask, { 1,1,ch / mask.dims(2),n / mask.dims(3) });
			else t_mask = mask;
			dot = masked(dot, t_mask, mask_val, true);
			dot = softmax(dot, 1, true);
			val4d* res = matmul(dot, val);
			res = reshape(res, af::dim4{ in,dim,1,n }, true);
			res = matmul(res, wo);
			return res;
		}

	public:
		SELF_ATTN() { built = false; }
		SELF_ATTN(OP_Base* fap,
			std::pair<dim_t, dim_t> Input, dim_t Cnt_head, dim_t Out_dim,
			af::dtype type = f32) :OP_Base(fap)
		{
			ext_assert(Input.second % Cnt_head == 0, fprintf(stderr, "\
In SELF_ATTN::SELF_ATTN(OP_Base* fap,\n\
	std::pair<dim_t, dim_t> Input, dim_t Cnt_head, dim_t Out_dim,\n\
	af::dtype type)\n\
  Input.second = %lld can't be divided by Cnt_head = %lld\n\n", (long long)Input.second, (long long)Cnt_head));
			built = true;
			in = Input.first, dim = Input.second;
			ch = Cnt_head, odim = Out_dim;
			wo = get<para4d>(af::dim4{ dim,odim,1,1 }, type);
			// init w
			wo->data() = af::randn(wo->dims(), type) * sqrt((double)1 / dim);
		}
	};

}