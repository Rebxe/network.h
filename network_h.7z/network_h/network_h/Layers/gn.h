#pragma once

// Group Normalization Layer

namespace network
{

	class GN : public OP_Base
	{
	public:
		read_only<bool, GN> built;
		read_only<int, GN> dim;
		read_only<dim_t, GN> siz, g;
		read_only<double, GN> eps;
		read_only<bool, GN> inplace;

	private:
		af::array* k, * b;
		af::array* k_grad, * b_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *k), writf(ouf, *b);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *k), readf(inf, *b);
			auto_load(inf);
		}
		void delthis()
		{
			if (built)
			{
				delete k, delete b;
				delete k_grad, delete b_grad;
			}
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype GN::type() const\n\
  this hasn't been initalized yet\n\n"));
			return k->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d* GN::operator()(auto_dao::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(dim) == siz, fprintf(stderr, "\
In val4d* GN::operator()(auto_grad::Data x)\n\
  dim = %d\n\
  siz = %lld\n\
but\n\
  x = [%lld * %lld * %lld * %lld]\n\n",
				(int)dim,
				(long long)siz,
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			val4d* resp;
			if (!inplace) resp = tmp<val4d>(x.dims(), x.type());
			else		  resp = x.getfa()->tmp<val4d>(x);
			auto_grad::Data res = resp;
			af::array tmp_data;
			if (inplace) tmp_data = x.data();
			// forward
			af::array tmp;
			if (dim == 0)      tmp = af::moddims(x.data(), { x.dims(0) / g,g,x.dims(1) * x.dims(2),x.dims(3) });
			else if (dim == 1) tmp = af::moddims(x.data(), { x.dims(0) * x.dims(1) / g,g,x.dims(2),x.dims(3) });
			else if (dim == 2) tmp = af::moddims(x.data(), { x.dims(0) * x.dims(1) * x.dims(2) / g,g,1,x.dims(3) });
			dim_t div = x.elements() / x.dims(3) / g;
			auto sum2 = [&](const auto& x) { return af::sum(af::sum(x, 0), 2); };
			auto sum3 = [&](const auto& x) { return af::sum(af::sum(af::sum(x, 0), 2), 3); };
			af::array avg = sum2(tmp) / div;
			af::array var = sum2((tmp - avg) * (tmp - avg)) / div;
			af::array xh = (tmp - avg) / af::sqrt(var + eps);
			res.data() = af::moddims(*k * xh + *b, x.dims());
			// backward
			if (!inplace)
			{
				res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = in[0];
					auto_grad::Data res = out;
					af::array tdata, tgrad;
					if (dim == 0)      tdata = af::moddims(x.data(), { x.dims(0) / g,g,x.dims(1) * x.dims(2),x.dims(3) });
					else if (dim == 1) tdata = af::moddims(x.data(), { x.dims(0) * x.dims(1) / g,g,x.dims(2),x.dims(3) });
					else if (dim == 2) tdata = af::moddims(x.data(), { x.dims(0) * x.dims(1) * x.dims(2) / g,g,1,x.dims(3) });
					if (dim == 0)      tgrad = af::moddims(res.grad(), { x.dims(0) / g,g,x.dims(1) * x.dims(2),x.dims(3) });
					else if (dim == 1) tgrad = af::moddims(res.grad(), { x.dims(0) * x.dims(1) / g,g,x.dims(2),x.dims(3) });
					else if (dim == 2) tgrad = af::moddims(res.grad(), { x.dims(0) * x.dims(1) * x.dims(2) / g,g,1,x.dims(3) });
					*k_grad += sum3(xh * tgrad);
					*b_grad += sum3(tgrad);
					af::array dL_dxh = tgrad * *k;
					af::array dL_dvar = -sum2(dL_dxh * (tdata - avg) / (2 * af::pow(var + eps, 1.5)));
					af::array dvar_davg = sum2(avg - tdata) * 2 / div;
					af::array dL_davg = dL_dvar * dvar_davg - sum2(dL_dxh / af::sqrt(var + eps));
					af::array dvar_dx = (tdata - avg) * 2 / div;
					x.grad() += af::moddims(dL_dxh / af::sqrt(var + eps) + dL_davg / div + dL_dvar * dvar_dx, x.dims());
					});
			}
			else
			{
				res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
					auto_grad::Data x = out;
					x.data() = tmp_data;
					af::array tdata, tgrad;
					if (dim == 0)      tdata = af::moddims(x.data(), { x.dims(0) / g,g,x.dims(1) * x.dims(2),x.dims(3) });
					else if (dim == 1) tdata = af::moddims(x.data(), { x.dims(0) * x.dims(1) / g,g,x.dims(2),x.dims(3) });
					else if (dim == 2) tdata = af::moddims(x.data(), { x.dims(0) * x.dims(1) * x.dims(2) / g,g,1,x.dims(3) });
					if (dim == 0)      tgrad = af::moddims(x.grad(), { x.dims(0) / g,g,x.dims(1) * x.dims(2),x.dims(3) });
					else if (dim == 1) tgrad = af::moddims(x.grad(), { x.dims(0) * x.dims(1) / g,g,x.dims(2),x.dims(3) });
					else if (dim == 2) tgrad = af::moddims(x.grad(), { x.dims(0) * x.dims(1) * x.dims(2) / g,g,1,x.dims(3) });
					*k_grad += sum3(xh * tgrad);
					*b_grad += sum3(tgrad);
					af::array dL_dxh = tgrad * *k;
					af::array dL_dvar = -sum2(dL_dxh * (tdata - avg) / (2 * af::pow(var + eps, 1.5)));
					af::array dvar_davg = sum2(avg - tdata) * 2 / div;
					af::array dL_davg = dL_dvar * dvar_davg - sum2(dL_dxh / af::sqrt(var + eps));
					af::array dvar_dx = (tdata - avg) * 2 / div;
					x.grad() = af::moddims(dL_dxh / af::sqrt(var + eps) + dL_davg / div + dL_dvar * dvar_dx, x.dims());
					});
			}
			return resp;
		}

	public:
		GN() { built = false; }
		GN(OP_Base* fap, int Dim, dim_t Siz, dim_t G, bool Inplace = false, float Eps = 1e-4, af::dtype type = f32) :OP_Base(fap)
		{
			ext_assert(0 <= Dim && Dim <= 2, fprintf(stderr, "\
In GN::GN(OP_Base* fap, int Dim, dim_t Siz, int G, bool Inplace, float Eps, af::dtype type)\n\
  Dim = %d is out of range [0,2]\n\n", Dim));
			ext_assert(Siz % G == 0, fprintf(stderr, "\
In GN::GN(OP_Base* fap, int Dim, dim_t Siz, int G, bool Inplace, float Eps, af::dtype type)\n\
  Siz = %lld can't be divided by G = %lld\n\n", (long long)Siz, (long long)G));
			built = true;
			dim = Dim, siz = Siz;
			g = G, eps = Eps;
			inplace = Inplace;
			af::dim4 ndim = { 1,g,1,1 };
			k = new af::array(ndim), b = new af::array(ndim);
			k_grad = new af::array(ndim), b_grad = new af::array(ndim);
			reg_para(k, k_grad);
			reg_para(b, b_grad);
			// init wei
			*k = 1, * b = 0;
		}
	};

}