#pragma once

// Group Normalization Layer

namespace network
{

class GN : public OP_Base 
{
public:
	read_only<bool,GN> built;
	read_only<int,GN> d,h,w;
	read_only<int,GN> g;
	read_only<float,GN> eps;
	read_only<int,GN> cnt; // number of groups

private:
	float *k,*b;
	float *k_grad,*b_grad;

private:
	void forward(auto_dao::Data in,auto_dao::Data out)
	{
		int n=in.n;
		ext_assert(d==in.d&&h==in.h&&w==in.w,
			fprintf(stderr,"\
In val4d* GN::operator()(auto_dao::Data x)\n\
  shape = [%d * %d * %d]\n\
but\n\
  x = [%d * %d * %d * %d]\n\n",(int)d,(int)h,(int)w,(int)in.n,(int)in.d,(int)in.h,(int)in.w));
  		float4d ina=in.data(),outa=out.data();
		for(int tb=0;tb<n;tb++)
		{ 
			for(int l=0,id=0;l<d;l+=g,id++)
			{
				int r=(std::min)(d-1,l+g-1);
				float avg=0,var=0;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++) avg+=ina[tb][j].a[t];
				avg/=(r-l+1)*h*w;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++) var+=pow(ina[tb][j].a[t]-avg,2);
				var/=(r-l+1)*h*w;
				float s=sqrt(var+eps);
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++)
						outa[tb][j].a[t]=k[id]*(ina[tb][j].a[t]-avg)/s+b[id];
			}
		}
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		int n=inp->n;
  		float4d ina=inp->data();
  		float4d ing=inp->grad(),outg=out->grad();
		for(int tb=0;tb<n;tb++)
		{
			for(int l=0,id=0;l<d;l+=g,id++)
			{
				int r=(std::min)(d-1,l+g-1);
				float avg=0,var=0;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++) avg+=ina[tb][j].a[t];
				avg/=(r-l+1)*h*w;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++) var+=pow(ina[tb][j].a[t]-avg,2);
				var/=(r-l+1)*h*w;
				float s=sqrt(var+eps),s2=pow(var+eps,1.5)*2;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++)
						k_grad[id]+=outg[tb][j].a[t]*(ina[tb][j].a[t]-avg)/s;
				for(int j=l;j<=r;j++)
					for(int t=0;t<h*w;t++) b_grad[id]+=outg[tb][j].a[t];
				float dL_davg=0,dL_dvar=0,dvar_davg=0;
				for(int j=l;j<=r;j++)
				{
					float *ia=ina[tb][j],*ig=ing[tb][j];
					float *og=outg[tb][j]; 
					for(int t=0;t<h*w;t++)
					{
						float dL_dhx=og[t]*k[id];
						ig[t]+=dL_dhx/s;
						dL_davg-=dL_dhx/s;
						dL_dvar-=dL_dhx*(ia[t]-avg)/s2;
						dvar_davg+=2/(float)((r-l+1)*h*w)*(avg-ia[t]);
					}
				}
				dL_davg+=dL_dvar*dvar_davg;
				for(int j=l;j<=r;j++)
				{
					float *ia=ina[tb][j],*ig=ing[tb][j];
					for(int t=0;t<h*w;t++)
						ig[t]+=(dL_davg+dL_dvar*2*(ia[t]-avg))/(float)((r-l+1)*h*w);
				}
			}
		}
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built) writf(ouf,k,cnt),writf(ouf,b,cnt);
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built) readf(inf,k,cnt),readf(inf,b,cnt);
		auto_load(inf);
	}
	void delthis()
	{
		if(built)
		{
			delete[] k,delete[] b;
			delete[] k_grad,delete[] b_grad;
		}
		built=false;
		auto_delthis();
	}

public:
	val4d* operator()(auto_dao::Data x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d* GN::operator()(auto_dao::Data x)\n\
  this hasn't been initalized yet\n\n"));
  		val4d* res=tmp<val4d>(shape4d{x.n,d,h,w});
		forward(x,*res);
		res->getdat().regop({x},std::bind(&GN::backward,this,std::placeholders::_1,std::placeholders::_2));
		return res;
	}

public:
	GN(){built=false;}
	GN(OP_Base* fap,shape3d Input,int G,float Eps=1e-4):OP_Base(fap)
	{
		built=true;
		d=Input[0],h=Input[1],w=Input[2];
		g=G,eps=Eps;
		cnt=d/g+(d%g!=0);
		k=new float[cnt],b=new float[cnt];
		k_grad=new float[cnt],b_grad=new float[cnt];
		reg_para(cnt,k,k_grad),reg_para(cnt,b,b_grad);
		// init wei
		for(int i=0;i<cnt;i++) k[i]=1,b[i]=0;
	}
};

}
