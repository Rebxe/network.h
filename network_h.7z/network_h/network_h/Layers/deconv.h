#pragma once

// Deconvolution layer

namespace network
{

class DECONV : public OP_Base 
{
public:
	read_only<bool,DECONV> built;
	read_only<int,DECONV> ind, inh, inw;
	read_only<int,DECONV> cnt, ch, cw;
	read_only<int,DECONV> stx, sty;
	read_only<int,DECONV> pdx, pdy;
	read_only<float,DECONV> pdval;
	read_only<int,DECONV> ouh, ouw;

private:
	float *w,*w_grad;

private:
	void forward(auto_dao::Data_Node& in,auto_dao::Data_Node& out)
	{
		int n=in.n;
		ext_assert(ind==in.d&&inh==in.h&&inw==in.w,
			fprintf(stderr,"\
In val4d* DECONV::operator()(auto_dao::Data_Node& x)\n\
  in  = [%d * %d * %d]\n\
  out = [%d * %d * %d]\n\
but\n\
  x = [%d * %d * %d * %d]\n\n",ind,inh,inw,cnt,ouh,ouw,in.n,in.d,in.h,in.w));
		in.sdim("NdHW","NHWd");
  		float4d ina=in.data(),outa=out.data();
  		float* outmrt=mem_pool::shared_memory;
		int out_h = inh * inw, out_w = cnt * ch * cw;
		int pre_h = mem_pool::max_size / out_w;
		for (int l = 0; l < n * out_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, n * out_h - 1);
			memset(outmrt, 0, sizeof(float) * (r - l + 1) * out_w);
			Matrix_Mul(r - l + 1, ind, out_w,
				ina.a + l * ind, false,
				w, false,
				outmrt);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % out_h, tb = k / out_h;
				int ix = idd / inw, iy = idd % inw;
				int lx = ix * stx - pdx, ly = iy * sty - pdy;
				for (int d = 0; d < cnt; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
						{
							if (x >= 0 && x < ouh && y >= 0 && y < ouw)	outa[tb][d][x][y] += outmrt[p];
							p++;
						}
			}
		}
		in.sdim("NHWd","NdHW");
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		inp->sdim("NdHW","NHWd");
		int n=inp->n;
		float4d ina=inp->data(),ing=inp->grad();
		float4d outg=out->grad();
  		float* outmrt=mem_pool::shared_memory;
		int out_h = inh * inw, out_w = cnt * ch * cw;
		int pre_h = mem_pool::max_size / out_w;
		for (int l = 0; l < n * out_h; l += pre_h)
		{
			int r = (std::min)(l + pre_h - 1, n * out_h - 1);
			for (int k = l, p = 0; k <= r; k++)
			{
				int idd = k % out_h, tb = k / out_h;
				int ix = idd / inw, iy = idd % inw;
				int lx = ix * stx - pdx, ly = iy * sty - pdy;
				for (int d = 0; d < cnt; d++)
					for (int x = lx; x < lx + ch; x++)
						for (int y = ly; y < ly + cw; y++)
							if (x >= 0 && x < ouh && y >= 0 && y < ouw)
								outmrt[p++] = outg[tb][d][x][y];
							else
								outmrt[p++] = 0;
			}
			Matrix_Mul(ind, r - l + 1, out_w,
				ina.a + l * ind, true,
				outmrt, false,
				w_grad);
			Matrix_Mul(r - l + 1, out_w, ind,
				outmrt, false,
				w, true,
				ing.a + l * ind);
		}
		inp->sdim("NHWd","NdHW");
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built) writf(ouf,w,(ind * ch * cw) * cnt);
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built) readf(inf,w,(ind * ch * cw) * cnt);
		auto_load(inf);
	}
	void delthis()
	{
		if(built) delete[] w,delete[] w_grad;
		built=false;
		auto_delthis(); 
	}

public:
	val4d* operator()(auto_dao::Data_Node& x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d* DECONV::operator()(auto_dao::Data_Node& x)\n\
  this hasn't been initalized yet\n\n"));
  		val4d* res=tmp<val4d>((shape4d){x.n,cnt,ouh,ouw});
		forward(x,*res);
		res->getdat().regop({&x},std::bind(&DECONV::backward,this,std::placeholders::_1,std::placeholders::_2));
		return res;
	}

public:
	DECONV(){built=false;}
	DECONV(OP_Base* fap,
		shape3d Input,
		int CoreCnt, std::pair<int,int> Core,
		std::pair<int,int> Stride = {1,1},
		std::pair<int,int> Padding = {0,0},
		int Init_Type = Init_He):OP_Base(fap)
	{
		built=true;
		ind = Input[0], inh = Input[1], inw = Input[2];
		cnt = CoreCnt, ch = Core.first, cw = Core.second;
		stx = Stride.first, sty = Stride.second;
		pdx = Padding.first, pdy = Padding.second;
		ouh = ch + (inh - 1) * stx - pdx * 2, ouw = cw + (inw - 1) * sty - pdy * 2;
		int w_cnt = (ind * ch * cw) * cnt;
		w = new float[w_cnt], w_grad = new float[w_cnt];
		reg_para(w_cnt,w,w_grad);
		// init w
		std::default_random_engine gen;
		std::normal_distribution<float> wer;
		int ins = ind * ((ch + stx - 1) / stx + (cw + sty - 1) / sty);
		if (Init_Type == Init_He) wer = std::normal_distribution<float>(0, sqrt(2 / (float)ins));
		else                      wer = std::normal_distribution<float>(0, sqrt(1 / (float)ins));
		gen.seed(time(NULL));
		for (int i = 0; i < w_cnt; i++) w[i] = wer(gen);
	}
};

}
