#pragma once

// Convolution layer

namespace network
{

	// Input: ouh * ouw * cnt * n
	// Output: inh * inw * inc * n

	class DECONV : public OP_Base
	{
	public:
		read_only<bool, DECONV> built;
		read_only<dim_t, DECONV> inh, inw, inc;
		read_only<dim_t, DECONV> ch, cw, cnt;
		read_only<dim_t, DECONV> stx, sty;   // stride
		read_only<dim_t, DECONV> pdx, pdy;   // padding
		read_only<dim_t, DECONV> dilx, dily; // dilation
		read_only<dim_t, DECONV> ouh, ouw;

	private:
		af::array* w, * w_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *w);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *w);
			auto_load(inf);
		}
		void delthis()
		{
			if (built) delete w, delete w_grad;
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype DECONV::type() const\n\
  this hasn't been initalized yet\n\n"));
			return w->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built,
				fprintf(stderr, "\
In val4d* DECONV::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(0) == ouh && x.dims(1) == ouw && x.dims(2) == cnt,
				fprintf(stderr, "\
In val4d* DECONV::operator()(auto_grad::Data x)\n\
  input = [%lld * %lld * %lld * n]\n\
  x     = [%lld * %lld * %lld * %lld]\n\n",
					(long long)ouh, (long long)ouw, (long long)cnt,
					(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			val4d* resp = tmp<val4d>(af::dim4{ inh,inw,inc,x.dims(3) });
			auto_grad::Data res = resp;
			res.data() = af::convolve2GradientNN(x.data(), res.grad(), *w, x.data(), // x.data * w => res.data
				af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 }, AF_CONV_GRADIENT_DATA);
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += af::convolve2NN(res.grad(), *w, // res.grad * w => x.grad
					af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 });
				*w_grad += af::convolve2GradientNN(x.data(), res.grad(), *w, x.data(), // res.grad * x.data => w_grad
					af::dim4{ stx,sty,0,0 }, af::dim4{ pdx,pdy,0,0 }, af::dim4{ dilx,dily,0,0 }, AF_CONV_GRADIENT_FILTER);
			});
			return resp;
		}

	public:
		DECONV() { built = false; }
		DECONV(OP_Base* fap,
			af::dim4 Input, // Input[3] is ignored
			std::pair<dim_t, dim_t> Core, dim_t CoreCnt,
			std::pair<dim_t, dim_t> Stride = { 1,1 },
			std::pair<dim_t, dim_t> Padding = { 0,0 },
			std::pair<dim_t, dim_t> Dilation = { 1,1 },
			int InitType = Init_He,
			af::dtype type = f32) :OP_Base(fap)
		{
			built = true;
			inh = Input[0], inw = Input[1], inc = Input[2];
			ch = Core.first, cw = Core.second, cnt = CoreCnt;
			stx = Stride.first, sty = Stride.second;
			pdx = Padding.first, pdy = Padding.second;
			dilx = Dilation.first, dily = Dilation.second;
			ouh = (inh + pdx * 2 - (ch - 1) * dilx - 1) / stx + 1, ouw = (inw + pdy * 2 - (cw - 1) * dily - 1) / sty + 1;
			af::dim4 core_shape = af::dim4{ ch,cw,inc,cnt };
			w = new af::array(core_shape, type);
			w_grad = new af::array(core_shape, type);
			reg_para(w, w_grad);
			// init wei
			*w = af::randn(core_shape, type);
			if (InitType == Init_He) *w *= sqrt(2 / (double)(ch * cw * inc));
			else                     *w *= sqrt(1 / (double)(ch * cw * inc));
		}
	};

}
