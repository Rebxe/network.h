#pragma once

// Full Connection layer

namespace network
{

class FC : public OP_Base
{
public:
	read_only<bool,FC> built;
	read_only<int,FC> ins, ous; // out: ous*1*1

private:
	float *w,*w_grad;
	
private:
	void forward(auto_dao::Data_Node& in,auto_dao::Data_Node& out)
	{
		int n=in.n;
		ext_assert(in.d*in.h*in.w==ins,
			fprintf(stderr,"\
In val4d* FC::operator()(auto_dao::Data_Node& x)\n\
  ins = %d\n\
  ous = %d\n\
  x = [%d * %d * %d * %d]\n\
But\n\
  %d * %d * %d != %d\n\n",ins,ous,n,in.d,in.h,in.w,in.d,in.h,in.w,ins));
		Matrix_Mul(n,ins,ous,in.data(),false,w,false,out.data());
	}
	void backward(std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		int n=inp->n;
		Matrix_Mul(n,ous,ins,out->grad(),false,w,true,inp->grad());
		Matrix_Mul(ins,n,ous,inp->data(),true,out->grad(),false,w_grad);
	}

public:
	void save(std::ofstream& ouf)
	{
		if(built) writf(ouf,w,ins*ous);
		auto_save(ouf);
	}
	void load(std::ifstream& inf)
	{
		if(built) readf(inf,w,ins*ous);
		auto_load(inf);
	}
	void delthis()
	{
		if(built) delete[] w,delete[] w_grad;
		built=false;
		auto_delthis();
	}

public:
	val4d* operator()(auto_dao::Data_Node& x)
	{
		ext_assert(built,
			fprintf(stderr,"\
In val4d FC::operator()(auto_dao::Data_Node& x)\n\
  this hasn't been initalized yet\n\n"));
  		val4d* res=tmp<val4d>((shape4d){x.n,ous,1,1});
		forward(x,*res);
		res->getdat().regop({&x},std::bind(&FC::backward,this,std::placeholders::_1,std::placeholders::_2));
		return res;
	}
	
public:
	FC(){built=false;}
	FC(OP_Base* fap,int INS,int OUS,int InitType=Init_He):OP_Base(fap)
	{
		built=true;
		ins=INS,ous=OUS;
		w=new float[ins*ous],w_grad=new float[ins*ous];
		reg_para(ins*ous,w,w_grad);
		// init wei
		std::default_random_engine gen;
		std::normal_distribution<float> wer;
		if (InitType == Init_He) wer = std::normal_distribution<float>(0, sqrt(2 / (float)ins));
		else                     wer = std::normal_distribution<float>(0, sqrt(1 / (float)ins));
		gen.seed(time(NULL));
		for (int i = 0; i < ins * ous; i++) w[i] = wer(gen);
	}
};

}
