#pragma once

// Full Connection layer

namespace network
{

	class FC : public OP_Base
	{
	public:
		read_only<bool, FC> built;
		read_only<dim_t, FC> ins, ous; // out: 1*1*ous*N

	private:
		af::array *w, *w_grad;

	public:
		void save(std::ofstream& ouf)
		{
			if (built) writf(ouf, *w);
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (built) readf(inf, *w);
			auto_load(inf);
		}
		void delthis()
		{
			if (built) delete w, delete w_grad;
			built = false;
			auto_delthis();
		}

	public:
		af::dtype type() const
		{
			ext_assert(built, fprintf(stderr, "\
In af::dtype FC::type() const\n\
  this hasn't been initalized yet\n\n"));
			return w->type();
		}
		val4d* operator()(auto_grad::Data x)
		{
			ext_assert(built, fprintf(stderr, "\
In val4d FC::operator()(auto_grad::Data x)\n\
  this hasn't been initalized yet\n\n"));
			ext_assert(x.dims(0) * x.dims(1) * x.dims(2) == ins, fprintf(stderr, "\
In val4d* FC::operator()(auto_grad::Data x)\n\
  ins = %lld\n\
  ous = %lld\n\
  x = [%lld * %lld * %lld * %lld]\n\n",
				(long long)ins,
				(long long)ous,
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3)));
			OP_Base* fax = x.getfa();
			val4d* resp = tmp<val4d>(af::dim4{ 1,1,ous,x.dims(3) }, x.type());
			auto_grad::Data res = resp;
			res.data() = af::moddims(af::matmul(
				af::moddims(x.data(), { 1,ins,1,x.dims(3) }),
				*w
			), { 1,1,ous,x.dims(3) });
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += af::moddims(af::matmulNT(
					af::moddims(res.grad(), { 1,ous,1,x.dims(3) }),
					*w
				), x.dims());
				*w_grad += af::sum(af::matmul(
					af::moddims(x.data(), { ins,1,1,x.dims(3) }),
					af::moddims(res.grad(), { 1,ous,1,x.dims(3) })
				), 3);
				});
			return resp;
		}

	public:
		FC() { built = false; }
		FC(OP_Base* fap, dim_t INS, dim_t OUS, int InitType = Init_He, af::dtype type = f32) :OP_Base(fap)
		{
			built = true;
			ins = INS, ous = OUS;
			w = new af::array(ins, ous, type);
			w_grad = new af::array(ins, ous, type);
			reg_para(w, w_grad);
			// init wei
			*w = af::randn(ins, ous, type);
			if (InitType == Init_He) *w *= sqrt(2 / (double)ins);
			else                     *w *= sqrt(1 / (double)ins);
		}
	};

}