#pragma once

#include "OS_Headers/stb/stb_image.h"
#include "OS_Headers/stb/stb_image_write.h"

namespace network
{

template<typename T>
void readf(std::ifstream& inf, T &x){inf.read((char*)&x,sizeof(T));}
template<typename T>
void readf(std::ifstream& inf, T *x, int siz){inf.read((char*)x,sizeof(T)*siz);}

template<typename T>
void writf(std::ofstream& ouf, T x){ouf.write((char*)&x,sizeof(T));}
template<typename T>
void writf(std::ofstream& ouf, T *x, int siz){ouf.write((char*)x,sizeof(T)*siz);}

float3d readimg(std::string path,float* buf,float l=-1,float r=1)
{
	int h,w,d;
	auto data=stbi_load(path.c_str(),&h,&w,&d,0);
	float3d img(d,h,w,buf);
	for(int i=0,p=0;i<h;i++)
		for(int j=0;j<w;j++)
			for(int k=0;k<d;k++) img[k][i][j]=data[p++]/(float)255*(r-l)+l;
	stbi_image_free(data);
	return img;
}

void savejpg(std::string path,float3d img,float l=-1,float r=1,
	int quality=100/*[1,100]*/)
{
	int h=img.h,w=img.w,d=img.d;
	auto tmp=new unsigned char[h*w*d];
	for(int i=0,p=0;i<h;i++)
		for(int j=0;j<w;j++)
			for(int k=0;k<d;k++)
			{
				int x=(img[k][i][j]-l)/(r-l)*255;
				tmp[p++]=(std::max)(0,(std::min)(x,255));
			}
	stbi_write_jpg(path.c_str(),h,w,d,tmp,quality);
	delete[] tmp;
}

void savepng(std::string path,float3d img,float l=-1,float r=1)
{
	int h=img.h,w=img.w,d=img.d;
	auto tmp=new unsigned char[h*w*d];
	for(int i=0,p=0;i<h;i++)
		for(int j=0;j<w;j++)
			for(int k=0;k<d;k++)
			{
				int x=(img[k][i][j]-l)/(r-l)*255;
				tmp[p++]=(std::max)(0,(std::min)(x,255));
			}
	stbi_write_png(path.c_str(),h,w,d,tmp,0);
	delete[] tmp;
}

void savebmp(std::string path,float3d img,float l=-1,float r=1)
{
	int h=img.h,w=img.w,d=img.d;
	auto tmp=new unsigned char[h*w*d];
	for(int i=0,p=0;i<h;i++)
		for(int j=0;j<w;j++)
			for(int k=0;k<d;k++)
			{
				int x=(img[k][i][j]-l)/(r-l)*255;
				tmp[p++]=(std::max)(0,(std::min)(x,255));
			}
	stbi_write_bmp(path.c_str(),h,w,d,tmp);
	delete[] tmp;
}

void getfiles(std::string path,std::vector<std::string> &files)
{
    intptr_t hFile=0;
    struct _finddata_t fileinfo;
    std::string p;
    if((hFile=_findfirst(p.assign(path).append("\\*").c_str(),&fileinfo))!=-1)
    {
        do
        {
            if((fileinfo.attrib&_A_SUBDIR))
            {
                if(strcmp(fileinfo.name,".")!=0&&strcmp(fileinfo.name,"..")!=0)
                    getfiles(p.assign(path).append("\\").append(fileinfo.name),files);
            }
            else files.push_back(p.assign(path).append("\\").append(fileinfo.name));
        }while(_findnext(hFile,&fileinfo)==0);
        _findclose(hFile);
    }
}

}
