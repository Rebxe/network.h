#pragma once

namespace network
{

	template<typename T>
	void readf(std::ifstream& inf, T& x) { inf.read((char*)&x, sizeof(T)); }
	template<typename T>
	void readf(std::ifstream& inf, T* x, int siz) { inf.read((char*)x, sizeof(T) * siz); }
    void readf(std::ifstream& inf, af::array& a)
    {
        void* p = new char[a.bytes()];
        inf.read((char*)p, a.bytes());
        switch (a.type())
        {
        case f16:
            a = af::array(a.dims(), (af::half*)p);
            break;
        case f32:
            a = af::array(a.dims(), (float*)p);
            break;
        case f64:
            a = af::array(a.dims(), (double*)p);
            break;
        default:
            ext_assert(false, fprintf(stderr, "Can't read af::array object of types out of {f16,f32,f64} from file"));
            return;
        }
        delete[] p;
    }

	template<typename T>
	void writf(std::ofstream& ouf, T x) { ouf.write((char*)&x, sizeof(T)); }
	template<typename T>
	void writf(std::ofstream& ouf, T* x, int siz) { ouf.write((char*)x, sizeof(T) * siz); }
    void writf(std::ofstream& ouf, af::array& a)
    {
        void* p;
        switch (a.type())
        {
        case f16:
            p = (void*)a.host<af::half>();
            break;
        case f32:
            p = (void*)a.host<float>();
            break;
        case f64:
            p = (void*)a.host<double>();
            break;
        default:
            ext_assert(false, fprintf(stderr, "Can't write af::array object of types out of {f16,f32,f64} to file"));
            return;
        }
        ouf.write((char*)p, a.bytes());
        af::freeHost(p);
    }

}
