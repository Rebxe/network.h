#pragma once

namespace network
{
	class val4d : public OP_Base
	{
		friend class auto_grad::Data;

	private:
		bool fmaster; // is the master of dat
		auto_grad::computing_node::Data_Node* dat;

	private:
		void chk(const char* type, const char* name) const
		{
			ext_assert(dat != 0,fprintf(stderr, "\
In %s val4d::%s\n\
  this hasn't been initalized yet\n\n", type, name));
		}

	public:
		af::dtype type()         const { return chk("af::dtype", "type()"), dat->type(); }
		dim_t dims(unsigned dim) const { return chk("dim_t", "dims(unsigned dim)"), dat->dims(dim); }
		af::dim4 dims()          const { return chk("af::dim4", "dims()"), dat->dims(); }
		dim_t elements()         const { return chk("dim_t", "elements()"), dat->elements(); }
		af::array& data() { return chk("af::array&", "data()"), dat->data(); }
		af::array& grad() { return chk("af::array&", "grad()"), dat->grad(); }
		void backward() { chk("void", "backward()"), dat->backward(); }

	public:
		void save(std::ofstream& ouf)
		{
			if (dat != 0) writf(ouf, data());
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (dat != 0) readf(inf, data());
			auto_load(inf);
		}
		void delthis()
		{
			if (fmaster && dat != 0) delete dat, dat = 0;
			auto_delthis();
		}
		void init_forward()
		{
			if (fmaster && dat != 0) dat->clearop();
			auto_init_forward();
		}

	public:
		val4d() { fmaster = false, dat = 0; }
		val4d(OP_Base* fap, auto_grad::computing_node::Data_Node& x);
		val4d(OP_Base* fap, af::dim4 dims, af_dtype type = f32);
		template<typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type> val4d(OP_Base* fap, af::dim4 dims, T val, af_dtype type = f32);
	};
}

namespace network
{
	val4d::val4d(OP_Base* fap, auto_grad::computing_node::Data_Node& x) :OP_Base(fap)
	{
		ext_assert(fap == x.getfa(), fprintf(stderr, "\
In val4d::val4d(OP_Base* fap,auto_dao::Data_Node& x)\n\
  fap is not equal to the owner of x\n\n"));
		fmaster = false;
		dat = &x;
	}
	val4d::val4d(OP_Base* fap, af::dim4 dims, af_dtype type) :OP_Base(fap)
	{
		fmaster = true;
		dat = new auto_grad::computing_node::Data_Node(this, false, dims, type);
		data() = 0;
	}
	template<typename T, typename> val4d::val4d(OP_Base* fap, af::dim4 dims, T val, af_dtype type) :OP_Base(fap)
	{
		fmaster = true;
		dat = new auto_grad::computing_node::Data_Node(this, false, dims, type);
		data() = val;
	}
}