#pragma once

namespace network
{
	// _0
	af::array sdim(const af::array& x, const char* from, const char* to);
	af::array reduse(const af::array& x, const af::dim4& dims);

	// _1
	val4d* reshape(auto_grad::Data x, af::dim4 dims, bool inplace = false);
	val4d* tile(auto_grad::Data x, af::dim4 dims);
	val4d* sdim(auto_grad::Data x, const char* from, const char* to, bool inplace = false); // example: from = "NDHW" to = "NDWH"

	// _2
	val4d* add(auto_grad::Data x, auto_grad::Data y);
	val4d* minus(auto_grad::Data x, auto_grad::Data y);
	val4d* mul(auto_grad::Data x, auto_grad::Data y);
	val4d* divide(auto_grad::Data x, auto_grad::Data y);
	template <typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
	val4d* add(auto_grad::Data x, T y, bool inplace = false);
	template <typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
	val4d* minus(T x, auto_grad::Data y, bool inplace = false);
	template <typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
	val4d* mul(auto_grad::Data x, T y, bool inplace = false);
	template <typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
	val4d* divide(T x, auto_grad::Data y, bool inplace = false);

	// _3
	val4d* matmul(auto_grad::Data x, auto_grad::Data y);
	val4d* matmulNT(auto_grad::Data x, auto_grad::Data y);
	val4d* matmulTN(auto_grad::Data x, auto_grad::Data y);
	template <typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type>
	val4d* masked(auto_grad::Data x, const af::array& mask, T val, bool inplace = false); // x(mask) = val

	// _4
	val4d* relu(auto_grad::Data x, bool inplace = false);
	val4d* leaky_relu(auto_grad::Data x, float a = 0.01, bool inplace = false);
	val4d* sigmoid(auto_grad::Data x, bool inplace = false);
	val4d* tanh(auto_grad::Data x, bool inplace = false);
	val4d* softmax(auto_grad::Data x, int dim, bool inplace = false); // dim in [0,3]

	// _5
	double MSEloss(auto_grad::Data x, const af::array& realout, bool mean = true);
	double CEloss(auto_grad::Data x, const af::array& realout, bool mean = true, double EPS = 1e-7);
	double BCEloss(auto_grad::Data x, const af::array& realout, bool mean = true, double EPS = 1e-7);

	// _6
	val4d* max_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core, double EPS = 1e-7);
	val4d* mean_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core);
	val4d* upsample(auto_grad::Data x, std::pair<dim_t, dim_t> Fill); // untest

	// _7
	val4d* concat(std::vector<auto_grad::Data> inlist, int dim);  // dim in [0,3]
}

#include "op/_0.h"
#include "op/_1.h"
#include "op/_2.h"
#include "op/_3.h"
#include "op/_4.h"
#include "op/_5.h"
#include "op/_6.h"
#include "op/_7.h"
