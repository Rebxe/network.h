#pragma once

namespace network
{

val4d* concat(std::vector<auto_grad::Data> inlist,int dim)
{
	std::vector<auto_grad::Data_Node*> in;
	for(auto &x:inlist) in.push_back(x); 
	ext_assert(in.size()>0,
		fprintf(stderr,"\
In val4d* concat(std::vector<auto_grad::Data> inlist,int dim)\n\
  in is empty\n\n"));
	ext_assert(1<=dim&&dim<=4,
		fprintf(stderr,"\
In val4d* concat(std::vector<auto_grad::Data> inlist,int dim)\n\
  dim = %d is out of the range [1,4]\n\n",dim));
#ifndef NDEBUG
{
	for(auto_grad::Data_Node* x:in)
		ext_assert(x->data().size()>0,
			fprintf(stderr,"\
In val4d* concat(std::vector<auto_grad::Data> inlist,int dim)\n\
  one of the input is empty\n\n"));
	int n=1;
	for(auto_grad::Data_Node* x:in) n=(std::max)(n,(int)x->n);
	shape4d shape={n,in[0]->d,in[0]->h,in[0]->w};
	int idx=0;
	for(auto &x:in)
	{
		idx++;
		shape4d pre={x->train?n:(int)x->n,x->d,x->h,x->w};
		bool f=true;
		for(int i=0;i<4&&f;i++) f&=i==dim-1||pre[i]==shape[i];
		ext_assert(f,
			fprintf(stderr,"\
In val4d* concat(std::vector<auto_grad::Data> inlist,int dim)\n\
  dim = %d\n\
  1st of in is [%d * %d * %d * %d]%s\n\
but\n\
  %dth of in is [%d * %d * %d * %d]%s\n",dim,
  			(int)in[0]->n,shape[1],shape[2],shape[3],in[0]->train?" (train)":"",
			idx,(int)x->n,pre[1],pre[2],pre[3],x->train?" (train)":""));
	}
}
#endif
/******************************* end assertion **********************************/
	auto_grad::Data_Node* xp=in[0];
	OP_Base* fax=xp->getfa();
	val4d* res;
	if(dim==1)
	{
		shape4d shape={0,xp->d,xp->h,xp->w};
		for(auto_grad::Data_Node* x:in) shape[0]+=x->n;
		// forward
		res=fax->tmp<val4d>(shape);
		int sm=0;
		for(auto_grad::Data_Node* x:in)
		{
			memcpy(res->data()[sm],x->data(),x->data().size());
			sm+=x->n;
		}
		// backward
		res->getdat().regop(in,[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
		{
			int sm=0;
			for(auto_grad::Data_Node* x:in)
			{
				float *og=out->grad()[sm],*xg=x->grad();
				int siz=x->grad().size();
				for(int i=0;i<siz;i++) xg[i]+=og[i];
				sm+=x->n;
			}
		});
	}
	else
	{
		shape4d shape={xp->n,xp->d,xp->h,xp->w};
		shape[dim-1]=0;
		for(auto_grad::Data_Node* x:in)
		{
			shape[0]=(std::max)(shape[0],(int)x->n);
			if(dim==2) shape[1]+=x->d;
			if(dim==3) shape[2]+=x->h;
			if(dim==4) shape[3]+=x->w;
		}
		// forward
		res=fax->tmp<val4d>(shape);
		for(int i=0;i<shape[0];i++)
		{
			float3d ra=res->data()[i];
			int sm=0;
			for(auto_grad::Data_Node* x:in)
			{
				float3d xa=x->data()[i%x->n];
				for(int j=0;j<x->d;j++)
					for(int k=0;k<x->h;k++)
						for(int l=0;l<x->w;l++)
						{
							int pos[3]={j,k,l};
							pos[dim-2]+=sm;
							ra[pos[0]][pos[1]][pos[2]]=xa[j][k][l];
						}
				if(dim==2) sm+=x->d;
				if(dim==3) sm+=x->h;
				if(dim==4) sm+=x->w;
			}
		}
		// backward
		res->getdat().regop(in,[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
		{
			for(int i=0;i<shape[0];i++)
			{
				float3d rg=res->grad()[i];
				int sm=0;
				for(auto_grad::Data_Node* x:in)
				{
					float3d xg=x->grad()[i%x->n];
					for(int j=0;j<x->d;j++)
						for(int k=0;k<x->h;k++)
							for(int l=0;l<x->w;l++)
							{
								int pos[3]={j,k,l};
								pos[dim-2]+=sm;
								xg[j][k][l]+=rg[pos[0]][pos[1]][pos[2]];
							}
					if(dim==2) sm+=x->d;
					if(dim==3) sm+=x->h;
					if(dim==4) sm+=x->w;
				}
			}
		});
	}
	return res;
}

std::vector<val4d*> split(auto_grad::Data x,int dim,int k)
{
#ifndef NDEBUG
{
	ext_assert(1<=dim&&dim<=4,
		fprintf(stderr,"\
In std::vector<val4d*> split(auto_grad::Data x,int dim,int k)\n\
  dim = %d is out of the range [1,4]\n\n",dim));
  	shape4d shape={x.n,x.d,x.h,x.w};
	ext_assert(shape[dim-1]%k==0,
		fprintf(stderr,"\
In std::vector<val4d*> split(auto_grad::Data x,int dim,int k)\n\
  x   = [%d * %d * %d * %d]\n\
  dim = %d\n\
  k   = %d\n\
but\n\
  %d %% %d != 0\n\n",shape[0],shape[1],shape[2],shape[3],dim,k,shape[dim-1],k));
}
#endif
/******************************* end assertion **********************************/
  	shape4d shape={x.n,x.d,x.h,x.w};
  	shape[dim-1]/=k;
	OP_Base* fax=x.getfa();
	std::vector<val4d*> res(k,fax->tmp<val4d>(shape));
	float4d xa=x.data();
	int sm=0;
	for(val4d* r:res)
	{
		// forward
		float4d ra=r->data();
		for(int i=0;i<shape[0];i++)
			for(int j=0;j<shape[1];j++)
				for(int k=0;k<shape[2];k++)
					for(int l=0;l<shape[3];l++)
					{
						int pos[4]={i,j,k,l};
						pos[dim-1]+=sm;
						ra[i][j][k][l]=xa[pos[0]][pos[1]][pos[2]][pos[3]];
					}
		// backward
		r->getdat().regop({x},[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
		{
			float4d xg=in[0]->grad();
			float4d rg=out->grad();
			for(int i=0;i<shape[0];i++)
				for(int j=0;j<shape[1];j++)
					for(int k=0;k<shape[2];k++)
						for(int l=0;l<shape[3];l++)
						{
							int pos[4]={i,j,k,l};
							pos[dim-1]+=sm;
							xg[pos[0]][pos[1]][pos[2]][pos[3]]+=rg[i][j][k][l];
						}
		});
		sm+=shape[dim-1];
	}
	return res; 
}

}
