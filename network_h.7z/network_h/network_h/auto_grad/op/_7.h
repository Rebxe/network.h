#pragma once

namespace network
{

	val4d* concat(std::vector<auto_grad::Data> inlist, int dim)
	{
		ext_assert(inlist.size() > 1,
			fprintf(stderr, "\
In val4d* concat(std::vector<auto_grad::Data> inlist, int dim)\n\
  inlist.size() = %d\n\n", (int)inlist.size()));
		ext_assert(0<=dim&&dim<4,
			fprintf(stderr, "\
In val4d* concat(std::vector<auto_grad::Data> inlist, int dim)\n\
  dim = %d is out of range [0,3]\n\n", (int)dim));
		af::array tmp = inlist[0].data();
		for (int i = 1; i < inlist.size(); i++) tmp = af::join(dim, tmp, inlist[i].data());
		OP_Base* fax = inlist[0].getfa();
		val4d* resp = fax->tmp<val4d>(tmp.dims(), tmp.type());
		auto_grad::Data res = resp;
		res.data() = tmp;
		res.regop(inlist, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			int sz = in.size();
			std::vector<dim_t> lb(sz);
			lb[0] = 0;
			for (int i = 1; i < sz; i++) lb[i] = lb[i - 1] + in[i - 1].dims(dim);
			auto_grad::Data res = out;
			for (int i = 0; i < sz; i++)
			{
				af::seq tmp = af::seq(lb[i], lb[i] + in[i].dims(dim) - 1);
				if (dim == 0) in[i].grad() += res.grad()(tmp, af::span, af::span, af::span);
				if (dim == 1) in[i].grad() += res.grad()(af::span, tmp, af::span, af::span);
				if (dim == 2) in[i].grad() += res.grad()(af::span, af::span, tmp, af::span);
				if (dim == 3) in[i].grad() += res.grad()(af::span, af::span, af::span, tmp);
			}
		});
		return resp;
	}

}
