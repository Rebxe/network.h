#pragma once

namespace network
{

	val4d* add(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(x.dims(), x.type());
		auto_grad::Data res = resp;
		res.data() = x.data() + y.data();
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(res.grad(), x.dims());
			y.grad() += reduse(res.grad(), y.dims());
			});
		return resp;
	}
	val4d* minus(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(x.dims(), x.type());
		auto_grad::Data res = resp;
		res.data() = x.data() - y.data();
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(res.grad(), x.dims());
			y.grad() -= reduse(res.grad(), x.dims());
			});
		return resp;
	}
	val4d* mul(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(x.dims(), x.type());
		auto_grad::Data res = resp;
		res.data() = x.data() * y.data();
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(res.grad() * y.data(), x.dims());
			y.grad() += reduse(res.grad() * x.data(), y.dims());
			});
		return resp;
	}
	val4d* divide(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(x.dims(), x.type());
		auto_grad::Data res = resp;
		res.data() = x.data() / y.data();
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(res.grad() / y.data(), x.dims());
			y.grad() += reduse(res.grad() * (-1 / (y.data() * y.data())) * x.data(), y.dims());
			});
		return resp;
	}
	template <typename T, typename>
	val4d* add(auto_grad::Data x, T y, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = x.data() + y;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += res.grad();
				});
		}
		else
		{
			x.data() += y;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.data() -= y;
				});
		}
		return resp;
	}
	template <typename T, typename>
	val4d* minus(T x, auto_grad::Data y, bool inplace)
	{
		OP_Base* fay = y.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fay->tmp<val4d>(y.dims(), y.type());
			auto_grad::Data res = resp;
			res.data() = x - y.data();
			res.regop({ y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data y = in[0];
				auto_grad::Data res = out;
				y.grad() -= res.grad();
				});
		}
		else
		{
			y.data() = x - y.data();
			resp = fay->tmp<val4d>(y);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data y = out;
				y.grad() = -y.grad();
				y.data() = x - y.data();
				});
		}
		return resp;
	}
	template <typename T, typename>
	val4d* mul(auto_grad::Data x, T y, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = x.data() * y;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += res.grad() * y;
				});
		}
		else
		{
			x.data() *= y;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() *= y;
				x.data() /= y;
				});
		}
		return resp;
	}
	template <typename T, typename>
	val4d* divide(T x, auto_grad::Data y, bool inplace)
	{
		OP_Base* fay = y.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fay->tmp<val4d>(y.dims(), y.type());
			auto_grad::Data res = resp;
			res.data() = x / y.data();
			res.regop({ y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data y = in[0];
				auto_grad::Data res = out;
				y.grad() = res.grad() * x * (-1 / (y.data() * y.data()));
				});
		}
		else
		{
			y.data() = x / y.data();
			resp = fay->tmp<val4d>(y);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data y = out;
				y.data() = x / y.data();
				y.grad() = y.grad() * x * (-1 / (y.data() * y.data()));
				});
		}
		return resp;
	}
}