#pragma once

namespace network
{

	val4d* matmul(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(af::dim4{ x.dims(0),y.dims(1),(std::max)(x.dims(2),y.dims(2)),(std::max)(x.dims(3),y.dims(3)) }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::matmul(x.data(), y.data());
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(af::matmulNT(res.grad(), y.data()), x.dims());
			y.grad() += reduse(af::matmulTN(x.data(), res.grad()), y.dims());
			});
		return resp;
	}
	val4d* matmulNT(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(af::dim4{ x.dims(0),y.dims(0),(std::max)(x.dims(2),y.dims(2)),(std::max)(x.dims(3),y.dims(3)) }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::matmulNT(x.data(), y.data());
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(af::matmul(res.grad(), y.data()), x.dims());
			y.grad() += reduse(af::matmulTN(res.grad(), x.data()), y.dims());
			});
		return resp;
	}
	val4d* matmulTN(auto_grad::Data x, auto_grad::Data y)
	{
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(af::dim4{ x.dims(0),y.dims(0),(std::max)(x.dims(2),y.dims(2)),(std::max)(x.dims(3),y.dims(3)) }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::matmulTN(x.data(), y.data());
		res.regop({ x,y }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0], y = in[1];
			auto_grad::Data res = out;
			x.grad() += reduse(af::matmulNT(y.data(), res.grad()), x.dims());
			y.grad() += reduse(af::matmul(x.data(), res.grad()), y.dims());
			});
		return resp;
	}
	template<typename T, typename>
	val4d* masked(auto_grad::Data x, const af::array& mask, T val, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = x.data();
			res.data()(mask) = val;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				af::array tmp = res.grad();
				tmp(mask) = 0;
				x.grad() += tmp;
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data()(mask) = val;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad()(mask) = 0;
				x.data() = *mem->tmp;
				});
		}
		return resp;
	}
	
}