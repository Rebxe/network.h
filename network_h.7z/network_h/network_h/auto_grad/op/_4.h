#pragma once

namespace network
{

	val4d* relu(auto_grad::Data x, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = (af::max)(0, x.data());
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				af::array tmp = res.grad();
				tmp(x.data() < 0) = 0;
				x.grad() += tmp;
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data() = (af::max)(0, x.data());
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.data() = *mem->tmp;
				x.grad()(x.data() < 0) = 0;
				});
		}
		return resp;
	}
	val4d* leaky_relu(auto_grad::Data x, float a, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = x.data();
			res.data()(x.data() < 0) *= a;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				af::array tmp = res.grad();
				tmp(x.data() < 0) *= a;
				x.grad() += tmp;
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data()(x.data() < 0) *= a;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.data() = *mem->tmp;
				x.grad()(x.data() < 0) *= a;
				});
		}
		return resp;
	}
	val4d* sigmoid(auto_grad::Data x, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = af::sigmoid(x.data());
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += res.grad() * res.data() * (1 - res.data());
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data() = af::sigmoid(x.data());
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() *= x.data() * (1 - x.data());
				x.data() = *mem->tmp;
				});
		}
		return resp;
	}
	val4d* tanh(auto_grad::Data x, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = af::tanh(x.data());
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += res.grad() * (1 - res.data() * res.data());
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data() = af::tanh(x.data());
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() *= 1 - x.data() * x.data();
				x.data() = *mem->tmp;
				});
		}
		return resp;
	}
	val4d* softmax(auto_grad::Data x, int dim, bool inplace)
	{
		OP_Base* fax = x.getfa();
		val4d* resp;
		af::array tmp = x.data() - (af::max)(x.data(), dim);
		tmp = af::exp(tmp);
		tmp = tmp / af::sum(tmp, dim);
		if (!inplace)
		{
			resp = fax->tmp<val4d>(x.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = tmp;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += res.data() * (res.grad() - af::sum(res.data() * res.grad(), dim));
				});
		}
		else
		{
			class TMP_MEM : public OP_Base
			{
			public:
				af::array* tmp;
				TMP_MEM(OP_Base* fap, const af::array& val) :OP_Base(fap) { tmp = new af::array(val); }
				void delthis() { delete tmp, auto_delthis(); }
			};
			TMP_MEM* mem = fax->tmp<TMP_MEM>(x.data());
			x.data() = tmp;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() = x.data() * (x.grad() - af::sum(x.data() * x.grad(), dim));
				x.data() = *mem->tmp;
				});
		}
		return resp;
	}

}