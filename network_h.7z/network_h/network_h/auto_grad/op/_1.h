#pragma once

namespace network
{
	val4d* reshape(auto_grad::Data x, af::dim4 dims, bool inplace)
	{
		ext_assert(x.elements() == dims[0] * dims[1] * dims[2] * dims[3], fprintf(stderr, "\
In val4d* reshape(auto_grad::Data x, af::dim4 dims, bool inplace)\n\
  x    = [%d * %d * %d * %d]\n\
  dims = [%d * %d * %d * %d]\n\n",
			x.dims(0), x.dims(1), x.dims(2), x.dims(3),
			dims[0], dims[1], dims[2], dims[3]));
		/******************************* end assertion **********************************/
		auto in_dim = x.dims();
		OP_Base* fax = x.getfa();
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(dims, x.type());
			auto_grad::Data res = resp;
			res.data() = af::moddims(x.data(), dims);
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += af::moddims(res.grad(), in_dim);
				});
		}
		else
		{
			x.grad() = af::moddims(x.grad(), dims);
			x.data() = af::moddims(x.data(), dims);
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() = af::moddims(x.grad(), in_dim);
				x.data() = af::moddims(x.data(), in_dim);
				});
		}
		return resp;
	}
	val4d* tile(auto_grad::Data x, af::dim4 dims)
	{
		auto odims = x.dims();
		OP_Base* fax = x.getfa();
		val4d* resp = fax->tmp<val4d>(dims, x.type());
		auto_grad::Data res = resp;
		res.data() = af::tile(x.data(), dims);
		res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0];
			auto_grad::Data res = out;
			for (int i = 0; i < dims[0]; i++)
				for (int j = 0; j < dims[1]; j++)
					for (int k = 0; k < dims[2]; k++)
						for (int l = 0; l < dims[3]; l++)
						{
							x.grad() += res.grad()(
								af::seq(i * odims[0], i * odims[0] + odims[0] - 1),
								af::seq(j * odims[1], j * odims[1] + odims[1] - 1),
								af::seq(k * odims[2], k * odims[2] + odims[2] - 1),
								af::seq(l * odims[3], l * odims[3] + odims[3] - 1)
								);
						}
			});
		return resp;
	}
	val4d* sdim(auto_grad::Data x, const char* from, const char* to, bool inplace)
	{
		OP_Base* fax = x.getfa();
		af::array res_data = sdim(x.data(), from, to);
		val4d* resp;
		if (!inplace)
		{
			resp = fax->tmp<val4d>(res_data.dims(), x.type());
			auto_grad::Data res = resp;
			res.data() = res_data;
			res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = in[0];
				auto_grad::Data res = out;
				x.grad() += sdim(res.grad(), to, from);
				});
		}
		else
		{
			x.grad() = sdim(x.grad(), from, to);
			x.data() = res_data;
			resp = fax->tmp<val4d>(x);
			auto_grad::Data res = resp;
			res.addop([=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
				auto_grad::Data x = out;
				x.grad() = sdim(x.grad(), to, from);
				x.data() = sdim(x.data(), to, from);
				});
		}
		return resp;
	}
}