#pragma once

namespace network
{

	double MSEloss(auto_grad::Data x, const af::array& realout, bool mean)
	{
		dim_t div = (mean ? x.elements() : x.dims(3));
		double res = af::sum<double>((x.data() - realout) * (x.data() - realout)) / div;
		x.grad() += 2 * (x.data() - realout) / div;
		return res;
	}
	double CEloss(auto_grad::Data x, const af::array& realout, bool mean, double EPS)
	{
		dim_t div = (mean ? x.elements() : x.dims(3));
		af::array tmp = (af::max)(EPS, x.data());
		double res = af::sum<double>(-realout * af::log(tmp)) / div;
		x.grad() += -(realout * (1 / tmp)) / div;
		return res;
	}
	double BCEloss(auto_grad::Data x, const af::array& realout, bool mean, double EPS)
	{
		dim_t div = (mean ? x.elements() : x.dims(3));
		af::array tmp = (af::min)((af::max)(EPS, x.data()), 1 - EPS);
		double res = af::sum<double>(-(realout * af::log(tmp) + (1 - realout) * af::log(1 - tmp))) / div;
		x.grad() += -(realout * (1 / tmp) - (1 - realout) * (1 / (1 - tmp))) / div;
		return res;
	}

}