#pragma once

namespace network
{

	af::array sdim(const af::array& x, const char* from, const char* to)
	{
		assert(strlen(from) == 4 && strlen(to) == 4);
#ifndef NDEBUG
		for (int i = 0; i < 4; i++)
			for (int j = i + 1; j < 4; j++)
				ext_assert(from[i] != from[j],
					fprintf(stderr, "\
In af::array sdim(const af::array& x, const char* from, const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' appears more than once in \"%s\"\n\n", from, to, from[i], from));
#endif
		int p[4] = { -1,-1,-1,-1 };
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4 && p[i] == -1; j++) if (to[i] == from[j]) p[i] = j;
			ext_assert(p[i] != -1,
				fprintf(stderr, "\
In af::array sdim(const af::array& x, const char* from, const char* to)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' in \"%s\" does not appear in \"%s\"\n\n", from, to, to[i], to, from));
		}
		/******************************* end assertion **********************************/
		return af::reorder(x, p[0], p[1], p[2], p[3]);
	}
	af::array reduse(const af::array& x, const af::dim4& dims)
	{
		af::array res = x;
		for (int i = 0; i < 4; i++)
			if (x.dims(i) != 1 && dims[i] == 1) res = af::sum(res, i);
		return res;
	}

}