#pragma once

namespace network
{

	val4d* max_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core, double EPS)
	{
		dim_t ch = Core.first, cw = Core.second;
		dim_t oh = x.dims(0) / ch, ow = x.dims(1) / cw;
		ext_assert(oh > 0 && ow > 0,
			fprintf(stderr, "\
In val4d* max_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core, double EPS)\n\
  x    = [%lld * %lld * %lld * %lld]\n\
  Core = [%lld * %lld]\n\n",
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3),
				(long long)ch, (long long)cw));
		OP_Base* fax = x.getfa();
		// forward
		af::array tmp = af::unwrap(x.data(), ch, cw, ch, cw, 0, 0);
		af::dim4 dtmp = tmp.dims();
		dim_t cntbatch = dtmp[1] * dtmp[2] * dtmp[3];
		tmp = af::moddims(tmp, af::dim4{ dtmp[0],cntbatch,1,1 });
		tmp = (af::max)(tmp, 0);
		val4d* resp = fax->tmp<val4d>(af::dim4{ 1,cntbatch,1,1 }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::moddims(tmp, af::dim4{ oh,ow,x.dims(2),x.dims(3) });
		// backward
		res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0];
			auto_grad::Data res = out;
			af::array tmp = af::unwrap(x.data(), ch, cw, ch, cw, 0, 0);
			af::dim4 dtmp = tmp.dims();
			dim_t cntbatch = dtmp[1] * dtmp[2] * dtmp[3];
			tmp = af::moddims(tmp, af::dim4{ dtmp[0],cntbatch,1,1 });
			af::array tmpg = af::array(af::dim4{ dtmp[0],cntbatch,1,1 }, x.type());
			tmpg = 0;
			af::array tres = af::tile(af::moddims(res.grad(), af::dim4{ 1,cntbatch,1,1 }), af::dim4{ dtmp[0],1,1,1 });
			af::array pos = tmp > af::tile(af::moddims(res.data(), af::dim4{ 1,cntbatch,1,1 }), af::dim4{ dtmp[0],1,1,1 }) - EPS;
			tmpg(pos) += tres(pos);
			x.grad()(af::seq(oh * ch), af::seq(ow * cw), af::span, af::span) += af::wrap(af::moddims(tmpg, dtmp), oh * ch, ow * cw, ch, cw, ch, cw, 0, 0);
		});
		return resp;
	}
	val4d* mean_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core)
	{
		dim_t ch = Core.first, cw = Core.second;
		dim_t oh = x.dims(0) / ch, ow = x.dims(1) / cw;
		ext_assert(oh > 0 && ow > 0,
			fprintf(stderr, "\
In val4d* mean_pool(auto_grad::Data x, std::pair<dim_t, dim_t> Core)\n\
  x    = [%lld * %lld * %lld * %lld]\n\
  Core = [%lld * %lld]\n\n",
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3),
				(long long)ch, (long long)cw));
		OP_Base* fax = x.getfa();
		// forward
		af::array tmp = af::unwrap(x.data(), ch, cw, ch, cw, 0, 0);
		af::dim4 dtmp = tmp.dims();
		dim_t cntbatch = dtmp[1] * dtmp[2] * dtmp[3];
		tmp = af::moddims(tmp, af::dim4{ dtmp[0],cntbatch,1,1 });
		tmp = (af::sum)(tmp, 0) / (ch * cw);
		val4d* resp = fax->tmp<val4d>(af::dim4{ 1,cntbatch,1,1 }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::moddims(tmp, af::dim4{ oh,ow,x.dims(2),x.dims(3) });
		// backward
		res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0];
			auto_grad::Data res = out;
			dim_t cntbatch = dtmp[1] * dtmp[2] * dtmp[3];
			af::array tres = af::tile(af::moddims(res.grad(), af::dim4{ 1,cntbatch,1,1 }), af::dim4{ dtmp[0],1,1,1 }) / (ch * cw);
			x.grad()(af::seq(oh * ch), af::seq(ow * cw), af::span, af::span) += af::wrap(af::moddims(tres, dtmp), oh * ch, ow * cw, ch, cw, ch, cw, 0, 0);
		});
		return resp;
	}
	val4d* upsample(auto_grad::Data x, std::pair<dim_t, dim_t> Fill)
	{
		dim_t fh = Fill.first, fw = Fill.second;
		dim_t oh = x.dims(0) * fh, ow = x.dims(1) * fw;
		ext_assert(oh > 0 && ow > 0,
			fprintf(stderr, "\
In val4d* upsample(auto_grad::Data x, std::pair<dim_t, dim_t> Fill)\n\
  x    = [%lld * %lld * %lld * %lld]\n\
  Fill = [%lld * %lld]\n\n",
				(long long)x.dims(0), (long long)x.dims(1), (long long)x.dims(2), (long long)x.dims(3),
				(long long)fh, (long long)fw));
		OP_Base* fax = x.getfa();
		// forward
		af::dim4 dx = x.dims();
		dx[1] *= dx[0], dx[0] = 1;
		af::array tmp = af::tile(af::moddims(x.data(), dx), af::dim4{ fh * fw,1,1,1 });
		val4d* resp = fax->tmp<val4d>(af::dim4{ oh,ow,x.dims(2),x.dims(3) }, x.type());
		auto_grad::Data res = resp;
		res.data() = af::wrap(tmp, oh, ow, fh, fw, fh, fw, 0, 0);
		// backward
		res.regop({ x }, [=](std::vector<auto_grad::Data> in, auto_grad::Data out) {
			auto_grad::Data x = in[0];
			auto_grad::Data res = out;
			af::array tres = af::sum(af::unwrap(res.grad(), fh, fw, fh, fw, 0, 0), 0);
			x.grad() += af::moddims(tres, x.dims());
		});
		return resp;
	}

}