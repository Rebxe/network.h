#pragma once

namespace network
{

val4d* max_pool(auto_grad::Data x,std::pair<int,int> Core,std::pair<int,int> Stride) // -1: equal to Core
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* max_pool(auto_grad::Data x,std::pair<int,int> Core,std::pair<int,int> Stride) // -1: equal to Core\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	int ch=Core.first,cw=Core.second;
	int stx=Stride.first,sty=Stride.second;
	if(stx==-1) stx=ch;
	if(sty==-1) sty=cw;
	int oh=(h+stx-1)/stx,ow=(w+sty-1)/sty;
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape4d{n,d,oh,ow});
	float4d xa=x.data(),ra=res->data();
	const float inf=1e8;
	for(int i=0;i<n;i++)
		for(int j=0;j<d;j++)
			for(int x=0,ix=0;x<h;x+=stx,ix++)
				for(int y=0,iy=0;y<w;y+=sty,iy++)
				{
					float mx=-inf;
					for(int px=x;px<x+ch&&px<h;px++)
						for(int py=y;py<y+cw&&py<w;py++)
							mx=(std::max)(mx,xa[i][j][px][py]);
					ra[i][j][ix][iy]=mx;
				}
	res->getdat().regop({x},[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
	{
		auto_grad::Data_Node* xp=in[0];
		float4d xa=xp->data(),xg=xp->grad();
		float4d ra=out->data(),rg=out->grad();
		const float eps=1e-8;
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int x=0,ix=0;x<h;x+=stx,ix++)
					for(int y=0,iy=0;y<w;y+=sty,iy++)
					{
						float mx=ra[i][j][ix][iy],g=rg[i][j][ix][iy];
						for(int px=x;px<x+ch&&px<h;px++)
							for(int py=y;py<y+cw&&py<w;py++)
								if(fabs(xa[i][j][px][py]-mx)<eps)
									xg[i][j][px][py]+=g;
					}
	});
	return res;
}

val4d* mean_pool(auto_grad::Data x,std::pair<int,int> Core,std::pair<int,int> Stride) // -1: equal to Core
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* mean_pool(auto_grad::Data x,std::pair<int,int> Core,std::pair<int,int> Stride) // -1: equal to Core\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	int ch=Core.first,cw=Core.second;
	int stx=Stride.first,sty=Stride.second;
	if(stx==-1) stx=ch;
	if(sty==-1) sty=cw;
	int oh=(h+stx-1)/stx,ow=(w+sty-1)/sty;
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape4d{n,d,oh,ow});
	float4d xa=x.data(),ra=res->data();
	for(int i=0;i<n;i++)
		for(int j=0;j<d;j++)
			for(int x=0,ix=0;x<h;x+=stx,ix++)
				for(int y=0,iy=0;y<w;y+=sty,iy++)
				{
					float sm=0;
					int tot=0;
					for(int px=x;px<x+ch&&px<h;px++)
						for(int py=y;py<y+cw&&py<w;py++)
							sm+=xa[i][j][px][py],tot++;
					ra[i][j][ix][iy]=sm/tot;
				}
	res->getdat().regop({x},[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
	{
		auto_grad::Data_Node* xp=in[0];
		float4d xg=xp->grad(),rg=out->grad();
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int x=0,ix=0;x<h;x+=stx,ix++)
					for(int y=0,iy=0;y<w;y+=sty,iy++)
					{
						float g=rg[i][j][ix][iy];
						int tot=0;
						for(int px=x;px<x+ch&&px<h;px++)
							for(int py=y;py<y+cw&&py<w;py++)
								tot++;
						for(int px=x;px<x+ch&&px<h;px++)
							for(int py=y;py<y+cw&&py<w;py++)
								xg[i][j][px][py]+=g/tot;
					}
	});
	return res;
}

val4d* upsample(auto_grad::Data x,std::pair<int,int> Fill)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* upsample(auto_grad::Data x,std::pair<int,int> Fill)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	int fh=Fill.first,fw=Fill.second;
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape4d{n,d,h*fh,w*fw});
	float4d xa=x.data(),ra=res->data();
	for(int i=0;i<n;i++)
		for(int j=0;j<d;j++)
			for(int x=0;x<h;x++)
				for(int y=0;y<w;y++)
					for(int k=0;k<fh;k++)
						for(int l=0;l<fw;l++)
							ra[i][j][x*fh+k][y*fw+l]=xa[i][j][x][y];
	res->getdat().regop({x},[=](std::vector<auto_grad::Data_Node*> in,auto_grad::Data_Node* out)
	{
		auto_grad::Data_Node* xp=in[0];
		float4d xg=xp->grad(),rg=out->grad();
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int x=0;x<h;x++)
					for(int y=0;y<w;y++)
						for(int k=0;k<fh;k++)
							for(int l=0;l<fw;l++)
								xg[i][j][x][y]=rg[i][j][x*fh+k][y*fw+l];
	});
	return res;
}

}
