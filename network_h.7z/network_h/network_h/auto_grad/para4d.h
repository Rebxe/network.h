#pragma once

namespace network
{
	class para4d : public OP_Base
	{
		friend class auto_grad::Data;

	private:
		auto_grad::computing_node::Data_Node* dat;

	private:
		void chk(const char* type, const char* name) const
		{
			ext_assert(dat != 0, fprintf(stderr, "\
In %s para4d::%s\n\
  this hasn't been initalized yet\n\n", type, name));
		}

	public:
		af::dtype type()         const { return chk("af::dtype", "type()"), dat->type(); }
		dim_t dims(unsigned dim) const { return chk("dim_t", "dims(unsigned dim)"), dat->dims(dim); }
		af::dim4 dims()          const { return chk("af::dim4", "dims()"), dat->dims(); }
		dim_t elements()         const { return chk("dim_t", "elements()"), dat->elements(); }
		af::array& data() { return chk("af::array&", "data()"), dat->data(); }
		af::array& grad() { return chk("af::array&", "grad()"), dat->grad(); }
		void backward() { chk("void", "backward()"), dat->backward(); }

	public:
		void save(std::ofstream& ouf)
		{
			if (dat != 0) writf(ouf, data());
			auto_save(ouf);
		}
		void load(std::ifstream& inf)
		{
			if (dat != 0) readf(inf, data());
			auto_load(inf);
		}
		void delthis()
		{
			if (dat != 0) delete dat, dat = 0;
			auto_delthis();
		}
		void init_forward()
		{
			if (dat != 0) dat->clearop();
			auto_init_forward();
		}

	public:
		para4d() { dat = 0; }
		para4d(OP_Base* fap, af::dim4 dims, af_dtype type = f32);
		template<typename T, typename = typename std::enable_if<type_check::just_basic_type<T>::value>::type> para4d(OP_Base* fap, af::dim4 dims, T val, af_dtype type = f32);
	};
}

namespace network
{
	para4d::para4d(OP_Base* fap, af::dim4 dims, af_dtype type) : OP_Base(fap)
	{
		dat = new auto_grad::computing_node::Data_Node(this, true, dims, type);
		reg_para(&data(), &grad());
		data() = 0;
	}
	template<typename T, typename> para4d::para4d(OP_Base* fap, af::dim4 dims, T val, af_dtype type) : OP_Base(fap)
	{
		dat = new auto_grad::computing_node::Data_Node(this, true, dims, type);
		reg_para(&data(), &grad());
		data() = val;
	}
}