#pragma once

#include "Optimizer/SGD.h"
#include "Optimizer/Adam.h"