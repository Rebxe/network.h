#pragma once

namespace network
{

// _1
val4d* reshape  (auto_dao::Data x,shape4d shape,bool inplace=false);
val4d* toshape  (auto_dao::Data x,shape4d shape);
val4d* sdim     (auto_dao::Data x,const char* from,const char* to,bool inplace=false); // example: from = "NDHW" to = "NDWH"

// _2
val4d* dotfunc(auto_dao::Data x,auto_dao::Data_Node y,
	std::function<float(float,float)>                              forward, // res=forward(x,y)
	std::function<std::pair<float,float>(float,float,float,float)> backward // make_pair(x_grad,y_grad)=backward(x,y,res,res_grad)
);
val4d* operator+(auto_dao::Data x,auto_dao::Data y);
val4d* operator-(auto_dao::Data x,auto_dao::Data y);
val4d* operator*(auto_dao::Data x,auto_dao::Data y);
val4d* operator/(auto_dao::Data x,auto_dao::Data y);

// _3
val4d* mul   (auto_dao::Data x,float y,bool inplace=false);
val4d* matmul(auto_dao::Data x,auto_dao::Data y);
val4d* masked(auto_dao::Data x,
	std::function<bool(int,int,int,int)> cover,float mask, // if(cover(n,d,h,w)) x[n][d][h][w] = mask
	bool inplace=false
);

// _4
val4d* relu      (auto_dao::Data x,bool inplace=false);
val4d* leaky_relu(auto_dao::Data x,float a=0.01,bool inplace=false);
val4d* sigmoid   (auto_dao::Data x,bool inplace=false);
val4d* tanh      (auto_dao::Data x,bool inplace=false);
val4d* softmax   (auto_dao::Data x,int dim); // dim in [1,4]

// _5
float MSEloss(auto_dao::Data x,float4d realout,bool mean=true);
float CEloss (auto_dao::Data x,float4d realout,bool mean=true);
float BCEloss(auto_dao::Data x,float4d realout,bool mean=true);

// _6
val4d* max_pool (auto_dao::Data x,std::pair<int,int> Core,std::pair<int,int> Stride={-1,-1}); // -1: equal to Core
val4d* mean_pool(auto_dao::Data x,std::pair<int,int> Core,std::pair<int,int> Stride={-1,-1}); // -1: equal to Core
val4d* upsample (auto_dao::Data x,std::pair<int,int> Fill);

// _7
val4d* concat(std::vector<auto_dao::Data> inlist,int dim); // dim in [1,4]
std::vector<val4d*> split(auto_dao::Data x,int dim,int k); // dim in [1,4]

}

#include "op/_1.h"
#include "op/_2.h"
#include "op/_3.h"
#include "op/_4.h"
#include "op/_5.h"
#include "op/_6.h"
#include "op/_7.h"
