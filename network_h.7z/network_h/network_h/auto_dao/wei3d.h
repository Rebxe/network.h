#pragma once

namespace network
{

class wei3d : public OP_Base
{
	private:
		auto_dao::Data_Node* dat;
		
	private:
		void chk(const char* type,const char* name)
		{
			ext_assert(dat!=0,
				fprintf(stderr,"\
In %s wei3d::%s\n\
  this hasn't been initalized yet\n\n",type,name));
		}
		
	public:
		int getd(){return chk("int","getd()"),dat->d;}
		int geth(){return chk("int","geth()"),dat->h;}
		int getw(){return chk("int","getw()"),dat->w;}
	
	public:
		read_func<int> d,h,w;
	
	private:
		void bindfunc()
		{
			d.bind(std::bind(&wei3d::getd,this));
			h.bind(std::bind(&wei3d::geth,this));
			w.bind(std::bind(&wei3d::getw,this)); 
		}
	
	public:
		float3d data(){return chk("float3d","data()"),dat->data()[0];}
		float3d grad(){return chk("float3d","grad()"),dat->grad()[0];}
		void backward(){chk("void","backward()"),dat->backward();}
		auto_dao::Data_Node& getdat(){return chk("auto_dao::Data_Node&","getdat()"),*dat;}
		operator auto_dao::Data_Node&(){return chk("","operator auto_dao::Data_Node&()"),getdat();}
	
	public:
		void save(std::ofstream &ouf)
		{
			writf(ouf,(float*)data(),data().size());
			auto_save(ouf);
		}
		void load(std::ifstream &inf)
		{
			readf(inf,(float*)data(),data().size());
			auto_load(inf);
		}
		void delthis()
		{
			if(dat!=0) delete dat,dat=0;
			auto_delthis();
		}
		void init_forward()
		{
			if(dat!=0) dat->clearop();
			auto_init_forward();
		}
		
	public:
		wei3d(){dat=0,bindfunc();}
		wei3d(OP_Base* fap,shape3d shape,float val=0);
		wei3d(OP_Base* fap,shape3d shape,float* val);
		wei3d(OP_Base* fap,shape3d shape,std::normal_distribution<float> rnd);
};

/***************************** End of definitions *****************************/

wei3d::wei3d(OP_Base* fap,shape3d shape,float val):OP_Base(fap)
{
	dat=new auto_dao::Data_Node(this,shape);
	bindfunc();
	reg_para(dat->data().size(),dat->data(),dat->grad());
	for(int i=0;i<data().size();i++) data().a[i]=val;
}
wei3d::wei3d(OP_Base* fap,shape3d shape,float* val):OP_Base(fap)
{
	dat=new auto_dao::Data_Node(this,shape);
	bindfunc();
	reg_para(dat->data().size(),dat->data(),dat->grad());
	memcpy(data(),val,sizeof(float)*data().size());
}
wei3d::wei3d(OP_Base* fap,shape3d shape,std::normal_distribution<float> rnd):OP_Base(fap)
{
	dat=new auto_dao::Data_Node(this,shape);
	bindfunc();
	reg_para(dat->data().size(),dat->data(),dat->grad());
	std::default_random_engine gen;
	gen.seed(time(NULL));
	for(int i=0;i<data().size();i++) data().a[i]=rnd(gen);
}

}
