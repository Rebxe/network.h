#pragma once

namespace network
{

val4d* mul(auto_dao::Data x,float y,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* mul(auto_dao::Data x,float y,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	OP_Base* fax=x.getfa();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		for(int i=0;i<n*d*h*w;i++) res->data().a[i]=x.data().a[i]*y;
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* xp=in[0];
			for(int i=0;i<n*d*h*w;i++) xp->grad().a[i]+=out->grad().a[i]*y;
		});
	}
	else
	{
		for(int i=0;i<n*d*h*w;i++) x.data().a[i]*=y;
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			for(int i=0;i<n*d*h*w;i++) out->grad().a[i]*=y,out->data().a[i]/=y;
		});
	}
    return res;
}

val4d* matmul(auto_dao::Data x,auto_dao::Data y)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* matmul(auto_dao::Data x,auto_dao::Data y)\n\
  x is empty\n\n"));
	ext_assert((x.train||y.train||x.n==y.n)&&x.d==y.d&&x.w==y.h,
		fprintf(stderr,"\
In val4d* matmul(auto_dao::Data x,auto_dao::Data y)\n\
  x = [%d * %d * %d * %d]%s\n\
  y = [%d * %d * %d * %d]%s\n\n",(int)x.n,(int)x.d,(int)x.h,(int)x.w,x.train?" (train)":"",(int)y.n,(int)y.d,(int)y.h,(int)y.w,y.train?" (train)":""));
/******************************* end assertion **********************************/
	// forward
	int n=std::max(x.n,y.n),d=x.d;
	int xh=x.h,xw=x.w,yw=y.w;
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape4d{n,d,xh,yw});
	if(x.train&&!y.train)
	{
		res->getdat().sdim("nDHW","DHWn"),y.sdim("nDHW","DHWn");
		for(int i=0;i<d;i++)
			Matrix_Mul(xh,xw,yw*n,x.data()[0][i],false,y.data()[i],false,res->data()[i]);
		res->getdat().sdim("DHWn","nDHW"),y.sdim("DHWn","nDHW");
		res->getdat().regop({x,y},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node *xp=in[0],*yp=in[1];
			out->sdim("nDHW","DHWn"),yp->sdim("nDHW","DHWn");
			for(int i=0;i<d;i++)
			{
				Matrix_Mul(xh,yw*n,xw,out->grad()[i],false,yp->data()[i],true,xp->grad()[0][i]);
				Matrix_Mul(xw,xh,yw*n,xp->data()[0][i],true,out->grad()[i],false,yp->grad()[i]);
			}
			out->sdim("DHWn","nDHW"),yp->sdim("DHWn","nDHW");
		});
	}
	else if(!x.train&&y.train)
	{
		res->getdat().sdim("nDHW","DnHW"),x.sdim("nDHW","DnHW");
		for(int i=0;i<d;i++)
			Matrix_Mul(n*xh,xw,yw,x.data()[i],false,y.data()[0][i],false,res->data()[i]);
		res->getdat().sdim("DnHW","nDHW"),x.sdim("DnHW","nDHW");
		res->getdat().regop({x,y},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node *xp=in[0],*yp=in[1];
			out->sdim("nDHW","DnHW"),xp->sdim("nDHW","DnHW");
			for(int i=0;i<d;i++)
			{
				Matrix_Mul(n*xh,yw,xw,out->grad()[i],false,yp->data()[0][i],true,xp->grad()[i]);
				Matrix_Mul(xw,n*xh,yw,xp->data()[i],true,out->grad()[i],false,yp->grad()[0][i]);
			}
			out->sdim("DnHW","nDHW"),xp->sdim("DnHW","nDHW");
		});
	}
	else
	{
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				Matrix_Mul(xh,xw,yw,x.data()[i][j],false,y.data()[i][j],false,res->data()[i][j]);
		res->getdat().regop({x,y},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node *xp=in[0],*yp=in[1];
			for(int i=0;i<n;i++)
				for(int j=0;j<d;j++)
				{
					Matrix_Mul(xh,yw,xw,out->grad()[i][j],false,yp->data()[i][j],true,xp->grad()[i][j]);
					Matrix_Mul(xw,xh,yw,xp->data()[i][j],true,out->grad()[i][j],false,yp->grad()[i][j]);
				}
		});
	}
    return res;
}

val4d* masked(auto_dao::Data x,std::function<bool(int,int,int,int)> cover,float mask,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* masked(auto_dao::Data x,std::function<bool(int,int,int,int)> cover,float mask,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	class TMP_MEM : public OP_Base
	{
		public:
			bool* tmp;
			TMP_MEM(OP_Base* fap,int siz):OP_Base(fap){tmp=new bool[siz];}
			void delthis(){delete[] tmp,auto_delthis();}
	};
	TMP_MEM* mem=fax->tmp<TMP_MEM>(n*d*h*w);
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		bool* fl=mem->tmp;
		for(int i=0,p=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
					{
						if((fl[p]=cover(i,j,k,l))) res->data()[i][j][k][l]=mask;
						else res->data()[i][j][k][l]=x.data()[i][j][k][l];
						p++;
					}
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			bool* fl=mem->tmp;
			for(int i=0,p=0;i<n;i++)
				for(int j=0;j<d;j++)
					for(int k=0;k<h;k++)
						for(int l=0;l<w;l++)
							if(!fl[p++]) inp->grad()[i][j][k][l]+=out->grad()[i][j][k][l];
		});
	}
	else
	{
		class TMP_IN : public OP_Base
		{
			public:
				float* tmp;
				TMP_IN(OP_Base* fap,int siz):OP_Base(fap){tmp=new float[siz];}
				void delthis(){delete[] tmp,auto_delthis();}
		};
		TMP_IN* tin=fax->tmp<TMP_IN>(n*d*h*w);
		memcpy(tin->tmp,x.data(),sizeof(float)*n*d*h*w);
		bool* fl=mem->tmp;
		for(int i=0,p=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
						if((fl[p++]=cover(i,j,k,l))) x.data()[i][j][k][l]=mask;
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			bool* fl=mem->tmp;
			for(int i=0,p=0;i<n;i++)
				for(int j=0;j<d;j++)
					for(int k=0;k<h;k++)
						for(int l=0;l<w;l++)
							if(fl[p++]) out->grad()[i][j][k][l]=0;
			memcpy(out->data(),tin->tmp,sizeof(float)*n*d*h*w);
		});
	}
    return res;
}

}
