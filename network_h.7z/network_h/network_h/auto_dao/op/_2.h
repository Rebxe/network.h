#pragma once

namespace network
{

val4d* dotfunc(auto_dao::Data_Node &x,auto_dao::Data_Node& y,
	std::function<float(float,float)>                              forward, // res=forward(x,y)
	std::function<std::pair<float,float>(float,float,float,float)> backward // make_pair(x_grad,y_grad)=backward(x,y,res,res_grad)
){
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* dotfunc(auto_dao::Data_Node &x,auto_dao::Data_Node& y,\n\
	std::function<float(float,float)>                              forward, // res=forward(x,y)\n\
	std::function<std::pair<float,float>(float,float,float,float)> backward // make_pair(x_grad,y_grad)=backward(x,y,res,res_grad)\n\
)\n\
  x is empty\n\n"));
	ext_assert((x.train||y.train||x.n==y.n)&&x.d==y.d&&x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val4d* dotfunc(auto_dao::Data_Node &x,auto_dao::Data_Node& y,\n\
	std::function<float(float,float)>                              forward, // res=forward(x,y)\n\
	std::function<std::pair<float,float>(float,float,float,float)> backward // make_pair(x_grad,y_grad)=backward(x,y,res,res_grad)\n\
)\n\
  x = [%d * %d * %d * %d]%s\n\
  y = [%d * %d * %d * %d]%s\n\n",x.n,x.d,x.h,x.w,x.train?" (train)":"",y.n,y.d,y.h,y.w,y.train?" (train)":""));
/******************************* end assertion **********************************/
	int n=std::max(x.n,y.n),d=x.d,h=x.h,w=x.w;
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>((shape4d){n,d,h,w});
	// forward
	for(int i=0;i<n;i++)
	{
		float *xa=x.data()[i%x.n],*ya=y.data()[i%y.n];
		for(int j=0;j<d*h*w;j++) res->data()[i].a[j]=forward(xa[j],ya[j]);
	}
	// backward
	res->getdat().regop({&x,&y},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node *xp=in[0],*yp=in[1];
		for(int i=0;i<n;i++)
		{
			float *xa=xp->data()[i%xp->n],*ya=yp->data()[i%yp->n];
			float *xg=xp->grad()[i%xp->n],*yg=yp->grad()[i%yp->n];
			for(int j=0;j<d*h*w;j++)
			{
				float oa=out->grad()[i].a[j];
				float og=out->grad()[i].a[j];
				std::pair<float,float> pre=backward(xa[j],ya[j],oa,og);
				xg[j]+=pre.first,yg[j]+=pre.second;
			}
		}
	});
    return res;
}

val4d* operator+(auto_dao::Data_Node& x,auto_dao::Data_Node& y)
{
	return dotfunc(x,y,
		[=](float x,float y){return x+y;},
		[=](float x,float y,float o,float og){return std::make_pair(og,og);}
	);
}

val4d* operator-(auto_dao::Data_Node& x,auto_dao::Data_Node& y)
{
	return dotfunc(x,y,
		[=](float x,float y){return x+y;},
		[=](float x,float y,float o,float og){return std::make_pair(og,-og);}
	);
}

val4d* operator*(auto_dao::Data_Node& x,auto_dao::Data_Node& y)
{
	return dotfunc(x,y,
		[=](float x,float y){return x*y;},
		[=](float x,float y,float o,float og){return std::make_pair(og*y,og*x);}
	);
}

val4d* operator/(auto_dao::Data_Node& x,auto_dao::Data_Node& y)
{
	return dotfunc(x,y,
		[=](float x,float y){return x/y;},
		[=](float x,float y,float o,float og){return std::make_pair(og/y,-x/(y*y)*og);}
	);
}

}
