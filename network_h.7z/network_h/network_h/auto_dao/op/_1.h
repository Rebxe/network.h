#pragma once

namespace network
{
	
val4d* reshape(auto_dao::Data x,shape4d shape,bool inplace)
{
	int inn=x.n,ind=x.d,inh=x.h,inw=x.w;
	int n=shape[0],d=shape[1],h=shape[2],w=shape[3];
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* reshape(auto_dao::Data x,shape4d shape,bool inplace)\n\
  x is empty\n\n"));
	ext_assert((x.train?n:inn)*ind*inh*inw==n*d*h*w,
		fprintf(stderr,"\
In val4d* reshape(auto_dao::Data x,shape4d shape,bool inplace)\n\
  x     = [%d * %d * %d * %d]%s\n\
  shape = [%d * %d * %d * %d]\n\n",(int)n,(int)d,(int)h,(int)w,x.train?" (train)":"",inn,ind,inh,inw));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape);
		if(x.train)
		{
			for(int i=0;i<n;i++)
				memcpy(res->data()[i],x.data(),sizeof(float)*x.data().size());
		}
		else memcpy(res->data(),x.data(),sizeof(float)*x.data().size());
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			if(inp->train)
			{
				for(int i=0;i<out->n;i++)
				{
					int siz=inp->grad().size();
					float *din=inp->grad(),*dout=out->grad()[i];
					for(int j=0;j<siz;j++) din[j]+=dout[j];
				}
			}
			else
			{
				int siz=inp->grad().size();
				float *din=inp->grad(),*dout=out->grad();
				for(int i=0;i<siz;i++) din[i]+=dout[i];
			}
		});
	}
	else
	{
		x.toshape(shape);
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			out->toshape({inn,ind,inh,inw});
		});
	}
    return res;
}

val4d* toshape(auto_dao::Data x,shape4d shape)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* toshape(auto_dao::Data x,shape4d shape)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape);
	int n=shape[0],d=shape[1],h=shape[2],w=shape[3];
	int inn=x.n,ind=x.d,inh=x.h,inw=x.w;
	for(int i=0;i<n;i++)
		for(int j=0;j<d;j++)
			for(int k=0;k<h;k++)
				for(int l=0;l<w;l++)
					res->data()[i][j][k][l]=x.data()[i%inn][j%ind][k%inh][l%inw];
	res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
						inp->grad()[i%inn][j%ind][k%inh][l%inw]+=out->grad()[i][j][k][l];
	});
    return res;
}

val4d* sdim(auto_dao::Data x,const char* from,const char* to,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* sdim(auto_dao::Data x,const char* from,const char* to,bool inplace)\n\
  x is empty\n\n"));
	ext_assert(strlen(from)==4&&strlen(to)==4,
		fprintf(stderr,"\
In val4d* sdim(auto_dao::Data x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
length of 'from' and length of 'to' should equal to 4\n\n",from,to));
#ifndef NDEBUG
	for(int i=0;i<4;i++)
		for(int j=i+1;j<4;j++)
			ext_assert(from[i]!=from[j],
				fprintf(stderr,"\
In val4d* sdim(auto_dao::Data x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' appears more than once in \"%s\"\n\n",from,to,from[i],from));
#endif
	int p[4]={-1,-1,-1,-1};
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4&&p[i]==-1;j++) if(to[i]==from[j]) p[i]=j;
		ext_assert(p[i]!=-1,
			fprintf(stderr,"\
In val4d* sdim(auto_dao::Data x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' in \"%s\" does not appear in \"%s\"\n\n",from,to,to[i],to,from));
	}
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	int tp[4]={n,d,h,w};
	int on=tp[p[0]],od=tp[p[1]],oh=tp[p[2]],ow=tp[p[3]];
	OP_Base* fax=x.getfa();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{on,od,oh,ow});
		// from DeepSeek
		const int total_elements = n * d * h * w;
	    const int original_dims[4] = {n, d, h, w};
	    const int new_dims[4] = {original_dims[p[0]], original_dims[p[1]], original_dims[p[2]], original_dims[p[3]]};
	
	    // ����ԭʼά�ȵĲ�����strides��
	    const int original_strides[4] = {
	        d * h * w,  // n�Ĳ���
	        h * w,      // d�Ĳ���
	        w,          // h�Ĳ���
	        1           // w�Ĳ���
	    };
	
	    // ����Ŀ��ά�ȵĲ���������new_dims��
	    const int new_strides[4] = {
	        new_dims[1] * new_dims[2] * new_dims[3],  // ��n�Ĳ���
	        new_dims[2] * new_dims[3],                // ��d�Ĳ���
	        new_dims[3],                              // ��h�Ĳ���
	        1                                         // ��w�Ĳ���
	    };
	
	    // ��������ӳ�亯�����޸�ԭ�����жϴ���
	    auto get_mapped_index = [&](int i, int j, int k, int l) -> int {
	        int mapped_coords[4];
	        mapped_coords[0] = i;  // ԭn������
	        mapped_coords[1] = j;  // ԭd������
	        mapped_coords[2] = k;  // ԭh������
	        mapped_coords[3] = l;  // ԭw������
	        // ��pӳ�䵽��ά��˳��
	        const int new_i = mapped_coords[p[0]];
	        const int new_j = mapped_coords[p[1]];
	        const int new_k = mapped_coords[p[2]];
	        const int new_l = mapped_coords[p[3]];
	        // ����Ŀ����������
	        return new_i * new_strides[0] + new_j * new_strides[1] + new_k * new_strides[2] + new_l;
	    };
	
	    // ����data��grad
	    auto process = [&](float* src, float* dst) {
	        #pragma omp parallel for collapse(4)
	        for (int i = 0; i < n; ++i) {
	            for (int j = 0; j < d; ++j) {
	                for (int k = 0; k < h; ++k) {
	                    for (int l = 0; l < w; ++l) {
	                        // ����ԭʼ��������
	                        const int src_idx = i * original_strides[0] + j * original_strides[1] + k * original_strides[2] + l;
	                        // ����Ŀ�������������޸��˴��߼���
	                        const int dst_idx = get_mapped_index(i, j, k, l);
	                        dst[dst_idx] = src[src_idx];
	                    }
	                }
	            }
	        }
	    };
	    process(x.data(), res->data());
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
		    // ��������ӳ�亯�����޸�ԭ�����жϴ���
		    auto get_mapped_index = [&](int i, int j, int k, int l) -> int {
		        int mapped_coords[4];
		        mapped_coords[0] = i;  // ԭn������
		        mapped_coords[1] = j;  // ԭd������
		        mapped_coords[2] = k;  // ԭh������
		        mapped_coords[3] = l;  // ԭw������
		        // ��pӳ�䵽��ά��˳��
		        const int new_i = mapped_coords[p[0]];
		        const int new_j = mapped_coords[p[1]];
		        const int new_k = mapped_coords[p[2]];
		        const int new_l = mapped_coords[p[3]];
		        // ����Ŀ����������
		        return new_i * new_strides[0] + new_j * new_strides[1] + new_k * new_strides[2] + new_l;
		    };
		    auto process = [&](float* src, float* dst) {
		        #pragma omp parallel for collapse(4)
		        for (int i = 0; i < n; ++i) {
		            for (int j = 0; j < d; ++j) {
		                for (int k = 0; k < h; ++k) {
		                    for (int l = 0; l < w; ++l) {
		                        // ����ԭʼ��������
		                        const int src_idx = i * original_strides[0] + j * original_strides[1] + k * original_strides[2] + l;
		                        // ����Ŀ�������������޸��˴��߼���
		                        const int dst_idx = get_mapped_index(i, j, k, l);
		                        src[src_idx] += dst[dst_idx];
		                    }
		                }
		            }
		        }
		    };
		    process(inp->grad(),out->grad()); 
		});
	}
	else
	{
		x.sdim(from,to);
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			out->sdim(to,from);
		});
	}
	return res;
}

}
