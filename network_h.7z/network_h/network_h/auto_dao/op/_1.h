#pragma once

namespace network
{
	
val4d* reshape(auto_dao::Data_Node& x,shape4d shape,bool inplace)
{
	int inn=x.n,ind=x.d,inh=x.h,inw=x.w;
	int n=shape[0],d=shape[1],h=shape[2],w=shape[3];
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* reshape(auto_dao::Data_Node& x,shape4d shape,bool inplace)\n\
  x is empty\n\n"));
	ext_assert((x.train?n:inn)*ind*inh*inw==n*d*h*w,
		fprintf(stderr,"\
In val4d* reshape(auto_dao::Data_Node& x,shape4d shape,bool inplace)\n\
  x     = [%d * %d * %d * %d]%s\n\
  shape = [%d * %d * %d * %d]\n\n",x.train?" (train)":"",inn,ind,inh,inw,n,d,h,w));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape);
		if(x.train)
		{
			for(int i=0;i<n;i++)
				memcpy(res->data()[i],x.data(),sizeof(float)*x.data().size());
		}
		else memcpy(res->data(),x.data(),sizeof(float)*x.data().size());
		res->getdat().regop({&x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			if(inp->train)
			{
				for(int i=0;i<out->n;i++)
				{
					int siz=inp->grad().size();
					float *din=inp->grad(),*dout=out->grad()[i];
					for(int j=0;j<siz;j++) din[j]+=dout[j];
				}
			}
			else
			{
				int siz=inp->grad().size();
				float *din=inp->grad(),*dout=out->grad();
				for(int i=0;i<siz;i++) din[i]+=dout[i];
			}
		});
	}
	else
	{
		x.toshape(shape);
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			out->toshape({inn,ind,inh,inw});
		});
	}
    return res;
}

val4d* toshape(auto_dao::Data_Node& x,shape4d shape)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* toshape(auto_dao::Data_Node& x,shape4d shape)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	val4d* res=fax->tmp<val4d>(shape);
	int n=shape[0],d=shape[1],h=shape[2],w=shape[3];
	int inn=x.n,ind=x.d,inh=x.h,inw=x.w;
	for(int i=0;i<n;i++)
		for(int j=0;j<d;j++)
			for(int k=0;k<h;k++)
				for(int l=0;l<w;l++)
					res->data()[i][j][k][l]=x.data()[i%inn][j%ind][k%inh][l%inw];
	res->getdat().regop({&x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
						inp->grad()[i%inn][j%ind][k%inh][l%inw]+=out->grad()[i][j][k][l];
	});
    return res;
}

val4d* sdim(auto_dao::Data_Node& x,const char* from,const char* to,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* sdim(auto_dao::Data_Node& x,const char* from,const char* to,bool inplace)\n\
  x is empty\n\n"));
	ext_assert(strlen(from)==4&&strlen(to)==4,
		fprintf(stderr,"\
In val4d* sdim(auto_dao::Data_Node& x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
length of 'from' and length of 'to' should equal to 4\n\n",from,to));
#ifndef NDEBUG
	for(int i=0;i<4;i++)
		for(int j=i+1;j<4;j++)
			ext_assert(from[i]!=from[j],
				fprintf(stderr,"\
In val4d* sdim(auto_dao::Data_Node& x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' appears more than once in \"%s\"\n\n",from,to,from[i],from));
#endif
	int p[4]={-1,-1,-1,-1};
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<4&&p[i]==-1;j++) if(to[i]==from[j]) p[i]=j;
		ext_assert(p[i]!=-1,
			fprintf(stderr,"\
In val4d* sdim(auto_dao::Data_Node& x,const char* from,const char* to,bool inplace)\n\
  from = \"%s\"\n\
  to   = \"%s\"\n\
but\n\
  '%c' in \"%s\" does not appear in \"%s\"\n\n",from,to,to[i],to,from));
	}
/******************************* end assertion **********************************/
	int n=x.n,d=x.d,h=x.h,w=x.w;
	int tp[4]={n,d,h,w};
	int on=tp[p[0]],od=tp[p[1]],oh=tp[p[2]],ow=tp[p[3]];
	OP_Base* fax=x.getfa();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>((shape4d){on,od,oh,ow});
		for(int i=0;i<n;i++)
			for(int j=0;j<d;j++)
				for(int k=0;k<h;k++)
					for(int l=0;l<w;l++)
					{
						int tp[4]={i,j,k,l};
						res->data()[tp[p[0]]][tp[p[1]]][tp[p[2]]][tp[p[3]]]=x.data()[i][j][k][l];
					}
		res->getdat().regop({&x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			for(int i=0;i<n;i++)
				for(int j=0;j<d;j++)
					for(int k=0;k<h;k++)
						for(int l=0;l<w;l++)
						{
							int tp[4]={i,j,k,l};
							inp->grad()[i][j][k][l]+=out->grad()[tp[p[0]]][tp[p[1]]][tp[p[2]]][tp[p[3]]];
						}
		});
	}
	else
	{
		x.sdim(from,to);
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			out->sdim(to,from);
		});
	}
	return res;
}

}
