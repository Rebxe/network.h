#pragma once

namespace network
{

val4d* relu(auto_dao::Data x,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* relu(auto_dao::Data x,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	float4d xa=x.data();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		float4d ra=res->data();
		for(int i=0;i<n*d*h*w;i++) ra.a[i]=xa.a[i]>0?xa.a[i]:0;
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			float4d xa=inp->data(),xg=inp->grad();
			float4d rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) xg.a[i]+=xa.a[i]>0?rg.a[i]:0;
		});
	}
	else
	{
		class TMP_MEM : public OP_Base
		{
			public:
				float* tmp;
				TMP_MEM(OP_Base* fap,int siz):OP_Base(fap){tmp=new float[siz];}
				void delthis(){delete[] tmp,auto_delthis();}
		};
		TMP_MEM* mem=fax->tmp<TMP_MEM>(n*d*h*w);
		memcpy(mem->tmp,xa,sizeof(float)*n*d*h*w);
		for(int i=0;i<n*d*h*w;i++) xa.a[i]=xa.a[i]>0?xa.a[i]:0;
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			float4d ra=out->data(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) rg.a[i]=mem->tmp[i]>0?rg.a[i]:0;
			memcpy(ra,mem->tmp,sizeof(float)*n*d*h*w);
		});
	}
	return res;
}

val4d* leaky_relu(auto_dao::Data x,float a,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* leaky_relu(auto_dao::Data x,float a,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	float4d xa=x.data();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		float4d ra=res->data();
		for(int i=0;i<n*d*h*w;i++) ra.a[i]=(xa.a[i]>0?1:a)*xa.a[i];
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			float4d xa=inp->data(),xg=inp->grad();
			float4d rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) xg.a[i]+=(xa.a[i]>0?1:a)*rg.a[i];
		});
	}
	else
	{
		class TMP_MEM : public OP_Base
		{
			public:
				float* tmp;
				TMP_MEM(OP_Base* fap,int siz):OP_Base(fap){tmp=new float[siz];}
				void delthis(){delete[] tmp,auto_delthis();}
		};
		TMP_MEM* mem=fax->tmp<TMP_MEM>(n*d*h*w);
		memcpy(mem->tmp,xa,sizeof(float)*n*d*h*w);
		for(int i=0;i<n*d*h*w;i++) xa.a[i]=(xa.a[i]>0?1:a)*xa.a[i];
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			float4d ra=out->data(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) rg.a[i]=(mem->tmp[i]>0?1:a)*rg.a[i];
			memcpy(ra,mem->tmp,sizeof(float)*n*d*h*w);
		});
	}
	return res;
}

val4d* sigmoid(auto_dao::Data x,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* sigmoid(auto_dao::Data x,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	float4d xa=x.data();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		float4d ra=res->data();
		for(int i=0;i<n*d*h*w;i++) ra.a[i]=1/(1+expf_fast(-xa.a[i]));
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			float4d xg=inp->grad(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) xg.a[i]+=ra.a[i]*(1-ra.a[i])*rg.a[i];
		});
	}
	else
	{
		class TMP_MEM : public OP_Base
		{
			public:
				float* tmp;
				TMP_MEM(OP_Base* fap,int siz):OP_Base(fap){tmp=new float[siz];}
				void delthis(){delete[] tmp,auto_delthis();}
		};
		TMP_MEM* mem=fax->tmp<TMP_MEM>(n*d*h*w);
		memcpy(mem->tmp,xa,sizeof(float)*n*d*h*w);
		for(int i=0;i<n*d*h*w;i++) xa.a[i]=1/(1+expf_fast(-xa.a[i]));
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			float4d ra=out->data(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) rg.a[i]=ra.a[i]*(1-ra.a[i])*rg.a[i];
			memcpy(ra,mem->tmp,sizeof(float)*n*d*h*w);
		});
	}
	return res;
}

val4d* tanh(auto_dao::Data x,bool inplace)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* tanh(auto_dao::Data x,bool inplace)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	float4d xa=x.data();
	val4d* res;
	if(!inplace)
	{
		res=fax->tmp<val4d>(shape4d{n,d,h,w});
		float4d ra=res->data();
		for(int i=0;i<n*d*h*w;i++)
		{
			float x=expf_fast(xa.a[i]),y=1/x;
			ra.a[i]=(x-y)/(x+y);
		}
		res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			auto_dao::Data_Node* inp=in[0];
			float4d xg=inp->grad(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) xg.a[i]+=(1-ra.a[i]*ra.a[i])*rg.a[i];
		});
	}
	else
	{
		class TMP_MEM : public OP_Base
		{
			public:
				float* tmp;
				TMP_MEM(OP_Base* fap,int siz):OP_Base(fap){tmp=new float[siz];}
				void delthis(){delete[] tmp,auto_delthis();}
		};
		TMP_MEM* mem=fax->tmp<TMP_MEM>(n*d*h*w);
		memcpy(mem->tmp,xa,sizeof(float)*n*d*h*w);
		for(int i=0;i<n*d*h*w;i++)
		{
			float x=expf_fast(xa.a[i]),y=1/x;
			xa.a[i]=(x-y)/(x+y);
		}
		res=fax->tmp<val4d>(x);
		res->getdat().addop([=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
		{
			float4d ra=out->data(),rg=out->grad();
			for(int i=0;i<n*d*h*w;i++) rg.a[i]=(1-ra.a[i]*ra.a[i])*rg.a[i];
			memcpy(ra,mem->tmp,sizeof(float)*n*d*h*w);
		});
	}
	return res;
}

val4d* softmax(auto_dao::Data x,int dim)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In val4d* softmax(auto_dao::Data x,int dim)\n\
  x is empty\n\n"));
/******************************* end assertion **********************************/
	OP_Base* fax=x.getfa();
	int n=x.n,d=x.d,h=x.h,w=x.w;
	float4d xa=x.data();
	val4d* res=fax->tmp<val4d>(shape4d{n,d,h,w});
	float4d ra=res->data();
	// forward
	shape4d ub,id;
	if(dim==1) ub={d,h,w,n},id={3,0,1,2};
	if(dim==2) ub={n,h,w,d},id={0,3,1,2};
	if(dim==3) ub={n,d,w,h},id={0,1,3,2};
	if(dim==4) ub={n,d,h,w},id={0,1,2,3};
	for(int i=0;i<ub[0];i++)
		for(int j=0;j<ub[1];j++)
			for(int k=0;k<ub[2];k++)
			{
				float mx;
				for(int l=0;l<ub[3];l++)
				{
					shape4d val={i,j,k,l};
					int i0=val[id[0]],i1=val[id[1]],i2=val[id[2]],i3=val[id[3]];
					float pre=xa[i0][i1][i2][i3];
					if(l==0) mx=pre;
					else mx=(std::max)(mx,pre);
				}
				float sm=0;
				for(int l=0;l<ub[3];l++)
				{
					shape4d val={i,j,k,l};
					int i0=val[id[0]],i1=val[id[1]],i2=val[id[2]],i3=val[id[3]];
					float pre=xa[i0][i1][i2][i3];
					sm+=expf_fast(pre-mx);
				}
				for(int l=0;l<ub[3];l++)
				{
					shape4d val={i,j,k,l};
					int i0=val[id[0]],i1=val[id[1]],i2=val[id[2]],i3=val[id[3]];
					float pre=xa[i0][i1][i2][i3];
					ra[i0][i1][i2][i3]=expf_fast(pre-mx)/sm;
				}
			}
	res->getdat().regop({x},[=](std::vector<auto_dao::Data_Node*> in,auto_dao::Data_Node* out)
	{
		auto_dao::Data_Node* inp=in[0];
		float4d xg=inp->grad();
		float4d ra=out->data(),rg=out->grad();
		for(int i=0;i<ub[0];i++)
			for(int j=0;j<ub[1];j++)
				for(int k=0;k<ub[2];k++)
				{
					float smg=0;
					for(int l=0;l<ub[3];l++)
					{
						shape4d val={i,j,k,l};
						int i0=val[id[0]],i1=val[id[1]],i2=val[id[2]],i3=val[id[3]];
						float gk=rg[i0][i1][i2][i3];
						float pk=ra[i0][i1][i2][i3];
						float pre=-gk*pk;
						smg+=pre;
					}
					for(int l=0;l<ub[3];l++)
					{
						shape4d val={i,j,k,l};
						int i0=val[id[0]],i1=val[id[1]],i2=val[id[2]],i3=val[id[3]];
						float gk=rg[i0][i1][i2][i3];
						float pk=ra[i0][i1][i2][i3];
						float pre=-gk*pk;
						xg[i0][i1][i2][i3]+=(smg-pre)*pk+gk*(pk-pk*pk);
					}
				}
	});
	return res;
}

}
