#pragma once

namespace network
{

float MSEloss(auto_dao::Data_Node& x,float4d realout,bool mean)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In float MSEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x is empty\n\n"));
	ext_assert(x.n==realout.n&&x.d==realout.d&&x.h==realout.h&&x.w==realout.w,
		fprintf(stderr,"\
In float MSEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x       = [%d * %d * %d * %d]\n\
  realout = [%d * %d * %d * %d]\n\n",x.n,x.d,x.h,x.w,realout.n,realout.d,realout.h,realout.w));
/******************************* end assertion **********************************/
	float res=0;
	int bs=x.n;
	for(int tb=0;tb<bs;tb++)
	{
		int n=x.data()[tb].size();
		for(int i=0;i<n;i++)
		{
			float val=x.data()[tb].a[i],y=realout[tb].a[i];
			res+=pow(val-y,2)/bs/(mean?n:1);
			x.grad()[tb].a[i]+=2*(val-y)/bs/(mean?n:1);
		}
	}
	return res;
}

float CEloss(auto_dao::Data_Node& x,float4d realout,bool mean)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In float CEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x is empty\n\n"));
	ext_assert(x.n==realout.n&&x.d==realout.d&&x.h==realout.h&&x.w==realout.w,
		fprintf(stderr,"\
In float CEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x       = [%d * %d * %d * %d]\n\
  realout = [%d * %d * %d * %d]\n\n",x.n,x.d,x.h,x.w,realout.n,realout.d,realout.h,realout.w));
/******************************* end assertion **********************************/
	float res=0;
	int bs=x.n;
	for(int tb=0;tb<bs;tb++)
	{
		int n=x.data()[tb].size();
		for(int i=0;i<n;i++)
		{
			float val=x.data()[tb].a[i],y=realout[tb].a[i],eps=1e-7;
			if(val<eps) val=eps;
			else x.grad()[tb].a[i]+=-(y*(1/val))/bs/(mean?n:1);
			res+=-y*log(val)/bs/(mean?n:1);
		}
	}
	return res;
}

float BCEloss(auto_dao::Data_Node& x,float4d realout,bool mean)
{
	ext_assert(x.data().size()>0,
		fprintf(stderr,"\
In float BCEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x is empty\n\n"));
	ext_assert(x.n==realout.n&&x.d==realout.d&&x.h==realout.h&&x.w==realout.w,
		fprintf(stderr,"\
In float BCEloss(auto_dao::Data_Node& x,float4d realout,bool mean)\n\
  x       = [%d * %d * %d * %d]\n\
  realout = [%d * %d * %d * %d]\n\n",x.n,x.d,x.h,x.w,realout.n,realout.d,realout.h,realout.w));
/******************************* end assertion **********************************/
	float res=0;
	int bs=x.n;
	for(int tb=0;tb<bs;tb++)
	{
		int n=x.data()[tb].size();
		for(int i=0;i<n;i++)
		{
			float val=x.data()[tb].a[i],y=realout[tb].a[i],eps=1e-7;
			if(val<eps||val>1-eps) val=(std::max)(eps,(std::min)(val,1-eps));
			else x.grad()[bs].a[i]+=-(y*(1/val)-(1-y)*(1/(1-val)))/bs/(mean?n:1);
			res+=-(y*log(val)+(1-y)*log(1-val))/bs/(mean?n:1);
		}
	}
	return res;
}

}
