#pragma once

namespace network
{

class val4d : public OP_Base
{
	private:
		bool fmaster; // is the master of dat
		auto_dao::Data_Node* dat;
	
	private:
		void chk(const char* type,const char* name)
		{
			ext_assert(dat!=0,
				fprintf(stderr,"\
In %s val4d::%s\n\
  this hasn't been initalized yet\n\n",type,name));
		}
		
	public:
		int getn(){return chk("int","n"),dat->n;}
		int getd(){return chk("int","d"),dat->d;}
		int geth(){return chk("int","h"),dat->h;}
		int getw(){return chk("int","w"),dat->w;}
	
	public:
		read_func<int> n,d,h,w;
	
	private:
		void bindfunc()
		{
			n.bind(std::bind(&val4d::getn,this));
			d.bind(std::bind(&val4d::getd,this));
			h.bind(std::bind(&val4d::geth,this));
			w.bind(std::bind(&val4d::getw,this)); 
		}
	
	public:
		float4d data(){return chk("float4d","data()"),dat->data();};
		float4d grad(){return chk("float4d","grad()"),dat->data();};
		void backward(){chk("void","backward()"),dat->backward();}
		auto_dao::Data_Node& getdat(){return chk("auto_dao::Data_Node&","getdat()"),*dat;}
		operator auto_dao::Data_Node&(){return chk("","operator auto_dao::Data_Node&()"),getdat();}
		
	public:
		void save(std::ofstream &ouf)
		{
			if(dat!=0) writf(ouf,(float*)data(),data().size());
			auto_save(ouf);
		}
		void load(std::ifstream &inf)
		{
			if(dat!=0) readf(inf,(float*)data(),data().size());
			auto_load(inf);
		}
		void delthis()
		{
			if(fmaster&&dat!=0) delete dat,dat=0;
			auto_delthis();
		}
		void init_forward()
		{
			if(fmaster&&dat!=0) dat->clearop();
			auto_init_forward();
		}
		
	public:
		val4d(){fmaster=false,dat=0,bindfunc();}
		val4d(OP_Base* fap,auto_dao::Data_Node& x);
		val4d(OP_Base* fap,shape4d shape,float val=0);
		val4d(OP_Base* fap,shape4d shape,float* val);
};

/***************************** End of definitions *****************************/

val4d::val4d(OP_Base* fap,auto_dao::Data_Node& x):OP_Base(fap)
{
	ext_assert(fap==x.getfa(),
		fprintf(stderr,"\
In val4d::val4d(OP_Base* fap,auto_dao::Data_Node& x)\n\
  fap is not equal to the owner of x\n\n"));
  	fmaster=false;
	dat=&x;
	bindfunc(); 
}
val4d::val4d(OP_Base* fap,shape4d shape,float val):OP_Base(fap)
{
	fmaster=true;
	dat=new auto_dao::Data_Node(this,shape);
	bindfunc();
	for(int i=0;i<data().size();i++) data().a[i]=val;
}
val4d::val4d(OP_Base* fap,shape4d shape,float *val):OP_Base(fap)
{
	fmaster=true;
	dat=new auto_dao::Data_Node(this,shape);
	bindfunc();
	memcpy(data(),val,sizeof(float)*data().size());
} 

}
