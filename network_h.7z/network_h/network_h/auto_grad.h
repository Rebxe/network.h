#pragma once

namespace network
{
	class val4d;
	class para4d;
	namespace auto_grad
	{
		namespace computing_node { class Data_Node; }
		class Data
		{
		private:
			computing_node::Data_Node* x;

		public:
			using type_backward_f = std::function<void(std::vector<Data>, Data)>;

		public:
			operator computing_node::Data_Node& ();
			operator computing_node::Data_Node* ();

		public:
			OP_Base* getfa()         const;
			bool train()             const;
			af::dtype type()         const;
			dim_t dims(unsigned dim) const;
			af::dim4 dims()          const;
			dim_t elements()         const;
			af::array& data();
			af::array& grad();

		public:
			void clearop();
			void regop(std::vector<Data> Input, type_backward_f Backward_f); // not inplace
			void addop(type_backward_f Backward_f);                          // inplace
			void backward();

		public:
			Data(computing_node::Data_Node& y);
			Data(computing_node::Data_Node* y);
			Data(val4d& y);
			Data(para4d& y);
			Data(val4d* y);
			Data(para4d* y);

		public:
			Data& operator=(const Data& y);
		};
	}
}

/******************************************* End of definition **********************************************/

namespace network
{
	namespace auto_grad
	{
		namespace computing_node
		{
			class Data_Node
			{
			public:
				using type_backward_f = std::function<void(std::vector<Data_Node*>, Data_Node*)>;

			private:
				OP_Base* fa;
				bool ftrain;
				af::array* pdata, * pgrad;
				std::vector<Data_Node*> input;
				std::vector<type_backward_f> backward_f;
				int outd;

			private:
				void freemem()
				{
					if (pdata != 0) delete pdata;
					if (pgrad != 0) delete pgrad;
					pdata = pgrad = 0;
				}

			public:
				OP_Base* getfa()         const { return fa; }
				bool train()             const { return ftrain; }
				af::dtype type()         const { return pdata->type(); }
				dim_t dims(unsigned dim) const { return pdata->dims(dim); }
				af::dim4 dims()          const { return pdata->dims(); }
				dim_t elements()         const { return pdata->elements(); }
				af::array& data() { return *pdata; }
				af::array& grad()
				{
					if (pgrad == 0) pgrad = new af::array(dims(), type()), * pgrad = 0;
					return *pgrad;
				}

			public:
				void clearop() { std::vector<Data_Node*>().swap(input), std::vector<type_backward_f>().swap(backward_f), outd = 0; }
				void regop(std::vector<Data_Node*> Input, type_backward_f Backward_f) // not inplace
				{
					ext_assert(backward_f.empty(), fprintf(stderr, "\
In void auto_grad::computing_node::Data_Node::regop(std::vector<Data_Node*> Input,type_backward_f Backward_f)\n\
  there can't be more than one not inplace operator\n\n"));
					input = Input;
					for (Data_Node* x : input) x->outd++;
					backward_f.push_back(Backward_f);
				}
				void addop(type_backward_f Backward_f) // inplace
				{
					ext_assert(!ftrain, fprintf(stderr, "\
In void auto_grad::computing_node::Data_Node::addop(type_backward_f Backward_f)\n\
  Inplace mode is not allowed for train_able item\n\n"));
					ext_assert(outd == 0, fprintf(stderr, "\
In void auto_grad::computing_node::Data_Node::addop(type_backward_f Backward_f)\n\
  this should not be used before an inplace operation\n\n"));
					backward_f.push_back(Backward_f);
				}
				void backward()
				{
					ext_assert(!fa->eval, fprintf(stderr, "\
In void auto_grad::computing_node::Data_Node::backward()\n\
  Backward is disabled in eval mode\n\n"));
					while (!backward_f.empty()) backward_f.back()(input, this), backward_f.pop_back();
					if (!ftrain && fa->deltmp) freemem();
					for (Data_Node* x : input) if (--x->outd == 0) x->backward();
				}

			public:
				Data_Node(OP_Base* fap, bool train, af::dim4 dims, af_dtype type)
				{
					fa = fap;
					ftrain = train;
					pdata = new af::array(dims, type), * pdata = 0, pgrad = 0;
					outd = 0;
				}
				~Data_Node() { freemem(); }

			public:
				// copying is disabled
				Data_Node& operator=(const Data_Node&) = delete;
			};
		}
	}
}

#include "auto_grad/val4d.h"
#include "auto_grad/para4d.h"

namespace network
{
	namespace auto_grad
	{
		Data::operator computing_node::Data_Node& () { return *x; }
		Data::operator computing_node::Data_Node* () { return x; }

		OP_Base* Data::getfa()         const { return x->getfa(); }
		bool Data::train()             const { return x->train(); }
		af::dtype Data::type()         const { return x->type(); }
		dim_t Data::dims(unsigned dim) const { return x->dims(dim); }
		af::dim4 Data::dims()          const { return x->dims(); }
		dim_t Data::elements()         const { return x->elements(); }
		af::array& Data::data() { return x->data(); }
		af::array& Data::grad() { return x->grad(); }
		
		void Data::clearop() { x->clearop(); }
		void Data::regop(std::vector<Data> Input, Data::type_backward_f Backward_f)
		{
			std::vector<computing_node::Data_Node*> tInput;
			for (Data t : Input) tInput.push_back(t);
			x->regop(tInput, [=](std::vector<computing_node::Data_Node*> in, computing_node::Data_Node* out) {
				std::vector<Data> tin;
				for (computing_node::Data_Node* t : in) tin.push_back(t);
				Backward_f(tin, out);
			});
		}
		void Data::addop(Data::type_backward_f Backward_f)
		{
			x->addop([=](std::vector<computing_node::Data_Node*> in, computing_node::Data_Node* out) {
				std::vector<Data> tin;
				for (computing_node::Data_Node* t : in) tin.push_back(t);
				Backward_f(tin, out);
			});
		}
		void Data::backward() { x->backward(); }

		Data::Data(computing_node::Data_Node& y) { x = &y; }
		Data::Data(computing_node::Data_Node* y) { x = y; }
		Data::Data(val4d& y) { x = y.dat; }
		Data::Data(para4d& y) { x = y.dat; }
		Data::Data(val4d* y) { x = y->dat; }
		Data::Data(para4d* y) { x = y->dat; }

		Data& Data::operator=(const Data& y) { return x = y.x, *this; }
	}
}

#include "auto_grad/operators.h"
