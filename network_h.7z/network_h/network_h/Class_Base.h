#pragma once

namespace network
{
	using Parameters = std::vector<std::pair<af::array*, af::array*>>;

	class OP_Base
	{
	private:
		OP_Base* fa;
		std::vector<OP_Base*> son;
		Parameters para;
		// delete in init_forward()
		std::vector<OP_Base*> tmpson; // should not have weight

	public:
		read_only<bool, OP_Base> eval, deltmp;

	public:
		void reg_para(af::array* wei, af::array* grad);
		Parameters parameter() const;

	public:
		void set_eval(bool feval);
		void set_deltmp(bool fdeltmp);

	public:
		template<typename T, typename... Args>
		T* get(Args&&... args);
		template<typename T, typename... Args>
		T* tmp(Args&&... args);

	protected:
		void auto_save(std::ofstream& ouf);
		void auto_load(std::ifstream& inf);
		void auto_delthis();
		void auto_init_forward();

	public:
		virtual void save(std::ofstream& ouf) { auto_save(ouf); }
		virtual void load(std::ifstream& inf) { auto_load(inf); }
		virtual void delthis() { auto_delthis(); }
		virtual void init_forward() { auto_init_forward(); }

	public:
		OP_Base(OP_Base* fap = 0);
		virtual ~OP_Base() {}

	public:
		// copying is disabled
		OP_Base& operator=(const OP_Base& x) = delete;
	};

	class Opti_Base
	{
	protected:
		Parameters para;

	public:
		virtual void clear_grad() = 0;
		virtual void step() = 0;

	public:
		virtual void save() {}
		virtual void load() {}
		virtual void delthis() {}

	public:
		virtual ~Opti_Base() {}
	};
}

namespace network
{
	void OP_Base::reg_para(af::array* wei, af::array* grad) { para.emplace_back(wei, grad); }
	Parameters OP_Base::parameter() const
	{
		Parameters res = para;
		for (OP_Base* p : son)
		{
			const Parameters tmp = p->parameter();
			for (auto t : tmp) res.push_back(t);
		}
		return res;
	}

	void OP_Base::set_eval(bool feval)
	{
		eval = feval;
		for (OP_Base* p : son) p->set_eval(feval);
		for (OP_Base* p : tmpson) p->set_eval(feval);
	}
	void OP_Base::set_deltmp(bool fdeltmp)
	{
		deltmp = fdeltmp;
		for (OP_Base* p : son) p->set_deltmp(fdeltmp);
		for (OP_Base* p : tmpson) p->set_deltmp(fdeltmp);
	}

	template<typename T, typename... Args>
	T* OP_Base::get(Args&&... args)
	{
		T* res = new T(this, std::forward<Args>(args)...);
		son.push_back((OP_Base*)res);
		return res;
	}
	template<typename T, typename... Args>
	T* OP_Base::tmp(Args&&... args)
	{
		T* res = new T(this, std::forward<Args>(args)...);
		tmpson.push_back((OP_Base*)res);
		return res;
	}

	void OP_Base::auto_save(std::ofstream& ouf) { for (OP_Base* p : son) p->save(ouf); }
	void OP_Base::auto_load(std::ifstream& inf) { for (OP_Base* p : son) p->load(inf); }
	void OP_Base::auto_delthis()
	{
		for (OP_Base* p : son) p->delthis(), delete p;
		for (OP_Base* p : tmpson) p->delthis(), delete p;
		son.clear();
		tmpson.clear();
		para.clear();
	}
	void OP_Base::auto_init_forward()
	{
		for (OP_Base* p : tmpson) p->delthis(), delete p;
		tmpson.clear();
		for (OP_Base* p : son) p->init_forward();
	}

	OP_Base::OP_Base(OP_Base* fap)
	{
		fa = fap;
		eval = false;
		deltmp = true;
	}
}