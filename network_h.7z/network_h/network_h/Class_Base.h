#pragma once

namespace network
{
	class OP_Base;
	
	namespace auto_dao
	{
		class Data_Node
		{
			private:
				OP_Base* fa;
			
			public:
				using type_backward_f=std::function<void(std::vector<Data_Node*>,Data_Node*)>;
				
			public: 
				read_only<bool,Data_Node> train;
				read_only<int,Data_Node> n,d,h,w;
			
			private:
				float *pdata,*pgrad;
				std::vector<Data_Node*> input;
				std::vector<type_backward_f> backward_f;
				int outd;
			
			private:
				void freemem();
				
			public:
				OP_Base* getfa();
				float4d data();
				float4d grad();
			
			public:
				void clearop();
				void regop(std::vector<Data_Node*> Input,type_backward_f Backward_f); // not inplace
				void addop(type_backward_f Backward_f); // inplace
				void backward();
			
			public:
				void toshape(shape4d shape);
				void sdim(const char* from,const char* to);
				
			public:
				Data_Node(OP_Base* fap,shape4d shape); // normal
				Data_Node(OP_Base* fap,shape3d shape); // train-able
				~Data_Node();
		};
	}
}

namespace network
{
	class Parameter
	{
		public:
			struct Node
			{
				int cnt;
				float *wei,*grad;
			};
		
		public:
			std::vector<Node> dat;
			void add(Node x){dat.push_back(x);}
			void merge(Parameter x){for(Node y:x.dat) dat.push_back(y);}
			int size()
			{
				int res=0;
				for(Node x:dat) res+=x.cnt;
				return res;
			}
			void clear(){dat.clear();}
	};
	
	class OP_Base
	{
		friend auto_dao::Data_Node;
		
		private:
			OP_Base* fa;
			std::vector<OP_Base*> son;
			Parameter para;
			// delete in init_forward()
			std::vector<OP_Base*> tmpson; // should not have weight
			
		public:
			read_only<bool,OP_Base> eval,deltmp;
			
		public:
			void reg_para(int cnt,float* wei,float* grad)
			{
				Parameter::Node x;
				x.cnt=cnt,x.wei=wei,x.grad=grad;
				para.add(x);
			}
			Parameter parameter()
			{
				Parameter res=para;
				for(OP_Base* p:son) res.merge(p->parameter());
				return res;
			}
			
			void set_eval(bool feval)
			{
				eval=feval;
				for(OP_Base* p:son) p->set_eval(feval);
				for(OP_Base* p:tmpson) p->set_eval(feval);
			}
			void set_deltmp(bool fdeltmp)
			{
				deltmp=fdeltmp;
				for(OP_Base* p:son) p->set_deltmp(fdeltmp);
				for(OP_Base* p:tmpson) p->set_deltmp(fdeltmp);
			}
			
			template<typename T,typename... Args>
			T* get(Args&&... args)
			{
				T* res=new T(this,std::forward<Args>(args)...);
				son.push_back((OP_Base*)res);
				return res;
			}
			template<typename T,typename... Args>
			T* tmp(Args&&... args)
			{
				T* res=new T(this,std::forward<Args>(args)...);
				tmpson.push_back((OP_Base*)res);
				return res;
			}
		
		protected:
			void auto_save(std::ofstream &ouf){for(OP_Base* p:son) p->save(ouf);}
			void auto_load(std::ifstream &inf){for(OP_Base* p:son) p->load(inf);}
			void auto_delthis()
			{
				for(OP_Base* p:son) p->delthis(),delete p;
				for(OP_Base* p:tmpson) p->delthis(),delete p;
				son.clear();
				tmpson.clear();
				para.clear();
			}
			void auto_init_forward()
			{
				for(OP_Base* p:tmpson) p->delthis(),delete p;
				tmpson.clear();
				for(OP_Base* p:son) p->init_forward();
			}
			
		public:
			virtual void save(std::ofstream &ouf){auto_save(ouf);}
			virtual void load(std::ifstream &inf){auto_load(inf);}
			virtual void delthis(){auto_delthis();}
			virtual void init_forward(){auto_init_forward();}
		
		public:
			OP_Base(OP_Base* fap=0)
			{
				fa=fap;
				eval=false;
				deltmp=true;
			}
			virtual ~OP_Base(){}
		
		public:
			OP_Base& operator=(const OP_Base& x)=delete; // copying is disabled
	};
	
	class Opti_Base
	{
		protected:
			Parameter para;
		
		public:
			virtual void clear_grad()=0;
			virtual void step()=0;
		
		public:
			virtual void save(){}
			virtual void load(){}
			virtual void delthis(){}
		
		public:
			virtual ~Opti_Base(){}
	};
}
