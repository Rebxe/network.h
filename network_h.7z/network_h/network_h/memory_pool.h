#pragma once

namespace network
{

namespace mem_pool
{
	const int max_size=MAX_BUFSIZE_BYTE/sizeof(float);
	float* shared_memory(new float[max_size]);
	void getmem(int siz)
	{
		ext_assert(siz<=max_size,
			fprintf(stderr,"\
In void mem_pool::getmem(int siz)\n\
  siz      = %d\n\
  max_size = %d\n\
but\n\
  %d > %d\n\n",siz,max_size,siz,max_size));
	}
}

}
