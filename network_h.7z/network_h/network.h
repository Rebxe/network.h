/************************** About Constants **************************/

// define ENABLE_GPU to enable gpu

// define DNEBUG to disable checkings

// use MAX_BUFSIZE_BYTE(default is 1073741824(1GB)) to set the maximum size of extra memory while computing,
//   see details in memory_pool.h

/************************** About The Speed **************************/

// matrix multiplication operation is based on Eigen and ViennaCL,
//   so enable OpenMP or enable instruction set like AVX or SSE can make your code run faster
// for example, in g++ you can use "-Ofast -fopenmp -march=native"

#pragma once

#include <cstring>
#include <ctime>
#include <fstream>
#include <random>
#include <cfloat>
#include <tuple>
#include <assert.h>
#include <cmath>
#include <type_traits>
#include <functional>
#include <vector>
#include <io.h>
#include <algorithm>
#include <array>

/***************** Begin of definitions***************/
namespace network
{

using shape3d=std::array<int,3>;
using shape4d=std::array<int,4>;

const int Init_He=1,Init_Xavier=2;

}

#ifdef NDEBUG
	#define ext_assert(_Expression,_Fail_Code) ((void)0)
#else
	#define ext_assert(_Expression,_Fail_Code) assert((_Expression)==true||((_Fail_Code),false))
#endif

#ifndef MAX_BUFSIZE_BYTE
	#define MAX_BUFSIZE_BYTE 1073741824
#endif
/***************** End of definitions***************/

#include "network_h/float4d.h"
#include "network_h/read_only.h"

#include "network_h/memory_pool.h"
#include "network_h/fast_calc.h"
#include "network_h/file_io.h"

#include "network_h/Class_Base.h"

#include "network_h/auto_dao.h"

#include "network_h/Layers.h"
#include "network_h/Optimizer.h"
