// This library depends on ArrayFire
// The dims is HWCN
// Store is N*C*W*H
// define DNEBUG to disable checkings

#pragma once

#define _CRT_SECURE_NO_WARNINGS

/******************* std libraries ******************/
#include <cstring>
#include <ctime>
#include <fstream>
#include <random>
#include <cfloat>
#include <tuple>
#include <assert.h>
#include <cmath>
#include <type_traits>
#include <functional>
#include <vector>
#include <algorithm>
#include <array>

/****************** Computing Engine ******************/
#include <arrayfire.h>

/***************** Begin of definitions ***************/
namespace network
{
	namespace type_check
	{
		template <typename T>
		struct just_basic_type : std::bool_constant<
			std::is_same<T, char>::value ||
			std::is_same<T, short>::value ||
			std::is_same<T, int>::value ||
			std::is_same<T, long long>::value ||
			std::is_same<T, float>::value ||
			std::is_same<T, double>::value ||
			std::is_same<T, long double>::value
		> {
		};
	}

	const int Init_He = 1, Init_Xavier = 2;

}

#ifdef NDEBUG
	#define ext_assert(_Expression,_Fail_Code) ((void)0)
#else
	#define ext_assert(_Expression,_Fail_Code) assert((_Expression)==true||((_Fail_Code),false))
#endif
/***************** End of definitions***************/

#include "network_h/read_only.h"
#include "network_h/file_io.h"
#include "network_h/Class_Base.h"
#include "network_h/auto_grad.h"
#include "network_h/Layers.h"
#include "network_h/Optimizer.h"