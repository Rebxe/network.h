#pragma once

#include <assert.h>
#include <functional>
#include <vector>
#include <cstring>
#include <cmath>

#include "defines.h"

namespace auto_dao
{
	int Batch_Size=0;
	
	struct node
	{
		int d,h,w;
		float *a,*da;
		node *in1,*in2;
		int oud,cnt;
		std::vector<std::function<void(node*,node*)> > backward_f;  // in      out
		std::function<void(node*,node*,node*)>         backward_f2; // in1 in2 out
		
		inline node(int td,int th,int tw);
		inline ~node();
		
		inline void initda();
		inline void backward();
	};
	
	std::vector<node*> tmp;
	
	inline void init(int BatchSize) // =0 for test
	{
		Batch_Size=BatchSize;
		for(node *x:tmp) delete x;
		tmp.clear();
	}
}

class val3d
{
	public:
		int d,h,w;
		float *a;
		float *da();

	public:
		inline val3d(){}
		inline val3d(int td,int th,int tw,float val=0);
		inline val3d(int td,int th,int tw,float *dat);
		inline void backward();

	public:
		auto_dao::node *dat;
};
		
inline val3d reshape(val3d x,int d,int h,int w,bool inplace=false);
inline val3d toshape(val3d x,int d,int h,int w);
inline val3d operator+(val3d x,val3d y);
inline val3d operator-(val3d x,val3d y);
inline val3d operator*(val3d x,val3d y);
inline val3d operator/(val3d x,val3d y);
inline val3d dcat(val3d x,val3d y);

inline float MSEloss(val3d x,float *realout);
inline float BCEloss(val3d x,float *realout); 

/***************************** End of definitions *****************************/


/******************************* auto_dao::node *******************************/

inline auto_dao::node::node(int td,int th,int tw)
{
	d=td,h=th,w=tw; 
	int bs=(std::max)(Batch_Size,1);
	a=new float[bs*d*h*w],da=0;
	memset(a,0,sizeof(float)*bs*d*h*w);
	in1=in2=0;
	oud=cnt=0;
	tmp.push_back(this);
}

inline auto_dao::node::~node()
{
	if(a!=0) delete[] a;
	if(da!=0) delete[] da;
}

inline void auto_dao::node::initda()
{
	if(da==0)
	{
		int bs=(std::max)(Batch_Size,1);
		da=new float[bs*d*h*w];
		memset(da,0,sizeof(float)*bs*d*h*w);
	}
}

inline void auto_dao::node::backward()
{
	if(in2==0&&in1==0) return;
	if(in2==0)
	{
		in1->initda();
		while(!backward_f.empty()) backward_f.back()(in1,this),backward_f.pop_back();
		if(++in1->cnt==in1->oud) in1->backward();
	}
	else
	{
		in1->initda(),in2->initda();
		backward_f2(in1,in2,this);
		if(++in1->cnt==in1->oud) in1->backward();
		if(++in2->cnt==in2->oud) in2->backward();
	}
	delete[] a;
	delete[] da;
	a=da=0;
}


/******************************* val3d *******************************/

inline float* val3d::da()
{
	dat->initda();
	return dat->da;
}

inline val3d::val3d(int td,int th,int tw,float val)
{
	d=td,h=th,w=tw;
	dat=new auto_dao::node(td,th,tw);
	a=dat->a;
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs*d*h*w;i++) a[i]=val;
}

inline val3d::val3d(int td,int th,int tw,float *val)
{
	d=td,h=th,w=tw;
	dat=new auto_dao::node(td,th,tw);
	a=dat->a;
	int bs=(std::max)(auto_dao::Batch_Size,1);
	memcpy(a,val,sizeof(float)*bs*d*h*w);
}

inline void val3d::backward()
{
	ext_assert(auto_dao::Batch_Size!=0,fprintf(stderr,"Backward is not allowed when testing\n\n"));
	ext_assert(dat->da!=0,fprintf(stderr,"There are no partial derivatives here\n\n"));
	dat->backward();
}

inline val3d reshape(val3d x,int d,int h,int w,bool inplace)
{
	ext_assert(x.d*x.h*x.w==d*h*w,
		fprintf(stderr,"\
In val3d reshape(val3d,int,int,int)\n\
  Input = [%d * %d * %d] = %d\n\
But\n\
  Output = [%d * %d * %d] = %d\n\n",x.d,x.h,x.w,x.d*x.h*x.w,d,h,w,d*h*w));
	val3d res;
	// forward
	int bs=(std::max)(auto_dao::Batch_Size,1);
	if(!inplace)
	{
		res=val3d(d,h,w);
		res.dat->in1=x.dat,x.dat->oud++;
		memcpy(res.a,x.a,sizeof(float)*bs*d*h*w);
	}
	else
	{
		res=x;
		res.dat->d=d,res.dat->h=h,res.dat->w=w;
		res.d=d,res.h=h,res.w=w;
	}
	// backward
	res.dat->backward_f.push_back([&,inplace,d,h,w](auto_dao::node* in,auto_dao::node* out)
    {
    	int bs=auto_dao::Batch_Size;
    	if(!inplace) for(int i=0;i<bs*d*h*w;i++) in->da[i]+=out->da[i];
		else out->d=d,out->h=h,out->w=w;
	});
    return res;
}

inline val3d toshape(val3d x,int d,int h,int w)
{
	val3d res(d,h,w);
	res.dat->in1=x.dat,x.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int adx=i*x.d*x.h*x.w,adr=i*d*h*w;
		for(int j=0;j<d;j++)
		{
			int adj=(j%x.d)*x.h*x.w;
			for(int k=0;k<h;k++)
			{
				int adk=(k%x.h)*x.w;
				for(int l=0;l<w;l++) res.a[adr++]=x.a[adx+adj+adk+(l%x.w)];
			}
		}
	}
	// backward
	res.dat->backward_f.push_back([&](auto_dao::node* nin,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int ind=nin->d,inh=nin->h,inw=nin->w;
    	int oud=nin->d,ouh=nin->h,ouw=nin->w;
 		float* din=nin->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int adi=i*ind*inh*inw,ado=i*oud*ouh*ouw;
			for(int j=0;j<oud;j++)
			{
				int adj=(j%ind)*inh*inw;
				for(int k=0;k<ouh;k++)
				{
					int adk=(k%inh)*inw;
					for(int l=0;l<ouw;l++) din[adi+adj+adk+(l%inw)]+=dout[ado++];
				}
			}
		}
    });
    return res;
}

inline val3d operator+(val3d x,val3d y)
{
	ext_assert(x.d==y.d&&x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val3d operator+(val3d x,val3d y)\n\
  x = [%d * %d * %d]\n\
  y = [%d * %d * %d]\n\n",x.d,x.h,x.w,y.d,y.h,y.w));
	val3d res(x.d,x.h,x.w);
	res.dat->in1=x.dat,x.dat->oud++;
	res.dat->in2=y.dat,y.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int ad=i*x.d*x.h*x.w;
		for(int j=0;j<x.d*x.h*x.w;j++) res.a[ad+j]=x.a[ad+j]+y.a[ad+j];
	}
	// backward
	res.dat->backward_f2=[&](auto_dao::node* nin1,auto_dao::node* nin2,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int d=nout->d,h=nout->h,w=nout->w;
    	float *din1=nin1->da,*din2=nin2->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int ad=i*d*h*w;
			for(int j=0;j<d*h*w;j++) din1[ad+j]+=dout[ad+j],din2[ad+j]+=dout[ad+j];
		}
    };
    return res;
}

inline val3d operator-(val3d x,val3d y)
{
	ext_assert(x.d==y.d&&x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val3d operator-(val3d x,val3d y)\n\
  x = [%d * %d * %d]\n\
  y = [%d * %d * %d]\n\n",x.d,x.h,x.w,y.d,y.h,y.w));
	val3d res(x.d,x.h,x.w);
	res.dat->in1=x.dat,x.dat->oud++;
	res.dat->in2=y.dat,y.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int ad=i*x.d*x.h*x.w;
		for(int j=0;j<x.d*x.h*x.w;j++) res.a[ad+j]=x.a[ad+j]-y.a[ad+j];
	}
	// backward
	res.dat->backward_f2=[&](auto_dao::node* nin1,auto_dao::node* nin2,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int d=nout->d,h=nout->h,w=nout->w;
    	float *din1=nin1->da,*din2=nin2->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int ad=i*d*h*w;
			for(int j=0;j<d*h*w;j++) din1[ad+j]+=dout[ad+j],din2[ad+j]+=-dout[ad+j];
		}
    };
    return res;
}

inline val3d operator*(val3d x,val3d y)
{
	ext_assert(x.d==y.d&&x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val3d operator*(val3d x,val3d y)\n\
  x = [%d * %d * %d]\n\
  y = [%d * %d * %d]\n\n",x.d,x.h,x.w,y.d,y.h,y.w));
	val3d res(x.d,x.h,x.w);
	res.dat->in1=x.dat,x.dat->oud++;
	res.dat->in2=y.dat,y.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int ad=i*x.d*x.h*x.w;
		for(int j=0;j<x.d*x.h*x.w;j++) res.a[ad+j]=x.a[ad+j]*y.a[ad+j];
	}
	// backward
	res.dat->backward_f2=[&](auto_dao::node* nin1,auto_dao::node* nin2,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int d=nout->d,h=nout->h,w=nout->w;
    	float *in1=nin1->a,*in2=nin2->a;
    	float *din1=nin1->da,*din2=nin2->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int ad=i*d*h*w;
			for(int j=0;j<d*h*w;j++)
			{
				din1[ad+j]+=dout[ad+j]*in2[ad+j];
				din2[ad+j]+=dout[ad+j]*in1[ad+j];
			}
		}
    };
    return res;
}

inline val3d operator/(val3d x,val3d y)
{
	ext_assert(x.d==y.d&&x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val3d operator/(val3d x,val3d y)\n\
  x = [%d * %d * %d]\n\
  y = [%d * %d * %d]\n\n",x.d,x.h,x.w,y.d,y.h,y.w));
	val3d res(x.d,x.h,x.w);
	res.dat->in1=x.dat,x.dat->oud++;
	res.dat->in2=y.dat,y.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int ad=i*x.d*x.h*x.w;
		for(int j=0;j<x.d*x.h*x.w;j++) res.a[ad+j]=x.a[ad+j]/y.a[ad+j];
	}
	// backward
	res.dat->backward_f2=[&](auto_dao::node* nin1,auto_dao::node* nin2,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int d=nout->d,h=nout->h,w=nout->w;
    	float *in1=nin1->a,*in2=nin2->a;
    	float *din1=nin1->da,*din2=nin2->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int ad=i*d*h*w;
			for(int j=0;j<d*h*w;j++)
			{
				din1[ad+j]+=dout[ad+j]/in2[ad+j];
				din2[ad+j]+=-in1[ad+j]/(in2[ad+j]*in2[ad+j])*dout[ad+j];
			}
		}
    };
    return res;
}

inline val3d dcat(val3d x,val3d y)
{
	ext_assert(x.h==y.h&&x.w==y.w,
		fprintf(stderr,"\
In val3d dcat(val3d x,val3d y)\n\
  x = [%d * %d * %d]\n\
  y = [%d * %d * %d]\n\n",x.d,x.h,x.w,y.d,y.h,y.w));
	val3d res(x.d+y.d,x.h,x.w);
	res.dat->in1=x.dat,x.dat->oud++;
	res.dat->in2=y.dat,y.dat->oud++;
	// forward 
	int bs=(std::max)(auto_dao::Batch_Size,1);
	for(int i=0;i<bs;i++)
	{
		int adx=i*x.d*x.h*x.w,ady=i*y.d*x.h*x.w;
		int ad=i*(x.d+y.d)*x.h*x.w;
		for(int j=0;j<x.d*x.h*x.w;j++) res.a[ad+j]=x.a[adx+j];
		for(int j=0;j<y.d*x.h*x.w;j++) res.a[ad+x.d*x.h*x.w+j]=y.a[ady+j];
	}
	// backward
	res.dat->backward_f2=[&](auto_dao::node* nin1,auto_dao::node* nin2,auto_dao::node* nout)
    {
    	int bs=auto_dao::Batch_Size; 
    	int d1=nin1->d,d2=nin2->d;
		int h=nout->h,w=nout->w;
    	float *din1=nin1->da,*din2=nin2->da,*dout=nout->da;
		for(int i=0;i<bs;i++)
		{
			int ad1=i*d1*h*w,ad2=i*d2*h*w;
			int ad=i*(d1+d2)*h*w;
			for(int j=0;j<d1*h*w;j++) din1[ad1+j]+=dout[ad+j];
			for(int j=0;j<d2*h*w;j++) din2[ad2+j]+=dout[ad+d1*h*w+j];
		}
    };
    return res;
}

inline float MSEloss(val3d x,float *realout)
{
	float res=0;
	int bs=(std::max)(auto_dao::Batch_Size,1);
	int n=bs*x.d*x.h*x.w;
	for(int i=0;i<n;i++)
	{
		float y=realout[i];
		res+=pow(x.a[i]-y,2)/n;
		x.da()[i]=2*(x.a[i]-y)/n;
	}
	return res;
}

inline float BCEloss(val3d x,float *realout)
{
	float res=0;
	int bs=(std::max)(auto_dao::Batch_Size,1);
	int n=bs*x.d*x.h*x.w;
	for(int i=0;i<n;i++)
	{
		float val=x.a[i],y=realout[i];
		float eps=1e-7;
		if(val<eps||val>1-eps)
		{
			val=(std::max)(eps,(std::min)(val,1-eps));
			x.da()[i]=0;
		}
		else x.da()[i]=-(y*(1/val)-(1-y)*(1/(1-val)))/n;
		res+=-(y*log(val)+(1-y)*log(1-val))/n;
	}
	return res;
}
