#pragma once

#include "Eigen/Eigen"

inline void toNHWD(float* a, int bs, int d, int h, int w)
{
	float* tmp = new float[d * h * w];
	for (int tb = 0;tb < bs;tb++)
	{
		int ad = tb * d * h * w;
		for (int i = 0;i < d;i++)
			for (int j = 0;j < h * w;j++)
				tmp[j * d + i] = a[ad + i * h * w + j];
		memcpy(a + ad, tmp, sizeof(float) * d * h * w);
	}
	delete[] tmp;
}

inline void toNDHW(float* a, int bs, int h, int w, int d)
{
	float* tmp = new float[d * h * w];
	for (int tb = 0;tb < bs;tb++)
	{
		int ad = tb * d * h * w;
		for (int i = 0;i < h * w;i++)
			for (int j = 0;j < d;j++)
				tmp[j * h * w + i] = a[ad + i * d + j];
		memcpy(a + ad, tmp, sizeof(float) * d * h * w);
	}
	delete[] tmp;
}

#ifdef ENABLE_GPU
	#define VIENNACL_WITH_OPENCL
	#define VIENNACL_WITH_EIGEN
	#include "viennacl/matrix.hpp"
	/*
		A: N*M
		B: M*K
		C: N*K
	*/
	inline void Matrix_Mul(int N, int M, int K,
		float* A, bool ta, // A or A^T
		float* B, bool tb, // B or B^T
		float* C)          // C
	{
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > a(A, !ta ? N : M, !ta ? M : N);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > b(B, !tb ? M : K, !tb ? K : M);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > c(C, N, K);
		viennacl::matrix<float> gpu_a(!ta ? N : M, !ta ? M : N);
		viennacl::matrix<float> gpu_b(!tb ? M : K, !tb ? K : M);
		viennacl::matrix<float> gpu_c(N, K);
		viennacl::copy(a, gpu_a);
		viennacl::copy(b, gpu_b);
		viennacl::copy(c, gpu_c);
		gpu_c += viennacl::linalg::prod(
			!ta ? gpu_a : viennacl::trans(gpu_a),
			!tb ? gpu_b : viennacl::trans(gpu_b)
		);
		viennacl::copy(gpu_c, c);
	}
#else
	// A: N*M
	// B: M*K
	// C: N*K
	inline void Matrix_Mul(int N, int M, int K,
		float* A, bool ta, // A or A^T
		float* B, bool tb, // B or B^T
		float* C)          // C
	{
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > a(A, !ta ? N : M, !ta ? M : N);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > b(B, !tb ? M : K, !tb ? K : M);
		Eigen::Map<Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> > c(C, N, K);
		if (!ta && !tb) c += a * b;
		if (ta&&!tb) c += a.transpose() * b;
		if (!ta&&tb) c += a * b.transpose();
		if (ta&&tb) c += a.transpose() * b.transpose();
	}
#endif